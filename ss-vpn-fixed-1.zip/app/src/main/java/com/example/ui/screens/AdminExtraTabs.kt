package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AdminSession
import com.example.data.AppConfigManager
import com.example.data.sanitizeUrl

private val AdText = Color(0xFF0F172A)
private val AdSub = Color(0xFF64748B)
private val AdBlue = Color(0xFF0F62FE)
private val AdBorder = Color(0xFFE2E8F0)
private val AdCard = Color(0xFFF8F9FA)

@Composable
private fun AdminCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(AdCard)
            .border(1.dp, AdBorder, RoundedCornerShape(22.dp))
            .padding(16.dp)
    ) {
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = AdText)
        Spacer(modifier = Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun SwitchLine(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = AdText)
            Text(desc, fontSize = 12.sp, color = AdSub)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun <T> Pills(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { (label, value) ->
            val on = value == selected
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (on) AdBlue else Color.White)
                    .border(1.dp, if (on) AdBlue else AdBorder, RoundedCornerShape(20.dp))
                    .clickable { onSelect(value) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (on) Color.White else AdText)
            }
        }
    }
}

@Composable
private fun Field(value: String, onChange: (String) -> Unit, label: String, singleLine: Boolean = true) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
    )
}

@Composable
private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp),
        colors = ButtonDefaults.buttonColors(containerColor = AdBlue),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

// =====================================================================
// ট্যাব ১: Control — বিজ্ঞাপন, সার্ভিস স্ট্যাটাস, ট্রাবলশুটিং, লাইসেন্স টুল, অডিট
// =====================================================================
@Composable
fun AdminControlTab(appConfigManager: AppConfigManager) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val control by appConfigManager.appControl.collectAsState()
    val keys by appConfigManager.keysList.collectAsState()
    val audit by appConfigManager.adminAudit.collectAsState()

    var maintMsg by remember(control.maintenanceMessage) { mutableStateOf(control.maintenanceMessage) }
    var announce by remember(control.announcement) { mutableStateOf(control.announcement) }
    var genDays by remember { mutableStateOf(30) }
    var lastKey by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        AdminCard("Ads control") {
            SwitchLine("All ads", "Master switch for every ad slot", control.adsEnabled) { v ->
                appConfigManager.updateAppControl("Ads master ${if (v) "ON" else "OFF"}") { it.copy(adsEnabled = v) }
            }
            SwitchLine("Banner ad", "Inline banner on the home page", control.bannerEnabled) { v ->
                appConfigManager.updateAppControl("Banner ${if (v) "ON" else "OFF"}") { it.copy(bannerEnabled = v) }
            }
            SwitchLine("Connect/disconnect ad", "Full-screen ad before connect & disconnect", control.interstitialEnabled) { v ->
                appConfigManager.updateAppControl("Interstitial ${if (v) "ON" else "OFF"}") { it.copy(interstitialEnabled = v) }
            }
            SwitchLine("Rewarded ad", "'Watch ad for ad-free time' card", control.rewardedEnabled) { v ->
                appConfigManager.updateAppControl("Rewarded ${if (v) "ON" else "OFF"}") { it.copy(rewardedEnabled = v) }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Reward length (hours of ad-free time per ad)", fontSize = 12.sp, color = AdSub)
            Spacer(modifier = Modifier.height(6.dp))
            Pills(
                options = listOf(1, 2, 3, 6, 12, 24).map { "${it}h" to it },
                selected = control.rewardHours
            ) { h -> appConfigManager.updateAppControl("Reward hours = $h") { it.copy(rewardHours = h) } }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Note: ad slots are placeholders until the AdMob SDK is integrated. IDs are kept in the 'AdMob IDs' tab.",
                fontSize = 11.sp,
                color = AdSub
            )
        }

        AdminCard("Service status") {
            SwitchLine("Maintenance mode", "Blocks new connections and shows the message below", control.maintenanceMode) { v ->
                appConfigManager.updateAppControl("Maintenance ${if (v) "ON" else "OFF"}") { it.copy(maintenanceMode = v) }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Field(maintMsg, { maintMsg = it.take(200) }, "Maintenance message")
            Spacer(modifier = Modifier.height(8.dp))
            PrimaryButton("Save maintenance message") {
                appConfigManager.updateAppControl("Maintenance message edited") { it.copy(maintenanceMessage = maintMsg) }
                Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
            }
            Spacer(modifier = Modifier.height(14.dp))
            Field(announce, { announce = it.take(200) }, "Announcement shown on home (empty = hidden)")
            Spacer(modifier = Modifier.height(8.dp))
            PrimaryButton("Publish announcement") {
                appConfigManager.updateAppControl("Announcement updated") { it.copy(announcement = announce) }
                Toast.makeText(context, "Published", Toast.LENGTH_SHORT).show()
            }
        }

        AdminCard("Connection troubleshooting") {
            Text(
                "TLS fingerprint used by Reality. If connections fail with 'reality verification failed', try another value.",
                fontSize = 12.sp,
                color = AdSub
            )
            Spacer(modifier = Modifier.height(8.dp))
            Pills(
                options = listOf(
                    "Profile default" to "",
                    "chrome" to "chrome",
                    "firefox" to "firefox",
                    "safari" to "safari",
                    "ios" to "ios",
                    "android" to "android",
                    "edge" to "edge",
                    "random" to "random"
                ),
                selected = control.fingerprintOverride
            ) { fp -> appConfigManager.updateAppControl("Fingerprint = ${fp.ifBlank { "default" }}") { it.copy(fingerprintOverride = fp) } }
            Spacer(modifier = Modifier.height(6.dp))
            Text("Applies on the next connect.", fontSize = 11.sp, color = AdSub)
        }

        AdminCard("License keys") {
            Text("Validity of new key", fontSize = 12.sp, color = AdSub)
            Spacer(modifier = Modifier.height(6.dp))
            Pills(
                options = listOf(7, 30, 90, 365).map { "${it} days" to it },
                selected = genDays
            ) { genDays = it }
            Spacer(modifier = Modifier.height(10.dp))
            PrimaryButton("Generate key") {
                lastKey = appConfigManager.generatePremiumKey(genDays)
                appConfigManager.logAdminAction("Generated $genDays-day key")
            }
            lastKey?.let { k ->
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(k, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AdText, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(k))
                        Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                    }) { Text("Copy") }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            TextButton(onClick = {
                val n = appConfigManager.deleteRevokedKeys()
                Toast.makeText(context, "Deleted $n revoked keys", Toast.LENGTH_SHORT).show()
            }) { Text("Delete all revoked keys") }

            keys.take(30).forEach { k ->
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(k.key, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AdText)
                        Text(
                            when {
                                k.isRevoked -> "Revoked"
                                k.boundDeviceId != null -> "Bound to a device"
                                else -> "Unused"
                            },
                            fontSize = 11.sp,
                            color = AdSub
                        )
                    }
                    if (k.boundDeviceId != null) {
                        TextButton(onClick = { appConfigManager.unbindKeyDevice(k.key) }) { Text("Unbind", fontSize = 12.sp) }
                    }
                    if (!k.isRevoked) {
                        TextButton(onClick = { appConfigManager.revokeKey(k.key) }) { Text("Revoke", fontSize = 12.sp) }
                    }
                    TextButton(onClick = { appConfigManager.deleteKey(k.key) }) { Text("Delete", fontSize = 12.sp, color = Color(0xFFDC2626)) }
                }
            }
        }

        AdminCard("Admin activity log") {
            if (audit.isEmpty()) {
                Text("No activity yet.", fontSize = 12.sp, color = AdSub)
            } else {
                audit.take(20).forEach { line ->
                    Text(line, fontSize = 12.sp, color = AdText, modifier = Modifier.padding(vertical = 2.dp))
                }
                TextButton(onClick = { appConfigManager.clearAdminAudit() }) { Text("Clear log") }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Spacer(modifier = Modifier.navigationBarsPadding())
    }
}

// =====================================================================
// ট্যাব ২: Branding — নাম, হেডলাইন, লোগো, লঞ্চার আইকন
// =====================================================================
private fun decodeScaled(context: android.content.Context, uri: Uri): Bitmap? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    } catch (e: Exception) {
        null
    }
}

@Composable
fun AdminBrandingTab(appConfigManager: AppConfigManager) {
    val context = LocalContext.current
    val control by appConfigManager.appControl.collectAsState()
    val logoVersion by appConfigManager.logoVersion.collectAsState()
    val logo = remember(logoVersion) { appConfigManager.loadLogo() }

    var nameInput by remember(control.appName) { mutableStateOf(control.appName) }
    var headlineInput by remember(control.homeHeadline) { mutableStateOf(control.homeHeadline) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val ok = appConfigManager.saveLogo(decodeScaled(context, uri))
            Toast.makeText(context, if (ok) "Logo updated" else "Could not read that image", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        AdminCard("App name & headline") {
            Field(nameInput, { nameInput = it.take(30) }, "App name (shown inside the app)")
            Spacer(modifier = Modifier.height(10.dp))
            Field(headlineInput, { headlineInput = it.take(60) }, "Home headline")
            Spacer(modifier = Modifier.height(10.dp))
            PrimaryButton("Save", enabled = nameInput.isNotBlank()) {
                appConfigManager.updateAppControl("Branding text updated") {
                    it.copy(appName = nameInput, homeHeadline = headlineInput)
                }
                Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
            }
        }

        AdminCard("In-app logo") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(36.dp))
                        .background(Color.White)
                        .border(1.dp, AdBorder, RoundedCornerShape(36.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (logo != null) {
                        androidx.compose.foundation.Image(
                            bitmap = logo.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier.size(72.dp).clip(RoundedCornerShape(36.dp)),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                        )
                    } else {
                        Text("Default", fontSize = 11.sp, color = AdSub)
                    }
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Button(
                        onClick = {
                            AdminSession.suppressAutoClose = true
                            picker.launch("image/*")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AdBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Choose image", fontSize = 13.sp) }
                    if (logo != null) {
                        TextButton(onClick = { appConfigManager.clearLogo() }) { Text("Remove custom logo", fontSize = 12.sp) }
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Square images look best. The logo is stored on this device only.", fontSize = 11.sp, color = AdSub)
        }

        AdminCard("Launcher icon & name") {
            Text(
                "Choose how the app appears on the phone's home screen. The change applies on this device within a few seconds.",
                fontSize = 12.sp,
                color = AdSub
            )
            Spacer(modifier = Modifier.height(8.dp))
            Pills(
                options = listOf("SS VPN (default)" to 0, "Shield VPN" to 1, "Night VPN" to 2),
                selected = control.launcherPreset
            ) { preset ->
                appConfigManager.updateAppControl("Launcher preset = $preset") { it.copy(launcherPreset = preset) }
                appConfigManager.applyLauncherPreset(preset)
                Toast.makeText(context, "Launcher updated — it may take a moment to refresh", Toast.LENGTH_LONG).show()
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Names/icons of these presets are defined in strings.xml and res/drawable (ic_launcher_alt_*). Edit them there to use your own artwork, then rebuild.",
                fontSize = 11.sp,
                color = AdSub
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
        Spacer(modifier = Modifier.navigationBarsPadding())
    }
}

// =====================================================================
// ট্যাব ৩: Links — সোশ্যাল লিংক ও আপডেট তথ্য
// =====================================================================
@Composable
fun AdminLinksTab(appConfigManager: AppConfigManager) {
    val context = LocalContext.current
    val control by appConfigManager.appControl.collectAsState()

    var fb by remember(control.facebookUrl) { mutableStateOf(control.facebookUrl) }
    var yt by remember(control.youtubeUrl) { mutableStateOf(control.youtubeUrl) }
    var ig by remember(control.instagramUrl) { mutableStateOf(control.instagramUrl) }
    var tg by remember(control.telegramUrl) { mutableStateOf(control.telegramUrl) }
    var latest by remember(control.latestVersion) { mutableStateOf(control.latestVersion) }
    var updateUrl by remember(control.updateUrl) { mutableStateOf(control.updateUrl) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        AdminCard("Community links") {
            Text("Only https:// or http:// links are accepted. Empty = hidden in the app.", fontSize = 12.sp, color = AdSub)
            Spacer(modifier = Modifier.height(10.dp))
            Field(fb, { fb = it }, "Facebook URL")
            Spacer(modifier = Modifier.height(8.dp))
            Field(yt, { yt = it }, "YouTube URL")
            Spacer(modifier = Modifier.height(8.dp))
            Field(ig, { ig = it }, "Instagram URL")
            Spacer(modifier = Modifier.height(8.dp))
            Field(tg, { tg = it }, "Telegram URL (e.g. https://t.me/yourchannel)")
        }

        AdminCard("App update") {
            Text(
                "When 'Latest version' is higher than the installed version, users see a Download update button in Settings.",
                fontSize = 12.sp,
                color = AdSub
            )
            Spacer(modifier = Modifier.height(10.dp))
            Field(latest, { latest = it.take(20) }, "Latest version (e.g. 1.1)")
            Spacer(modifier = Modifier.height(8.dp))
            Field(updateUrl, { updateUrl = it }, "Download link (https://…)")
        }

        PrimaryButton("Save links & update info") {
            val bad = listOf(fb, yt, ig, tg, updateUrl).any { it.isNotBlank() && sanitizeUrl(it).isEmpty() }
            if (bad) {
                Toast.makeText(context, "Only http:// or https:// links are allowed", Toast.LENGTH_LONG).show()
            } else {
                appConfigManager.updateAppControl("Links/update info updated") {
                    it.copy(
                        facebookUrl = fb, youtubeUrl = yt, instagramUrl = ig, telegramUrl = tg,
                        latestVersion = latest, updateUrl = updateUrl
                    )
                }
                Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Spacer(modifier = Modifier.navigationBarsPadding())
    }
}
