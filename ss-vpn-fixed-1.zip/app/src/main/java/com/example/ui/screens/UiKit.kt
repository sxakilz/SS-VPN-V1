package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalPal

/** পুরো প্রজেক্টে ব্যবহৃত গোলাকার কার্ড। */
@Composable
fun PalCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val pal = LocalPal.current
    val base = modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(26.dp))
        .background(pal.card)
        .border(BorderStroke(1.dp, pal.border), RoundedCornerShape(26.dp))
    val clickMod = if (onClick != null) base.clickable { onClick() } else base
    Column(modifier = clickMod.padding(horizontal = 20.dp, vertical = 16.dp), content = content)
}

@Composable
fun SectionHeader(title: String, subtitle: String) {
    val pal = LocalPal.current
    Column(modifier = Modifier.padding(top = 22.dp, bottom = 10.dp)) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = pal.text)
        Text(subtitle, fontSize = 13.sp, color = pal.sub)
    }
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color? = null) {
    val pal = LocalPal.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 15.sp, color = pal.sub)
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            value,
            fontSize = 15.sp,
            color = valueColor ?: pal.text,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f, fill = false)
        )
    }
}

/** সোশ্যাল বাটন — ব্র্যান্ড আইকনের বদলে রঙিন অক্ষর, যাতে কোনো অতিরিক্ত লাইব্রেরি না লাগে। */
@Composable
fun SocialButton(label: String, glyph: String, tint: Color, url: String, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    val uri = LocalUriHandler.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable {
                try { uri.openUri(url) } catch (_: Exception) { }
            }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(tint.copy(alpha = if (pal.isDark) 0.18f else 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Text(glyph, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = tint)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, fontSize = 12.sp, color = pal.text)
    }
}

@Composable
fun CommunityRow(
    facebook: String,
    youtube: String,
    instagram: String,
    telegram: String
) {
    val items = buildList {
        if (facebook.isNotBlank()) add(Triple("Facebook", "f", Color(0xFF1877F2)) to facebook)
        if (youtube.isNotBlank()) add(Triple("YouTube", "▶", Color(0xFFFF2D2D)) to youtube)
        if (instagram.isNotBlank()) add(Triple("Instagram", "IG", Color(0xFFE1306C)) to instagram)
        if (telegram.isNotBlank()) add(Triple("Telegram", "TG", Color(0xFF29A9EB)) to telegram)
    }
    if (items.isEmpty()) return
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items.forEach { (meta, url) ->
            SocialButton(
                label = meta.first,
                glyph = meta.second,
                tint = meta.third,
                url = url,
                modifier = Modifier.weight(1f)
            )
        }
        // বাকি জায়গা ফাঁকা রেখে বাটনগুলো সমান আকারে রাখা
        repeat(4 - items.size) { Spacer(modifier = Modifier.weight(1f)) }
    }
}

/** নিচের ভাসমান নেভিগেশন (Home / Settings)। */
@Composable
fun FloatingNav(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(32.dp))
                .background(pal.card)
                .border(BorderStroke(1.dp, pal.border), RoundedCornerShape(32.dp))
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            NavItem("Home", Icons.Default.Home, selected == 0, Modifier.weight(1f)) { onSelect(0) }
            NavItem("Settings", Icons.Default.Settings, selected == 1, Modifier.weight(1f)) { onSelect(1) }
        }
    }
}

@Composable
private fun NavItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val pal = LocalPal.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(26.dp))
            .background(if (selected) pal.accent.copy(alpha = if (pal.isDark) 0.22f else 0.16f) else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) pal.accent else pal.sub, modifier = Modifier.size(24.dp))
        Text(
            label,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) pal.accent else pal.sub
        )
    }
}

/** ডিফল্ট লোগো: অ্যাডমিন কাস্টম লোগো না দিলে এটি দেখায়। */
@Composable
fun BrandLogo(
    bitmap: android.graphics.Bitmap?,
    size: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    val pal = LocalPal.current
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(pal.card)
            .border(BorderStroke(1.dp, pal.border), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            androidx.compose.foundation.Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
        } else {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = pal.accent,
                modifier = Modifier.size(size * 0.55f)
            )
        }
    }
}

/** "1.2.0" > "1.1.9" তুলনা। */
fun isNewerVersion(latest: String, installed: String): Boolean {
    fun parts(v: String) = v.trim().removePrefix("v").split(".").map { it.filter { c -> c.isDigit() }.toIntOrNull() ?: 0 }
    val a = parts(latest)
    val b = parts(installed)
    for (i in 0 until maxOf(a.size, b.size)) {
        val x = a.getOrElse(i) { 0 }
        val y = b.getOrElse(i) { 0 }
        if (x != y) return x > y
    }
    return false
}
