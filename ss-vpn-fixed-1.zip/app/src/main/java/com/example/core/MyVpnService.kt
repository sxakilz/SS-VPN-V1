package com.example.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.vpn.TrafficStats
import com.example.vpn.VlessProfile
import com.example.vpn.VpnStatus
import com.example.BuildConfig
import com.example.RealityVpnApp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicLong

/**
 * Production Android VpnService backed by the native sing-box (libbox) VLESS Reality core.
 *
 * Enforces:
 * - Physical connectivity pre-check before touching TUN
 * - Strictly protected TUN (`172.19.0.1/30`, `0.0.0.0/0`, `AF_INET` on API 21+, app self-exclusion)
 * - Full sing-box VLESS Reality (`xtls-rprx-vision`, `xudp`) outbound with `"final": "proxy"` & `hijack-dns`
 * - 4-second VPS socket handshake verification & auto-fallback (never shows fake connected state)
 * - Real sing-box CommandClient telemetry for upload/download speeds and byte totals
 */
class MyVpnService : VpnService() {

    private var singBoxEngine: SingBoxEngine? = null
    private var workerJob: Job? = null
    private val serviceJob = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + serviceJob)

    private val liveUpRateBytesPerSec = AtomicLong(0L)
    private val liveDownRateBytesPerSec = AtomicLong(0L)
    private val liveTotalUpBytes = AtomicLong(0L)
    private val liveTotalDownBytes = AtomicLong(0L)

    private var activeProfile: VlessProfile? = null
    private var startTimeMillis: Long = 0L

    override fun onCreate() {
        super.onCreate()
        currentInstance = this
        _activeOutboundTag.value = "proxy"
        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val configJson = intent.getStringExtra(EXTRA_CONFIG_JSON)
                val profile = if (!configJson.isNullOrEmpty()) {
                    try {
                        val obj = JSONObject(configJson)
                        VlessProfile(
                            id = obj.optString("id"),
                            remarks = obj.optString("remarks", ConfigManager.DEFAULT_REMARKS),
                            address = obj.optString("address", ConfigManager.DEFAULT_SERVER_IP),
                            port = obj.optInt("port", ConfigManager.DEFAULT_PORT),
                            uuid = obj.optString("uuid", ConfigManager.DEFAULT_UUID),
                            flow = obj.optString("flow", ConfigManager.DEFAULT_FLOW),
                            security = obj.optString("security", ConfigManager.DEFAULT_SECURITY),
                            sni = obj.optString("sni", ConfigManager.DEFAULT_SNI),
                            fingerprint = obj.optString("fingerprint", ConfigManager.DEFAULT_FINGERPRINT),
                            packetEncoding = obj.optString("packetEncoding", ConfigManager.DEFAULT_PACKET_ENCODING),
                            publicKey = obj.optString("publicKey", ConfigManager.DEFAULT_PUBLIC_KEY),
                            shortId = obj.optString("shortId", ConfigManager.DEFAULT_SHORT_ID)
                        )
                    } catch (_: Exception) {
                        ConfigManager.DEFAULT_PROFILE
                    }
                } else {
                    ConfigManager.DEFAULT_PROFILE
                }

                startTunnel(profile)
            }
            ACTION_DISCONNECT -> {
                stopTunnel()
            }
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    private fun networkLabel(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return "unknown"
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) } ?: return "none"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            else -> "other"
        }
    }

    private fun isPhysicalNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
    }

    private fun startTunnel(profile: VlessProfile) {
        // startForegroundService() requires startForeground() within ~5s on EVERY path,
        // including the early-return below, otherwise the app is killed.
        startForeground(NOTIFICATION_ID, createNotification("Connecting to SS VPN (Smart Secured)..."))

        validateProfile(profile)?.let { problem ->
            _vpnStatus.value = VpnStatus.DISCONNECTED
            _lastErrorMessage.value = "Invalid server profile: $problem"
            appendLog("[app] Invalid server profile: $problem")
            stopTunnel()
            return
        }

        // 1. Mandatory Physical Pre-Check
        if (!isPhysicalNetworkAvailable()) {
            _vpnStatus.value = VpnStatus.DISCONNECTED
            _lastErrorMessage.value = "No Internet Connection"
            stopSelf()
            return
        }

        // Tear down any previous core instance cleanly before starting a new session
        workerJob?.cancel()
        workerJob = null
        singBoxEngine?.stop()
        singBoxEngine = null

        activeProfile = profile
        if (BuildConfig.DEBUG) {
            appendLog("[app] Connecting to ${profile.address}:${profile.port} (sni=${profile.sni}, flow=${profile.flow}, fp=${profile.fingerprint}, sid=${profile.shortId}, uuid=${profile.uuid.take(8)}…${profile.uuid.takeLast(4)}, pbk=${profile.publicKey.take(6)}…${profile.publicKey.takeLast(4)})")
        } else {
            appendLog("[app] Connecting...")
        }
        _vpnStatus.value = VpnStatus.CONNECTING
        _lastErrorMessage.value = null

        workerJob = scope.launch {
            try {
                // Measure initial direct VPS latency via protected socket
                val initialPing = measurePing(profile.address, profile.port)
                if (initialPing > 0) {
                    _pingMs.value = initialPing
                }

                val acm = RealityVpnApp.instance.appConfigManager
                var fakeDns = acm.engineDnsMode() == "fakeip"
                val engineMtu = acm.engineMtu()
                val candidates = if (acm.engineAutoFallback()) buildCandidates(profile) else listOf(profile)
                var tunnelProbe: SingBoxEngine.TunnelProbeResult? = null
                var usedProfile = profile
                var lastEngine: SingBoxEngine? = null
                for ((idx, cand) in candidates.withIndex()) {
                // 2+3. কনফিগ বানিয়ে sing-box (libbox) চালু; Fake-IP কনফিগ নিতে না পারলে নিজে সাধারণ DNS-এ নামে
                val started = startEngineFor(cand, engineMtu, fakeDns)
                val engine = started.engine
                val probePort = started.probePort
                fakeDns = started.fakeUsed
                lastEngine = engine

                // Confirm TUN was established by sing-box PlatformInterface
                if (engine.currentTunDescriptor == null) {
                    _lastErrorMessage.value = "Connection Failed: Unable to initialize VPN TUN interface"
                    stopTunnel()
                    return@launch
                }

                // 4A. Real 4-second VPS TCP Handshake Validation (Anti-Fake Connection Guard)
                val isHandshakeValid = withTimeoutOrNull(4000L) {
                    validateServerHandshake(profile)
                } ?: false

                appendLog("[app] VPS TCP handshake ok=$isHandshakeValid, tun fd ready=${engine.currentTunDescriptor != null}")
                if (!isHandshakeValid) {
                    _lastErrorMessage.value =
                        "Connection Failed: cannot reach server (${lastHandshakeError ?: "timed out after 4s"})"
                    stopTunnel()
                    return@launch
                }

                // 4B. End-to-End VLESS Reality + DNS + HTTPS Egress Verification inside sing-box
                val firstProbe = withTimeoutOrNull(if (candidates.size > 1) 15_000L else 25_000L) {
                    SingBoxEngine.verifyEndToEndTunnel(
                        socksPort = probePort,
                        timeoutMs = 7000,
                        coreLogProvider = { engine.getRecentLogs() },
                        socketProtector = { sock -> protect(sock) }
                    )
                } ?: SingBoxEngine.TunnelProbeResult(
                    success = false,
                    failureStage = SingBoxEngine.TunnelFailureStage.HTTP_READ_TIMEOUT,
                    errorDetail = SingBoxEngine.diagnoseProbeFailure(
                        stage = SingBoxEngine.TunnelFailureStage.HTTP_READ_TIMEOUT,
                        targetHost = "connectivitycheck.gstatic.com / ifconfig.me",
                        coreLogs = engine.getRecentLogs(),
                        rawDetail = "HTTPS tunnel verification exceeded 25s total budget"
                    ).second
                )

                // স্থিতিশীলতা পরীক্ষা: একটি সফল টেস্টই যথেষ্ট নয়। আরও ৪টি নতুন সংযোগ চালিয়ে অন্তত ৩/৫ পাস না করলে
                // এই কম্বিনেশন ব্যর্থ ধরা হয় (সার্ভার বেশিরভাগ সংযোগ ফিরিয়ে দিলে "Connected" দেখানো ঠিক নয়)।
                var probeResult = firstProbe
                if (firstProbe.success) {
                    var passed = 1
                    var failed = 0
                    var runs = 0
                    while (runs < 4 && failed < 3) {
                        runs++
                        val r = withTimeoutOrNull(9_000L) {
                            SingBoxEngine.verifyEndToEndTunnel(
                                socksPort = probePort,
                                timeoutMs = 4000,
                                coreLogProvider = { engine.getRecentLogs() },
                                probeTargets = SingBoxEngine.DEFAULT_PROBE_TARGETS.take(1),
                                socketProtector = { sock -> protect(sock) }
                            )
                        }
                        if (r?.success == true) passed++ else failed++
                    }
                    val total = passed + failed
                    appendLog("[app] stability: $passed/$total test connections passed")
                    if (passed < 3) {
                        probeResult = firstProbe.copy(
                            success = false,
                            failureStage = SingBoxEngine.TunnelFailureStage.UPSTREAM_REALITY_EOF,
                            errorDetail = "Tunnel unstable: only $passed of $total test connections passed. " +
                                "Check UUID / Public Key / Short ID / Flow on the server (Admin → Server)."
                        )
                    }
                }

                appendLog("[app] attempt ${idx + 1}/${candidates.size} net=${networkLabel()} dns=${if (fakeDns) "fakeip" else "standard"} mtu=$engineMtu fp=${cand.fingerprint} flow=${cand.flow.ifBlank { "none" }} -> success=${probeResult.success} stage=${probeResult.failureStage} ip=${probeResult.exitIp} detail=${probeResult.errorDetail?.take(160)}")
                if (probeResult.success) {
                    tunnelProbe = probeResult
                    usedProfile = cand
                    saveWorkingVariant(cand)
                    break
                }
                tunnelProbe = probeResult
                if (idx < candidates.size - 1) { singBoxEngine = null; lastEngine = null; engine.stop() }

                }
                val engine = lastEngine ?: return@launch
                val finalProbe = tunnelProbe ?: return@launch
                if (!finalProbe.success) {
                    val detail = finalProbe.errorDetail ?: "VLESS Reality HTTPS verification failed"
                    _lastErrorMessage.value =
                        if (finalProbe.failureStage == SingBoxEngine.TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED) {
                            "Preview Sandbox Restriction: $detail"
                        } else {
                            "Connection Failed: $detail"
                        }
                    stopTunnel()
                    return@launch
                }

                if (finalProbe.latencyMs > 0) {
                    _pingMs.value = finalProbe.latencyMs
                }
                _verifiedExitIp.value = finalProbe.exitIp

                // 5. Verified sing-box TUN + VLESS Reality end-to-end internet: enter CONNECTED state
                startTimeMillis = System.currentTimeMillis()
                _vpnStatus.value = VpnStatus.CONNECTED
                _connectedProfile.value = usedProfile
                _activeOutboundTag.value = "proxy"

                val pingLabel = if (_pingMs.value > 0) "${_pingMs.value} ms" else "Protected"
                updateNotification("Protected • SS VPN (Smart Secured) • $pingLabel")

                var tick = 0L
                while (isActive && singBoxEngine != null && engine.currentTunDescriptor != null) {
                    delay(1000L)
                    tick++

                    val duration = (System.currentTimeMillis() - startTimeMillis) / 1000L + sessionBonusSeconds

                    if (tick % 15L == 0L) {
                        val newPing = measurePing(profile.address, profile.port)
                        if (newPing > 0) {
                            _pingMs.value = newPing
                            updateNotification("Protected • SS VPN (Smart Secured) • $newPing ms")
                        }
                    }

                    _stats.value = SingBoxEngine.calculateLiveTrafficStats(
                        uplinkBytesPerSec = liveUpRateBytesPerSec.get(),
                        downlinkBytesPerSec = liveDownRateBytesPerSec.get(),
                        totalUploadBytes = liveTotalUpBytes.get(),
                        totalDownloadBytes = liveTotalDownBytes.get(),
                        durationSeconds = duration
                    )
                }
                if (isActive && engine.currentTunDescriptor == null && _vpnStatus.value == VpnStatus.CONNECTED) {
                    _lastErrorMessage.value = "Connection Failed: VPN TUN interface closed unexpectedly"
                    stopTunnel()
                }
            } catch (e: CancellationException) {
                // ব্যবহারকারী ডিসকানেক্ট চাপলে coroutine বাতিল হয় — এটা ত্রুটি নয়, তাই কোনো বার্তা নয়।
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "sing-box tunnel startup failed: ${e.message}", e)
                appendLog("[app] Startup exception: ${e.javaClass.simpleName}: ${e.message}")
                _lastErrorMessage.value = if (e.message?.contains("config", ignoreCase = true) == true) {
                    "Connection Failed: Core Config Error (${e.message})"
                } else {
                    "Connection Failed: ${e.message ?: e.javaClass.simpleName}"
                }
                stopTunnel()
            }
        }
    }


    /** সার্ভারের Reality মিলছে না এমন ক্ষেত্রে fingerprint/flow-এর বিকল্প ক্রমে চেষ্টা করে; সফলটা মনে রাখে। */
    private fun buildCandidates(p: VlessProfile): List<VlessProfile> {
        val prefs = getSharedPreferences("vpn_variant", MODE_PRIVATE)
        val keyNow = variantKey(p)
        val savedFp = prefs.getString("fp", null)
        val savedFlow = prefs.getString("flow", null)
        val savedOk = prefs.getString("key", null) == keyNow
        val out = LinkedHashSet<Pair<String, String>>()
        if (savedOk && savedFp != null && savedFlow != null) out.add(savedFp to savedFlow)
        // 3x-ui সার্ভারে client flow = None, তাই ফাঁকা flow আগে; vision শেষ ভরসা হিসেবে।
        out.add(p.fingerprint to p.flow)
        out.add("chrome" to "")
        out.add("firefox" to "")
        out.add("ios" to "")
        out.add("chrome" to "xtls-rprx-vision")
        return out.map { (fp, flow) -> p.copy(fingerprint = fp, flow = flow) }
    }


    private class StartedEngine(val engine: SingBoxEngine, val probePort: Int, val fakeUsed: Boolean)

    private fun startEngineFor(cand: VlessProfile, mtu: Int, fakeDns: Boolean): StartedEngine {
        var fake = fakeDns
        while (true) {
            val probePort = SingBoxEngine.findFreeLocalPort()
            val json = ConfigManager(this).buildSingboxConfigJson(
                profile = cand,
                socksProbePort = probePort,
                fakeDns = fake,
                mtu = mtu
            )
            liveUpRateBytesPerSec.set(0L)
            liveDownRateBytesPerSec.set(0L)
            liveTotalUpBytes.set(0L)
            liveTotalDownBytes.set(0L)

            val engine = SingBoxEngine(this)
            singBoxEngine = engine
            try {
                engine.start(
                    configJson = json,
                    onTrafficStatus = { statusMsg ->
                        liveUpRateBytesPerSec.set(statusMsg.uplink)
                        liveDownRateBytesPerSec.set(statusMsg.downlink)
                        liveTotalUpBytes.set(statusMsg.uplinkTotal)
                        liveTotalDownBytes.set(statusMsg.downlinkTotal)
                    },
                    onLogMessage = { logLine ->
                        Log.d(TAG, "[sing-box] $logLine")
                        if (BuildConfig.DEBUG && !isNoisyCoreLine(logLine)) appendLog("[sing-box] $logLine")
                    },
                    onUnexpectedStop = { reason ->
                        if (singBoxEngine === engine && (_vpnStatus.value == VpnStatus.CONNECTED || _vpnStatus.value == VpnStatus.CONNECTING)) {
                            if (!reason.isNullOrBlank()) {
                                _lastErrorMessage.value = "Tunnel disconnected: $reason"
                            }
                            stopTunnel()
                        }
                    }
                )
                return StartedEngine(engine, probePort, fake)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                singBoxEngine = null
                try { engine.stop() } catch (_: Exception) {}
                if (fake) {
                    appendLog("[app] Fake-IP DNS rejected by core (${e.message?.take(120)}); retrying with standard DNS")
                    fake = false
                    continue
                }
                throw e
            }
        }
    }

    private fun isNoisyCoreLine(l: String): Boolean =
        l.contains("found user id") || l.contains("found package") || l.contains("inbound/tun") ||
            l.contains("outbound connection to") || l.contains("process DNS packet")

    private fun saveWorkingVariant(p: VlessProfile) {
        getSharedPreferences("vpn_variant", MODE_PRIVATE).edit()
            .putString("fp", p.fingerprint).putString("flow", p.flow).putString("key", variantKey(p)).apply()
    }

    private fun variantKey(p: VlessProfile) = "${p.address}:${p.port}|${p.uuid}|${p.publicKey}|${p.shortId}|${p.sni}"

    @Volatile
    private var lastHandshakeError: String? = null

    /** সার্ভার প্রোফাইলের স্পষ্ট ভুল (যেমন পোর্ট ৬৫৫৩৫-এর বেশি) আগেই ধরে সঠিক বার্তা দেয়। */
    private fun validateProfile(p: VlessProfile): String? {
        if (p.address.isBlank()) return "Server address is empty"
        if (p.port !in 1..65535) return "Invalid server port: ${p.port} (must be 1-65535)"
        if (!Regex("^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$").matches(p.uuid)) {
            return "Invalid UUID format"
        }
        if (p.security.equals("reality", ignoreCase = true)) {
            if (p.publicKey.length != 43) return "Invalid Reality public key (must be 43 characters)"
            if (!Regex("^[0-9a-fA-F]{0,16}$").matches(p.shortId)) return "Invalid Reality short ID (hex, max 16)"
            if (p.sni.isBlank()) return "Reality SNI is empty"
        }
        return null
    }

    private fun validateServerHandshake(profile: VlessProfile): Boolean {
        lastHandshakeError = null
        val socket = Socket()
        return try {
            if (!protect(socket)) {
                Log.w(TAG, "protect(handshakeSocket) returned false for ${profile.address}:${profile.port}")
            }
            val start = System.currentTimeMillis()
            socket.connect(InetSocketAddress(profile.address, profile.port), 4000)
            val latency = (System.currentTimeMillis() - start).toInt()
            if (latency > 0) _pingMs.value = latency
            true
        } catch (e: Exception) {
            lastHandshakeError = e.message ?: e.javaClass.simpleName
            false
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun stopTunnel() {
        _vpnStatus.value = VpnStatus.DISCONNECTING

        workerJob?.cancel()
        workerJob = null

        try {
            singBoxEngine?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping SingBoxEngine: ${e.message}")
        }
        singBoxEngine = null

        _vpnStatus.value = VpnStatus.DISCONNECTED
        _connectedProfile.value = null
        _verifiedExitIp.value = null
        _stats.value = TrafficStats()
        _pingMs.value = 0

        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        stopTunnel()
        serviceJob.cancel()
        if (currentInstance === this) {
            currentInstance = null
        }
        super.onDestroy()
    }

    private fun measurePing(host: String, port: Int): Int {
        return try {
            val start = System.currentTimeMillis()
            val socket = Socket()
            if (!protect(socket)) {
                Log.w(TAG, "protect(pingSocket) returned false for $host:$port")
            }
            socket.connect(InetSocketAddress(host, port), 2000)
            val latency = (System.currentTimeMillis() - start).toInt()
            socket.close()
            latency
        } catch (_: Exception) {
            -1
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SS VPN Tunnel Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live connection status for SS VPN"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = Intent(this, MyVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val pendingDisconnect = PendingIntent.getService(
            this,
            1,
            disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SS VPN")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_vpn)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", pendingDisconnect)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, createNotification(text))
        } catch (_: Exception) {}
    }

    companion object {
        private const val TAG = "MyVpnService"
        const val ACTION_CONNECT = "com.ss.vpn.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.ss.vpn.ACTION_DISCONNECT"
        const val EXTRA_CONFIG_JSON = "extra_config_json"

        const val CHANNEL_ID = "ss_vpn_status_channel"
        const val NOTIFICATION_ID = 2001

        private val _vpnStatus = MutableStateFlow(VpnStatus.DISCONNECTED)
        val vpnStatus = _vpnStatus.asStateFlow()

        private val _activeOutboundTag = MutableStateFlow("proxy")
        val activeOutboundTag = _activeOutboundTag.asStateFlow()

        private val _lastErrorMessage = MutableStateFlow<String?>(null)
        val lastErrorMessage = _lastErrorMessage.asStateFlow()

        private val _connectedProfile = MutableStateFlow<VlessProfile?>(null)
        val connectedProfile = _connectedProfile.asStateFlow()

        private val _stats = MutableStateFlow(TrafficStats())
        val stats = _stats.asStateFlow()

        private val _pingMs = MutableStateFlow(0)
        val pingMs = _pingMs.asStateFlow()

        private val _verifiedExitIp = MutableStateFlow<String?>(null)
        val verifiedExitIp = _verifiedExitIp.asStateFlow()

        private var sessionBonusSeconds: Long = 0L

        private val _logs = MutableStateFlow<List<String>>(emptyList())
        val logs = _logs.asStateFlow()

        @Synchronized
        fun appendLog(line: String) {
            val next = _logs.value + line
            _logs.value = if (next.size <= 600) next else {
                // পুরোনো sing-box নয়েজ আগে ফেলি; [app] লাইনগুলো (কোন attempt সফল/ব্যর্থ) যতটা সম্ভব রাখি।
                val keepApp = next.filter { it.startsWith("[app]") }.takeLast(150)
                val rest = next.filter { !it.startsWith("[app]") }.takeLast(450)
                (keepApp + rest)
            }
        }

        @Synchronized
        fun clearLogs() {
            _logs.value = emptyList()
        }

        @Volatile
        var currentInstance: MyVpnService? = null
            private set

        fun setOutboundTag(tag: String) {
            _activeOutboundTag.value = tag
        }

        fun addSessionBonus(seconds: Long) {
            sessionBonusSeconds += seconds
        }

        fun clearErrorMessage() {
            _lastErrorMessage.value = null
        }
    }
}
