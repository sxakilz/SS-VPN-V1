package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import com.example.core.MyVpnService
import com.example.ads.findActivity
import com.example.ui.components.InterstitialAdDialog
import com.example.ui.components.RewardedAdDialog
import com.example.ui.screens.ActivationKeyDialog
import com.example.ui.screens.FloatingNav
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DarkPal
import com.example.ui.theme.LightPal
import com.example.ui.theme.LocalPal
import com.example.ui.theme.MyApplicationTheme
import com.example.vpn.VlessProfile
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appConfigManager = RealityVpnApp.instance.appConfigManager
        // ইউরোপ/আমেরিকা ইত্যাদির সম্মতি (UMP/GDPR) নিয়ে তবেই অ্যাড লোড হয়
        com.example.ads.ConsentHelper.gather(this) { com.example.ads.AdManager.markConsentReady(this) }

        setContent {
            val dark by appConfigManager.isDark.collectAsState()
            DisposableEffect(dark) {
                val transparent = android.graphics.Color.TRANSPARENT
                enableEdgeToEdge(
                    statusBarStyle = if (dark) SystemBarStyle.dark(transparent)
                    else SystemBarStyle.light(transparent, transparent),
                    navigationBarStyle = if (dark) SystemBarStyle.dark(transparent)
                    else SystemBarStyle.light(transparent, transparent)
                )
                onDispose { }
            }
            MyApplicationTheme {
                MainAppContent(
                    appConfigManager = appConfigManager,
                    onStartVpnService = { profile -> startVpn(profile) },
                    onStopVpnService = { stopVpn() },
                    onOpenAdminActivity = {
                        startActivity(Intent(this, AdminDashboardActivity::class.java))
                    },
                    onToast = { msg ->
                        val duration = if (msg.length > 45) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
                        Toast.makeText(this, msg, duration).show()
                    }
                )
            }
        }
    }

    private fun startVpn(profile: VlessProfile) {
        val intent = Intent(this, MyVpnService::class.java).apply {
            action = MyVpnService.ACTION_CONNECT
            val json = JSONObject().apply {
                put("id", profile.id)
                put("remarks", profile.remarks)
                put("address", profile.address)
                put("port", profile.port)
                put("uuid", profile.uuid)
                put("flow", profile.flow)
                put("security", profile.security)
                put("sni", profile.sni)
                val fpOverride = RealityVpnApp.instance.appConfigManager.appControl.value.fingerprintOverride
                put("fingerprint", fpOverride.ifBlank { profile.fingerprint })
                put("packetEncoding", profile.packetEncoding)
                put("publicKey", profile.publicKey)
                put("shortId", profile.shortId)
            }
            putExtra(MyVpnService.EXTRA_CONFIG_JSON, json.toString())
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopVpn() {
        val intent = Intent(this, MyVpnService::class.java).apply {
            action = MyVpnService.ACTION_DISCONNECT
        }
        startService(intent)
    }
}

@Composable
fun MainAppContent(
    appConfigManager: com.example.data.AppConfigManager,
    onStartVpnService: (VlessProfile) -> Unit,
    onStopVpnService: () -> Unit,
    onOpenAdminActivity: () -> Unit,
    onToast: (String) -> Unit
) {
    val status by MyVpnService.vpnStatus.collectAsState()
    val trafficStats by MyVpnService.stats.collectAsState()
    val pingMs by MyVpnService.pingMs.collectAsState()
    val lastError by MyVpnService.lastErrorMessage.collectAsState()
    val currentProfile by appConfigManager.currentProfile.collectAsState()

    var showActivationDialog by remember { mutableStateOf(false) }
    var showLogsDialog by remember { mutableStateOf(false) }
    var showRewardedAdDialog by remember { mutableStateOf(false) }

    // Interstitial Ad Trigger state (5-second auto-skippable)
    var showInterstitialAd by remember { mutableStateOf(false) }
    var interstitialTitle by remember { mutableStateOf("Connecting to Secure Tunnel") }
    var onInterstitialComplete by remember { mutableStateOf<() -> Unit>({}) }

    // Pending profile to connect upon VPN permission grant
    var pendingProfileToConnect by remember { mutableStateOf<VlessProfile?>(null) }

    var visibleErrorBanner by remember { mutableStateOf<String?>(null) }

    val context = androidx.compose.ui.platform.LocalContext.current

    // Error toast + persistent untruncated banner observation
    LaunchedEffect(lastError) {
        lastError?.let { msg ->
            visibleErrorBanner = msg
            onToast(msg)
            MyVpnService.clearErrorMessage()
        }
    }

    LaunchedEffect(status) {
        if (status == com.example.vpn.VpnStatus.CONNECTED || status == com.example.vpn.VpnStatus.CONNECTING) {
            visibleErrorBanner = null
        }
    }

    fun isInternetAvailable(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            pendingProfileToConnect?.let { profile ->
                onStartVpnService(profile)
            }
        } else {
            onToast("VPN permission is required to route traffic through SS VPN")
        }
        pendingProfileToConnect = null
    }

    var pendingProfileAfterNotif by remember { mutableStateOf<VlessProfile?>(null) }

    fun proceedWithVpnPermission(profile: VlessProfile) {
        val prepareIntent = VpnService.prepare(context)
        if (prepareIntent != null) {
            pendingProfileToConnect = profile
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            onStartVpnService(profile)
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        pendingProfileAfterNotif?.let { profile ->
            proceedWithVpnPermission(profile)
        }
        pendingProfileAfterNotif = null
    }

    fun initiateConnection(profile: VlessProfile) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            pendingProfileAfterNotif = profile
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            proceedWithVpnPermission(profile)
        }
    }

    // Connect logic with physical pre-check & 5-second ad for free users
    fun handleConnect(profile: VlessProfile) {
        visibleErrorBanner = null
        if (!isInternetAvailable(context)) {
            val noNetMsg = "No Internet Connection"
            visibleErrorBanner = noNetMsg
            onToast(noNetMsg)
            return
        }

        val control = appConfigManager.appControl.value
        if (control.maintenanceMode) {
            visibleErrorBanner = control.maintenanceMessage
            onToast(control.maintenanceMessage)
            return
        }

        if (!appConfigManager.shouldShowInterstitial()) {
            initiateConnection(profile)
        } else {
            val act = context.findActivity()
            if (act == null) initiateConnection(profile)
            else com.example.ads.AdManager.showInterstitial(act) { initiateConnection(profile) }
        }
    }

    // Disconnect logic with 5-second ad for free users
    fun handleDisconnect() {
        if (!appConfigManager.shouldShowInterstitial()) {
            onStopVpnService()
        } else {
            val act = context.findActivity()
            if (act == null) onStopVpnService()
            else com.example.ads.AdManager.showInterstitial(act) { onStopVpnService() }
        }
    }

    val isDark by appConfigManager.isDark.collectAsState()
    val pal = if (isDark) DarkPal else LightPal
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val control by appConfigManager.appControl.collectAsState()

    CompositionLocalProvider(LocalPal provides pal) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(pal.bg)
    ) {
        if (tab == 0) {
            HomeScreen(
                status = status,
                stats = trafficStats,
                pingMs = pingMs,
                appConfigManager = appConfigManager,
                errorMessage = visibleErrorBanner,
                onDismissError = { visibleErrorBanner = null },
                onConnect = { handleConnect(currentProfile) },
                onDisconnect = { handleDisconnect() },
                onWatchRewarded = {
                    val act = context.findActivity()
                    val hrs = appConfigManager.appControl.value.rewardHours
                    if (act == null) {
                        onToast("Ad unavailable")
                    } else {
                        com.example.ads.AdManager.showRewarded(
                            act,
                            onReward = {
                                appConfigManager.stackTwoHoursAdFree()
                                MyVpnService.addSessionBonus(hrs * 3600L)
                                onToast("🎉 +$hrs Hours Ad-Free Added!")
                            },
                            onNotReady = { onToast("Ad is not ready yet. Try again in a moment.") }
                        )
                    }
                }
            )
        } else {
            SettingsScreen(
                status = status,
                appConfigManager = appConfigManager,
                onOpenActivation = { if (appConfigManager.adminSessionValid()) onOpenAdminActivity() else showActivationDialog = true },
                onOpenLogs = { showLogsDialog = true },
                onToast = onToast
            )
        }

        FloatingNav(
            selected = tab,
            onSelect = { tab = it },
            modifier = Modifier.align(Alignment.BottomCenter)
        )

        if (showLogsDialog) {
            com.example.ui.screens.LogsDialog(onDismiss = { showLogsDialog = false })
        }

        // Clean Activation Dialog (Strictly no demo buttons or admin hints)
        if (showActivationDialog) {
            ActivationKeyDialog(
                appConfigManager = appConfigManager,
                onDismiss = { showActivationDialog = false },
                onAdminUnlocked = {
                    showActivationDialog = false
                    onOpenAdminActivity()
                },
                onPremiumActivated = { days ->
                    showActivationDialog = false
                    onToast("🎉 Premium Activated: $days Days Remaining!")
                }
            )
        }

        // 30s Rewarded Ad with Stacking +2 Hours dynamically added to session & ad-free timer
        if (showRewardedAdDialog) {
            RewardedAdDialog(
                hours = control.rewardHours,
                onDismiss = { showRewardedAdDialog = false },
                onRewardGranted = {
                    appConfigManager.stackTwoHoursAdFree()
                    MyVpnService.addSessionBonus(control.rewardHours * 3600L)
                    onToast("🎉 +${control.rewardHours} Hours Ad-Free Added!")
                    showRewardedAdDialog = false
                }
            )
        }

        // 5-second Auto-Skippable Interstitial Ad on connect/disconnect
        if (showInterstitialAd) {
            InterstitialAdDialog(
                actionTitle = interstitialTitle,
                onAdCompleted = {
                    onInterstitialComplete()
                }
            )
        }
    }
    }

}
