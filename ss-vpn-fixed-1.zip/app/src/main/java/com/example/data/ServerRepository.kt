package com.example.data

import android.content.Context
import com.example.model.VlessConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

class ServerRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("reality_vpn_servers", Context.MODE_PRIVATE)

    private val _servers = MutableStateFlow<List<VlessConfig>>(emptyList())
    val servers: StateFlow<List<VlessConfig>> = _servers.asStateFlow()

    private val _selectedServer = MutableStateFlow<VlessConfig>(defaultServers.first())
    val selectedServer: StateFlow<VlessConfig> = _selectedServer.asStateFlow()

    init {
        loadServers()
    }

    private fun loadServers() {
        val savedJson = prefs.getString("custom_servers_json", null)
        val list = mutableListOf<VlessConfig>()
        list.addAll(defaultServers)

        if (!savedJson.isNullOrEmpty()) {
            try {
                val array = JSONArray(savedJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        VlessConfig(
                            id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                            remarks = obj.optString("remarks", "Custom Reality"),
                            address = obj.optString("address", ""),
                            port = obj.optInt("port", 443),
                            uuid = obj.optString("uuid", ""),
                            flow = obj.optString("flow", "xtls-rprx-vision"),
                            encryption = obj.optString("encryption", "none"),
                            networkType = obj.optString("networkType", "tcp"),
                            headerType = obj.optString("headerType", "none"),
                            security = obj.optString("security", "reality"),
                            sni = obj.optString("sni", ""),
                            fingerprint = obj.optString("fingerprint", "chrome"),
                            publicKey = obj.optString("publicKey", ""),
                            shortId = obj.optString("shortId", ""),
                            spiderX = obj.optString("spiderX", "/"),
                            isCustom = true
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        _servers.value = list
        val savedSelectedId = prefs.getString("selected_server_id", null)
        val selected = list.find { it.id == savedSelectedId } ?: list.first()
        _selectedServer.value = selected
    }

    private fun persistCustomServers() {
        val customOnly = _servers.value.filter { it.isCustom }
        val array = JSONArray()
        customOnly.forEach { s ->
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("remarks", s.remarks)
            obj.put("address", s.address)
            obj.put("port", s.port)
            obj.put("uuid", s.uuid)
            obj.put("flow", s.flow)
            obj.put("encryption", s.encryption)
            obj.put("networkType", s.networkType)
            obj.put("headerType", s.headerType)
            obj.put("security", s.security)
            obj.put("sni", s.sni)
            obj.put("fingerprint", s.fingerprint)
            obj.put("publicKey", s.publicKey)
            obj.put("shortId", s.shortId)
            obj.put("spiderX", s.spiderX)
            array.put(obj)
        }
        prefs.edit().putString("custom_servers_json", array.toString()).apply()
    }

    fun selectServer(server: VlessConfig) {
        _selectedServer.value = server
        prefs.edit().putString("selected_server_id", server.id).apply()
    }

    fun addServer(server: VlessConfig) {
        val updated = _servers.value.toMutableList()
        // Replace if already exists, else prepend
        val existingIndex = updated.indexOfFirst { it.id == server.id }
        if (existingIndex >= 0) {
            updated[existingIndex] = server
        } else {
            updated.add(0, server)
        }
        _servers.value = updated
        _selectedServer.value = server
        prefs.edit().putString("selected_server_id", server.id).apply()
        persistCustomServers()
    }

    fun deleteServer(server: VlessConfig) {
        if (!server.isCustom) return // Prevent deleting preset defaults
        val updated = _servers.value.filter { it.id != server.id }
        _servers.value = updated
        if (_selectedServer.value.id == server.id) {
            _selectedServer.value = updated.firstOrNull() ?: defaultServers.first()
        }
        persistCustomServers()
    }

    suspend fun pingServer(server: VlessConfig): Int = withContext(Dispatchers.IO) {
        try {
            val startTime = System.currentTimeMillis()
            val socket = Socket()
            socket.connect(InetSocketAddress(server.address, server.port), 2500)
            val latency = (System.currentTimeMillis() - startTime).toInt()
            socket.close()
            latency
        } catch (e: Exception) {
            -1
        }
    }

    suspend fun testAllServers() = withContext(Dispatchers.IO) {
        val currentList = _servers.value
        val testedList = currentList.map { server ->
            val latency = pingServer(server)
            server.copy(pingMs = latency)
        }
        _servers.value = testedList
        _selectedServer.value = testedList.find { it.id == _selectedServer.value.id } ?: testedList.first()
    }

    companion object {
        // শুধু আপনার আসল সার্ভার; ভুয়া/ডেমো সার্ভার সরানো হয়েছে
        val defaultServers = listOf(
            VlessConfig(
                id = "embedded-default-node",
                remarks = "SS VPN Server",
                address = "149.28.156.223",
                port = 47778,
                uuid = "9bea506a-6f3f-4e4c-8e5d-9473d70fba51",
                flow = "",
                security = "reality",
                sni = "dl.google.com",
                fingerprint = "chrome",
                publicKey = "8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg",
                shortId = "c1e22f0e",
                spiderX = "/",
                pingMs = 0,
                isCustom = false
            )
        )
    }
}
