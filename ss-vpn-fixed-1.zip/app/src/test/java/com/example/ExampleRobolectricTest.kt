package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.ConfigManager
import com.example.data.AppConfigManager
import com.example.data.KeyActivationResult
import com.example.vpn.VlessParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SS VPN", appName)
    }

    @Test
    fun `default vless reality parser test`() {
        val defaultLink = "vless://9bea506a-6f3f-4e4c-8e5d-9473d70fba51@149.28.156.223:47778?security=reality&encryption=none&pbk=8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg&headerType=none&fp=chrome&type=tcp&flow=xtls-rprx-vision&sid=c1e22f0e&sni=dl.google.com#SS%20VPN%20Server"
        val result = VlessParser.parse(defaultLink)
        assertTrue(result.isSuccess)
        val profile = result.getOrThrow()

        assertEquals("9bea506a-6f3f-4e4c-8e5d-9473d70fba51", profile.uuid)
        assertEquals("149.28.156.223", profile.address)
        assertEquals(47778, profile.port)
        assertEquals("reality", profile.security)
        assertEquals("8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg", profile.publicKey)
        assertEquals("c1e22f0e", profile.shortId)
        assertEquals("dl.google.com", profile.sni)
        assertEquals("chrome", profile.fingerprint)
        assertEquals("tcp", profile.networkType)
        assertEquals("xtls-rprx-vision", profile.flow)
        assertEquals("SS VPN Server", profile.remarks)

        val xrayJson = profile.toXrayJson()
        assertTrue(xrayJson.contains("149.28.156.223"))
        assertTrue(xrayJson.contains("47778"))
        assertTrue(xrayJson.contains("realitySettings"))
        assertTrue(xrayJson.contains("dl.google.com"))
    }

    @Test
    fun `singbox json config generation test`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val configManager = ConfigManager(context)
        val singboxJson = configManager.buildSingboxConfigJson()

        // Verify sing-box 1.12+ DNS resolution routing (zero DNS/IP leak via proxy + local bootstrap)
        assertTrue(singboxJson.contains("ipv4_only"))
        assertTrue(singboxJson.contains("google-dns"))
        assertTrue(singboxJson.contains("8.8.8.8"))
        assertTrue(singboxJson.contains("cloudflare-dns"))
        assertTrue(singboxJson.contains("1.1.1.1"))
        assertTrue(singboxJson.contains("local-dns"))
        assertTrue(singboxJson.contains("\"detour\": \"proxy\""))

        // Verify Tun Inbound (IPv4 172.19.0.1/30 + IPv6 fdfe:dcba:9876::1/126)
        assertTrue(singboxJson.contains("172.19.0.1/30"))
        assertTrue(singboxJson.contains("fdfe:dcba:9876::1/126"))
        assertTrue(singboxJson.contains("tun-in"))

        // Verify Outbound VLESS Reality Proxy
        assertTrue(singboxJson.contains("149.28.156.223"))
        assertTrue(singboxJson.contains("47778"))
        assertTrue(singboxJson.contains("dl.google.com"))
        assertTrue(singboxJson.contains("9bea506a-6f3f-4e4c-8e5d-9473d70fba51"))
        assertTrue(singboxJson.contains("8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg"))
        assertTrue(singboxJson.contains("c1e22f0e"))
        assertTrue(singboxJson.contains("xtls-rprx-vision"))
        assertTrue(singboxJson.contains("xudp"))

        // Verify Anti-Leak Route Rules (final: proxy + hijack-dns + tun-in scoped sniff) and Reality connect_timeout
        assertTrue(singboxJson.contains("\"connect_timeout\": \"10s\""))
        assertTrue(singboxJson.contains("\"independent_cache\": true"))
        assertTrue(singboxJson.contains("\"final\": \"proxy\""))
        assertTrue(singboxJson.contains("\"auto_detect_interface\": true"))
        assertTrue(singboxJson.contains("\"action\": \"hijack-dns\""))
        assertTrue(singboxJson.contains("\"action\": \"sniff\""))
        val routeRules = org.json.JSONObject(singboxJson).getJSONObject("route").getJSONArray("rules")
        val sniffRule = routeRules.getJSONObject(0)
        assertEquals("sniff", sniffRule.getString("action"))
        assertEquals("tun-in", sniffRule.getJSONArray("inbound").getString(0))
        val port53Rule = routeRules.getJSONObject(2)
        assertEquals("hijack-dns", port53Rule.getString("action"))
        assertEquals(53, port53Rule.getInt("port"))
        assertEquals("tun-in", port53Rule.getJSONArray("inbound").getString(0))
    }

    @Test
    fun `secret admin key and device binding security test`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AppConfigManager(context)

        // 1. অ্যাডমিন কী হ্যাশ করে সংরক্ষণ হয়; নতুন কী সেট করে যাচাই
        assertTrue(manager.updateSecretAdminKey("test-admin-key-123"))
        val adminRes = manager.activateKey("test-admin-key-123")
        assertTrue(adminRes is KeyActivationResult.AdminUnlocked)
        // ভুল কী প্রত্যাখ্যাত হয়
        assertTrue(manager.activateKey("shakilxd71") is KeyActivationResult.Error)

        // 2. Generate a 1-Month key
        val generatedKey = manager.generatePremiumKey(30)
        assertTrue(generatedKey.startsWith("SS-30D-"))

        // 3. Activate on current device -> should bind and succeed
        val activateRes = manager.activateKey(generatedKey)
        assertTrue(activateRes is KeyActivationResult.PremiumActivated)
        assertTrue(manager.isPremium.value)

        // 4. Test Stacking +2 hours ad-free bonus
        val beforeAdFree = manager.getRemainingAdFreeSeconds()
        manager.stackTwoHoursAdFree()
        val afterAdFree = manager.getRemainingAdFreeSeconds()
        assertTrue(afterAdFree >= beforeAdFree + 7100L)
    }

    @Test
    fun `tun packet engine ip checksum and utilities test`() {
        // Test IP formatting
        val ipBytes = byteArrayOf(172.toByte(), 19.toByte(), 0.toByte(), 1.toByte())
        assertEquals("172.19.0.1", com.example.core.TunPacketEngine.formatIp(ipBytes))

        // Test IPv4 checksum calculation on synthetic header
        val header = ByteArray(20)
        header[0] = 0x45.toByte()
        header[1] = 0x00.toByte()
        com.example.core.TunPacketEngine.writeShort(header, 2, 40)
        com.example.core.TunPacketEngine.writeShort(header, 4, 1234)
        com.example.core.TunPacketEngine.writeShort(header, 6, 0x4000)
        header[8] = 64.toByte()
        header[9] = 6.toByte() // TCP
        System.arraycopy(ipBytes, 0, header, 12, 4)
        val dstIp = byteArrayOf(8.toByte(), 8.toByte(), 8.toByte(), 8.toByte())
        System.arraycopy(dstIp, 0, header, 16, 4)

        val checksum = com.example.core.TunPacketEngine.computeChecksum(header, 0, 20)
        assertTrue(checksum in 1..65535)

        // Test TCP pseudo-header checksum
        val tcpPacket = ByteArray(20)
        com.example.core.TunPacketEngine.writeShort(tcpPacket, 0, 12345) // srcPort
        com.example.core.TunPacketEngine.writeShort(tcpPacket, 2, 80) // dstPort
        com.example.core.TunPacketEngine.writeInt(tcpPacket, 4, 1000L) // seq
        com.example.core.TunPacketEngine.writeInt(tcpPacket, 8, 2000L) // ack
        tcpPacket[12] = 0x50.toByte() // data offset 5 (20 bytes)
        tcpPacket[13] = 0x02.toByte() // SYN
        com.example.core.TunPacketEngine.writeShort(tcpPacket, 14, 65535) // window

        val tcpChecksum = com.example.core.TunPacketEngine.computeTcpChecksum(ipBytes, dstIp, tcpPacket, 0, 20)
        assertTrue(tcpChecksum in 1..65535)
    }

    @Test
    fun `vpn traffic leak automated diagnosis detects direct route fallback`() {
        // Construct leaking Sing-box config where route final is set to direct
        val leakingJson = """
        {
          "inbounds": [{"type": "tun", "tag": "tun-in", "inet4_address": "172.19.0.1/30", "auto_route": true}],
          "outbounds": [
            {
              "type": "vless",
              "tag": "proxy",
              "server": "149.28.156.223",
              "server_port": 47778,
              "uuid": "9bea506a-6f3f-4e4c-8e5d-9473d70fba51",
              "tls": {
                "server_name": "dl.google.com",
                "reality": {
                  "public_key": "8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg",
                  "short_id": "c1e22f0e"
                }
              }
            },
            {"type": "direct", "tag": "direct"}
          ],
          "route": {
            "final": "direct"
          }
        }
        """.trimIndent()

        val audit = com.example.core.VpnLeakDiagnostic.runAudit(leakingJson)
        assertEquals(false, audit.isZeroLeakGuaranteed)
        assertEquals("DIAGNOSTIC ERROR: Route fallback is set to DIRECT instead of PROXY", audit.errorStatusSummary)

        val routeFallbackFinding = audit.findings.find { it.category == "ROUTE_FALLBACK" }
        assertTrue(routeFallbackFinding != null)
        assertEquals(com.example.core.VpnLeakDiagnostic.Severity.ERROR, routeFallbackFinding?.severity)
    }

    @Test
    fun `vpn dynamic json auto fix patcher repairs route and enforces proxy`() {
        val brokenJson = """
        {
          "route": { "final": "direct" }
        }
        """.trimIndent()

        val fixResult = com.example.core.VpnLeakDiagnostic.applyAutoFix(brokenJson)
        assertTrue(fixResult.success)
        assertTrue(fixResult.patchedJson.contains("\"final\": \"proxy\""))
        assertTrue(fixResult.patchedJson.contains("149.28.156.223"))
        assertTrue(fixResult.patchedJson.contains("47778"))
        assertTrue(fixResult.patchedJson.contains("9bea506a-6f3f-4e4c-8e5d-9473d70fba51"))
        assertTrue(fixResult.patchedJson.contains("8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg"))
        assertTrue(fixResult.patchedJson.contains("c1e22f0e"))

        // Re-audit patched JSON
        val reAudit = com.example.core.VpnLeakDiagnostic.runAudit(fixResult.patchedJson)
        assertTrue(reAudit.isZeroLeakGuaranteed)
        assertEquals(null, reAudit.errorStatusSummary)
    }

    @Test
    fun `default singbox configuration zero leak test`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val configManager = ConfigManager(context)
        val defaultJson = configManager.buildSingboxConfigJson()

        val report = configManager.auditCurrentConfig(defaultJson)
        assertTrue(report.isZeroLeakGuaranteed)
        assertEquals(null, report.errorStatusSummary)
        assertTrue(report.logLines.any { it.contains("ZERO-LEAK STATUS") })
    }

    @Test
    fun `diagnostic detects direct bypass engine instead of sing-box core`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val configManager = ConfigManager(context)
        val defaultJson = configManager.buildSingboxConfigJson()

        val audit = com.example.core.VpnLeakDiagnostic.runAudit(
            configJson = defaultJson,
            activeProfile = ConfigManager.DEFAULT_PROFILE,
            isVpnActive = true,
            activeOutboundTag = "proxy",
            coreEngineType = "tun-packet-engine"
        )
        assertEquals(false, audit.isZeroLeakGuaranteed)
        assertTrue(audit.errorStatusSummary?.contains("Bypass engine") == true)
        assertTrue(audit.findings.any { it.category == "CORE_ENGINE" })
    }

    @Test
    fun `live traffic stats report zero when idle without synthetic noise`() {
        val idleStats = com.example.core.SingBoxEngine.calculateLiveTrafficStats(
            uplinkBytesPerSec = 0L,
            downlinkBytesPerSec = 0L,
            totalUploadBytes = 0L,
            totalDownloadBytes = 0L,
            durationSeconds = 12L
        )
        assertEquals(0f, idleStats.uploadSpeedKbps, 0.001f)
        assertEquals(0f, idleStats.downloadSpeedKbps, 0.001f)
        assertEquals(0L, idleStats.totalUploadBytes)
        assertEquals(0L, idleStats.totalDownloadBytes)
        assertEquals(12L, idleStats.durationSeconds)

        val activeStats = com.example.core.SingBoxEngine.calculateLiveTrafficStats(
            uplinkBytesPerSec = 1024L,
            downlinkBytesPerSec = 2048L,
            totalUploadBytes = 4096L,
            totalDownloadBytes = 8192L,
            durationSeconds = 20L
        )
        assertEquals(8f, activeStats.uploadSpeedKbps, 0.001f)
        assertEquals(16f, activeStats.downloadSpeedKbps, 0.001f)
        assertEquals(4096L, activeStats.totalUploadBytes)
        assertEquals(8192L, activeStats.totalDownloadBytes)
    }

    @Test
    fun `libbox classes packaged on classpath`() {
        val platformIface = Class.forName("io.nekohasekai.libbox.PlatformInterface", false, javaClass.classLoader)
        val cmdServer = Class.forName("io.nekohasekai.libbox.CommandServer", false, javaClass.classLoader)
        assertTrue(platformIface.isInterface)
        assertEquals("CommandServer", cmdServer.simpleName)
    }

    @Test
    fun `singbox config includes gvisor stack, tcp dns, and optional socks probe`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val configManager = ConfigManager(context)
        val probeConfig = configManager.buildSingboxConfigJson(socksProbePort = 18080)

        assertTrue(probeConfig.contains("\"stack\": \"gvisor\""))
        assertTrue(probeConfig.contains("\"type\": \"tcp\""))
        assertTrue(probeConfig.contains("\"tag\": \"socks-probe\""))
        assertTrue(probeConfig.contains("\"listen\": \"127.0.0.1\""))
        assertTrue(probeConfig.contains("\"listen_port\": 18080"))
    }

    @Test
    fun `socks5 connect encoder and exit ip parsers work cleanly`() {
        val req = com.example.core.SingBoxEngine.buildSocks5ConnectRequest("connectivitycheck.gstatic.com", 443)
        assertEquals(0x05.toByte(), req[0])
        assertEquals(0x01.toByte(), req[1])
        assertEquals(0x03.toByte(), req[3])
        assertEquals("connectivitycheck.gstatic.com".length.toByte(), req[4])
        assertEquals(0x01.toByte(), req[req.size - 2]) // 443 high byte
        assertEquals(0xBB.toByte(), req[req.size - 1]) // 443 low byte

        // Default HTTPS probe targets use connectivitycheck.gstatic.com and ifconfig.me (never 1.1.1.1)
        val targets = com.example.core.SingBoxEngine.DEFAULT_PROBE_TARGETS
        assertEquals(2, targets.size)
        assertEquals("https://connectivitycheck.gstatic.com/generate_204", targets[0].urlString)
        assertEquals("https://ifconfig.me/ip", targets[1].urlString)
        assertTrue(targets.none { it.host == "1.1.1.1" })

        val ifconfigResponse = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n149.28.156.223\n"
        assertEquals("149.28.156.223", com.example.core.SingBoxEngine.parseExitIpFromResponse(ifconfigResponse))

        val trace = """
            HTTP/1.1 200 OK

            fl=21f108
            h=example
            ip=149.28.156.223
        """.trimIndent()
        assertEquals("149.28.156.223", com.example.core.SingBoxEngine.parseExitIpFromResponse(trace))
    }

    @Test
    fun `verifyEndToEndTunnel reports sandbox preview block vs real device upstream EOF with core logs`() {
        val server = java.net.ServerSocket(0, 10, java.net.InetAddress.getByName("127.0.0.1"))
        val worker = Thread {
            while (!server.isClosed) {
                try {
                    val client = server.accept()
                    val inp = client.getInputStream()
                    val out = client.getOutputStream()
                    // Read SOCKS5 greeting
                    val greeting = ByteArray(3)
                    inp.read(greeting)
                    out.write(byteArrayOf(0x05, 0x00))
                    out.flush()
                    // Read SOCKS5 CONNECT header + domain
                    val head = ByteArray(64)
                    inp.read(head)
                    out.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 127, 0, 0, 1, 0, 443.and(0xFF).toByte()))
                    out.flush()
                    // Close immediately after receiving HTTP GET (simulating upstream Reality EOF)
                    inp.read(ByteArray(256))
                    client.close()
                } catch (_: Exception) {
                    break
                }
            }
        }.apply { isDaemon = true; start() }

        try {
            // 1. Inside emulator/AI Studio preview sandbox -> reports ENVIRONMENT_SANDBOX_BLOCKED
            val sandboxRes = com.example.core.SingBoxEngine.verifyEndToEndTunnel(
                socksPort = server.localPort,
                timeoutMs = 1500,
                coreLogProvider = { emptyList() },
                isEmulatorEnvironment = true,
                tlsSocketWrapper = { sock, _, _, _ -> sock }
            )
            assertEquals(false, sandboxRes.success)
            assertEquals(
                com.example.core.SingBoxEngine.TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED,
                sandboxRes.failureStage
            )
            assertTrue(sandboxRes.errorDetail!!.contains("Sandbox/Emulator preview"))
            assertTrue(!sandboxRes.errorDetail!!.contains("1.1.1.1"))

            // 2. On real device with core error log -> surfaces UPSTREAM_REALITY_EOF + core log hint + tested host details
            val deviceRes = com.example.core.SingBoxEngine.verifyEndToEndTunnel(
                socksPort = server.localPort,
                timeoutMs = 1500,
                coreLogProvider = { listOf("ERROR outbound/vless[proxy]: tls: handshake failure") },
                isEmulatorEnvironment = false,
                tlsSocketWrapper = { sock, _, _, _ -> sock }
            )
            assertEquals(false, deviceRes.success)
            assertEquals(
                com.example.core.SingBoxEngine.TunnelFailureStage.UPSTREAM_REALITY_EOF,
                deviceRes.failureStage
            )
            assertTrue(deviceRes.errorDetail!!.contains("Upstream VLESS Reality tunnel closed"))
            assertTrue(deviceRes.errorDetail!!.contains("connectivitycheck.gstatic.com"))
            assertTrue(deviceRes.errorDetail!!.contains("ifconfig.me"))
            assertTrue(deviceRes.errorDetail!!.contains("tls: handshake failure"))
        } finally {
            server.close()
            worker.interrupt()
        }
    }

    @Test
    fun `verifyEndToEndTunnel reports HTTP read timeout and falls back from gstatic to ifconfig me`() {
        val timeoutServer = java.net.ServerSocket(0, 10, java.net.InetAddress.getByName("127.0.0.1"))
        val timeoutWorker = Thread {
            while (!timeoutServer.isClosed) {
                try {
                    val client = timeoutServer.accept()
                    Thread {
                        try {
                            val inp = client.getInputStream()
                            val out = client.getOutputStream()
                            inp.read(ByteArray(3))
                            out.write(byteArrayOf(0x05, 0x00))
                            out.flush()
                            inp.read(ByteArray(64))
                            out.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 127, 0, 0, 1, 0x01, 0xBB.toByte()))
                            out.flush()
                            Thread.sleep(600)
                            client.close()
                        } catch (_: Exception) {}
                    }.apply { isDaemon = true; start() }
                } catch (_: Exception) {
                    break
                }
            }
        }.apply { isDaemon = true; start() }

        // Mock server where first target (connectivitycheck.gstatic.com) closes with 0 bytes,
        // and fallback target (ifconfig.me) succeeds with 200 OK + exit IP 149.28.156.223.
        val fallbackServer = java.net.ServerSocket(0, 10, java.net.InetAddress.getByName("127.0.0.1"))
        val fallbackWorker = Thread {
            while (!fallbackServer.isClosed) {
                try {
                    val client = fallbackServer.accept()
                    Thread {
                        try {
                            val inp = client.getInputStream()
                            val out = client.getOutputStream()
                            inp.read(ByteArray(3))
                            out.write(byteArrayOf(0x05, 0x00))
                            out.flush()
                            val connectReq = ByteArray(128)
                            val connectLen = inp.read(connectReq)
                            val requestedHost = if (connectLen > 5) {
                                val domainLen = connectReq[4].toInt() and 0xFF
                                String(connectReq, 5, minOf(domainLen, connectLen - 5), Charsets.UTF_8)
                            } else {
                                ""
                            }
                            out.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 127, 0, 0, 1, 0x01, 0xBB.toByte()))
                            out.flush()
                            inp.read(ByteArray(512))
                            if (requestedHost == "ifconfig.me") {
                                val httpResp = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 15\r\n\r\n149.28.156.223\n"
                                out.write(httpResp.toByteArray(Charsets.US_ASCII))
                                out.flush()
                            }
                            client.close()
                        } catch (_: Exception) {}
                    }.apply { isDaemon = true; start() }
                } catch (_: Exception) {
                    break
                }
            }
        }.apply { isDaemon = true; start() }

        try {
            val timeoutRes = com.example.core.SingBoxEngine.verifyEndToEndTunnel(
                socksPort = timeoutServer.localPort,
                timeoutMs = 250,
                coreLogProvider = { emptyList() },
                isEmulatorEnvironment = false,
                tlsSocketWrapper = { sock, _, _, _ -> sock }
            )
            assertEquals(false, timeoutRes.success)
            assertEquals(
                com.example.core.SingBoxEngine.TunnelFailureStage.HTTP_READ_TIMEOUT,
                timeoutRes.failureStage
            )
            assertTrue(timeoutRes.errorDetail!!.contains("Timed out waiting for HTTPS response"))
            assertTrue(timeoutRes.errorDetail!!.contains("connectivitycheck.gstatic.com"))
            assertTrue(timeoutRes.errorDetail!!.contains("ifconfig.me"))

            val fallbackRes = com.example.core.SingBoxEngine.verifyEndToEndTunnel(
                socksPort = fallbackServer.localPort,
                timeoutMs = 1500,
                isEmulatorEnvironment = false,
                tlsSocketWrapper = { sock, _, _, _ -> sock }
            )
            assertTrue(fallbackRes.success)
            assertEquals("149.28.156.223", fallbackRes.exitIp)
            assertTrue(fallbackRes.latencyMs >= 1)
        } finally {
            timeoutServer.close()
            fallbackServer.close()
            timeoutWorker.interrupt()
            fallbackWorker.interrupt()
        }
    }

    @Test
    fun `verifyEndToEndTunnel protects probe sockets and recovers on transient warmup EOF`() {
        val attemptCounter = java.util.concurrent.atomic.AtomicInteger(0)
        val warmupServer = java.net.ServerSocket(0, 10, java.net.InetAddress.getByName("127.0.0.1"))
        val warmupWorker = Thread {
            while (!warmupServer.isClosed) {
                try {
                    val client = warmupServer.accept()
                    Thread {
                        try {
                            val inp = client.getInputStream()
                            val out = client.getOutputStream()
                            inp.read(ByteArray(3))
                            out.write(byteArrayOf(0x05, 0x00))
                            out.flush()
                            inp.read(ByteArray(128))
                            out.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 127, 0, 0, 1, 0x01, 0xBB.toByte()))
                            out.flush()
                            inp.read(ByteArray(512))
                            val currentAttempt = attemptCounter.incrementAndGet()
                            if (currentAttempt == 1) {
                                // First attempt closes with 0 bytes (simulating cold-start Reality EOF)
                                client.close()
                            } else {
                                // Second attempt succeeds cleanly
                                val httpResp = "HTTP/1.1 204 No Content\r\nContent-Length: 0\r\n\r\n"
                                out.write(httpResp.toByteArray(Charsets.US_ASCII))
                                out.flush()
                                client.close()
                            }
                        } catch (_: Exception) {}
                    }.apply { isDaemon = true; start() }
                } catch (_: Exception) {
                    break
                }
            }
        }.apply { isDaemon = true; start() }

        try {
            val protectedCount = java.util.concurrent.atomic.AtomicInteger(0)
            var protectedBeforeConnect = true
            val res = com.example.core.SingBoxEngine.verifyEndToEndTunnel(
                socksPort = warmupServer.localPort,
                timeoutMs = 1500,
                isEmulatorEnvironment = false,
                socketProtector = { sock ->
                    if (sock.isConnected) {
                        protectedBeforeConnect = false
                    }
                    protectedCount.incrementAndGet()
                    true
                },
                tlsSocketWrapper = { sock, _, _, _ -> sock }
            )

            assertTrue(res.success)
            assertTrue(res.latencyMs >= 1)
            assertTrue(protectedBeforeConnect)
            assertTrue("Expected at least 2 protected probe sockets, got ${protectedCount.get()}", protectedCount.get() >= 2)
        } finally {
            warmupServer.close()
            warmupWorker.interrupt()
        }
    }

    @Test
    fun `detectEmulatorEnvironment identifies cloud emulators without false positives on real devices`() {
        // Cloud / QEMU / Cuttlefish emulator markers
        assertTrue(
            com.example.core.SingBoxEngine.detectEmulatorEnvironment(
                fingerprint = "google/sdk_gphone64_x86_64/emu64x:15/AP31/123:userdebug/dev-keys",
                model = "sdk_gphone64_x86_64",
                manufacturer = "Google",
                brand = "google",
                device = "emu64x",
                hardware = "ranchu",
                product = "sdk_gphone64_x86_64",
                qemuProperty = "1"
            )
        )
        assertTrue(
            com.example.core.SingBoxEngine.detectEmulatorEnvironment(
                fingerprint = "aosp/aosp_cf_x86_64_phone/vsoc_x86_64:14/AP2A/123:userdebug/test-keys",
                model = "Cuttlefish x86_64 phone",
                manufacturer = "Google",
                brand = "aosp",
                device = "cutf_cvm",
                hardware = "cutf_cvm",
                product = "aosp_cf_x86_64_phone",
                qemuProperty = ""
            )
        )
        assertTrue(
            com.example.core.SingBoxEngine.detectEmulatorEnvironment(
                fingerprint = "generic/aosp/generic:14/UQ1A/123:user/release-keys",
                model = "Android Device",
                manufacturer = "Unknown",
                brand = "generic",
                device = "generic",
                hardware = "goldfish",
                product = "aosp",
                qemuProperty = "1"
            )
        )

        // Real physical hardware (Pixel & Samsung Galaxy) must NOT be misclassified
        assertEquals(
            false,
            com.example.core.SingBoxEngine.detectEmulatorEnvironment(
                fingerprint = "google/shiba/shiba:15/AP3A.241105.007/12470370:user/release-keys",
                model = "Pixel 8",
                manufacturer = "Google",
                brand = "google",
                device = "shiba",
                hardware = "shiba",
                product = "shiba",
                qemuProperty = "0"
            )
        )
        assertEquals(
            false,
            com.example.core.SingBoxEngine.detectEmulatorEnvironment(
                fingerprint = "samsung/e1qxxx/e1q:14/UP1A.231005.007/S921BXXU3AXH7:user/release-keys",
                model = "SM-S921B",
                manufacturer = "samsung",
                brand = "samsung",
                device = "e1q",
                hardware = "qcom",
                product = "e1qxxx",
                qemuProperty = "",
                characteristicsProperty = "default"
            )
        )
        assertTrue(
            com.example.core.SingBoxEngine.detectEmulatorEnvironment(
                fingerprint = "google/test/test:15/AP3A/123:user/release-keys",
                model = "Device",
                manufacturer = "Google",
                brand = "google",
                device = "dev",
                hardware = "dev",
                product = "dev",
                qemuProperty = "",
                characteristicsProperty = "emulator"
            )
        )
        assertTrue(
            com.example.core.SingBoxEngine.extractRelevantCoreError(
                listOf("INFO outbound started", "WARN router: broken pipe on reality stream")
            )?.contains("broken pipe") == true
        )
    }

    @Test
    fun `extractRelevantCoreError prioritizes ERROR and FATAL over later WARN or closed lines`() {
        val logs = listOf(
            "ERROR outbound/vless[proxy]: missing default interface",
            "INFO router: connection finished",
            "WARN socks: closed before handshake completed"
        )
        val picked = com.example.core.SingBoxEngine.extractRelevantCoreError(logs)
        assertTrue(picked?.contains("missing default interface") == true)
    }

    @Test
    fun `verifyEndToEndTunnel recovers on transient SOCKS5 rep=1 retry and surfaces core error on persistent rep=1`() {
        val transientAttempts = java.util.concurrent.atomic.AtomicInteger(0)
        val transientServer = java.net.ServerSocket(0, 10, java.net.InetAddress.getByName("127.0.0.1"))
        val transientWorker = Thread {
            while (!transientServer.isClosed) {
                try {
                    val client = transientServer.accept()
                    Thread {
                        try {
                            val inp = client.getInputStream()
                            val out = client.getOutputStream()
                            inp.read(ByteArray(3))
                            out.write(byteArrayOf(0x05, 0x00))
                            out.flush()
                            inp.read(ByteArray(128))
                            val attempt = transientAttempts.incrementAndGet()
                            if (attempt == 1) {
                                // First attempt fails with rep=1 (General SOCKS server failure)
                                out.write(byteArrayOf(0x05, 0x01, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                                out.flush()
                                client.close()
                            } else {
                                // Retry succeeds cleanly
                                out.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 127, 0, 0, 1, 0x01, 0xBB.toByte()))
                                out.flush()
                                inp.read(ByteArray(512))
                                val httpResp = "HTTP/1.1 204 No Content\r\nContent-Length: 0\r\n\r\n"
                                out.write(httpResp.toByteArray(Charsets.US_ASCII))
                                out.flush()
                                client.close()
                            }
                        } catch (_: Exception) {}
                    }.apply { isDaemon = true; start() }
                } catch (_: Exception) {
                    break
                }
            }
        }.apply { isDaemon = true; start() }

        val persistentRejectServer = java.net.ServerSocket(0, 10, java.net.InetAddress.getByName("127.0.0.1"))
        val persistentWorker = Thread {
            while (!persistentRejectServer.isClosed) {
                try {
                    val client = persistentRejectServer.accept()
                    Thread {
                        try {
                            val inp = client.getInputStream()
                            val out = client.getOutputStream()
                            inp.read(ByteArray(3))
                            out.write(byteArrayOf(0x05, 0x00))
                            out.flush()
                            inp.read(ByteArray(128))
                            out.write(byteArrayOf(0x05, 0x01, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                            out.flush()
                            client.close()
                        } catch (_: Exception) {}
                    }.apply { isDaemon = true; start() }
                } catch (_: Exception) {
                    break
                }
            }
        }.apply { isDaemon = true; start() }

        try {
            // 1. Transient rep=1 recovers on retry
            val recovered = com.example.core.SingBoxEngine.verifyEndToEndTunnel(
                socksPort = transientServer.localPort,
                timeoutMs = 1500,
                isEmulatorEnvironment = false,
                tlsSocketWrapper = { sock, _, _, _ -> sock }
            )
            assertTrue(recovered.success)
            assertEquals(2, transientAttempts.get())

            // 2. Persistent rep=1 on real device puts [core: ...] first so Toast/UI truncation never hides it
            val deviceFailure = com.example.core.SingBoxEngine.verifyEndToEndTunnel(
                socksPort = persistentRejectServer.localPort,
                timeoutMs = 1500,
                coreLogProvider = { listOf("ERROR outbound/vless[proxy]: missing default interface") },
                isEmulatorEnvironment = false,
                tlsSocketWrapper = { sock, _, _, _ -> sock }
            )
            assertEquals(false, deviceFailure.success)
            assertEquals(
                com.example.core.SingBoxEngine.TunnelFailureStage.SOCKS5_HANDSHAKE_FAILED,
                deviceFailure.failureStage
            )
            assertTrue(deviceFailure.errorDetail!!.startsWith("[core: ERROR outbound/vless[proxy]: missing default interface]"))
            assertTrue(deviceFailure.errorDetail!!.contains("SOCKS5 CONNECT rejected (rep=1)"))

            // 3. Persistent rep=1 in emulator sandbox with no core logs classifies as ENVIRONMENT_SANDBOX_BLOCKED
            val sandboxFailure = com.example.core.SingBoxEngine.verifyEndToEndTunnel(
                socksPort = persistentRejectServer.localPort,
                timeoutMs = 1500,
                coreLogProvider = { emptyList() },
                isEmulatorEnvironment = true,
                tlsSocketWrapper = { sock, _, _, _ -> sock }
            )
            assertEquals(false, sandboxFailure.success)
            assertEquals(
                com.example.core.SingBoxEngine.TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED,
                sandboxFailure.failureStage
            )
            assertTrue(sandboxFailure.errorDetail!!.contains("Sandbox/Emulator preview"))
        } finally {
            transientServer.close()
            persistentRejectServer.close()
            transientWorker.interrupt()
            persistentWorker.interrupt()
        }
    }
}
