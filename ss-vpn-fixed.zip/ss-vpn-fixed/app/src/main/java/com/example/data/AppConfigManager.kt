package com.example.data

import android.content.Context
import android.provider.Settings
import com.example.vpn.VlessParser
import com.example.vpn.VlessProfile
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

sealed class KeyActivationResult {
    data object AdminUnlocked : KeyActivationResult()
    data class PremiumActivated(val daysLeft: Int) : KeyActivationResult()
    data class Error(val message: String) : KeyActivationResult()
}

data class PremiumKeyData(
    val key: String,
    val days: Int = 30,
    val boundDeviceId: String? = null,
    val activatedAt: Long = 0L,
    val expiresAt: Long = 0L,
    val isRevoked: Boolean = false
)

data class AdMobConfig(
    val bannerId: String = "",
    val interstitialId: String = "",
    val rewardedId: String = ""
)

/** অ্যাডমিন প্যানেল থেকে নিয়ন্ত্রিত অ্যাপ সেটিংস। */
/** অ্যাডমিনের সংরক্ষিত সার্ভার তালিকার একটি এন্ট্রি (vless:// লিংকসহ)। */
data class AdminServer(
    val id: String,
    val name: String,
    val uri: String,
    val enabled: Boolean = true
)

data class AppControl(
    val adsEnabled: Boolean = true,
    val bannerEnabled: Boolean = true,
    val interstitialEnabled: Boolean = true,
    val rewardedEnabled: Boolean = true,
    val rewardHours: Int = 2,
    val maintenanceMode: Boolean = false,
    val maintenanceMessage: String = "Service is under maintenance. Please try again later.",
    val announcement: String = "",
    val fingerprintOverride: String = "",
    // ব্র্যান্ডিং
    val appName: String = "SS VPN",
    val homeHeadline: String = "Secure. Private. Fast.",
    val launcherPreset: Int = 0,
    // সোশ্যাল লিংক (শুধু http/https)
    val facebookUrl: String = "",
    val youtubeUrl: String = "",
    val instagramUrl: String = "",
    val telegramUrl: String = "",
    // আপডেট
    val latestVersion: String = "",
    val updateUrl: String = ""
)

/** শুধু নিরাপদ http/https লিংক গ্রহণ করে (intent:, javascript:, file: ইত্যাদি বাতিল)। */
fun sanitizeUrl(raw: String): String {
    val t = raw.trim().take(300)
    if (t.isEmpty()) return ""
    val lower = t.lowercase()
    return if (lower.startsWith("https://") || lower.startsWith("http://")) t else ""
}

class AppConfigManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("ss_vpn_config", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.IO)

    // Hardware Android_ID for 1 Key = 1 Device binding
    val currentDeviceId: String = try {
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "UNKNOWN_DEV"
    } catch (e: Exception) {
        "UNKNOWN_DEV"
    }

    // Default configuration values
    // অ্যাডমিন কী সোর্সে প্লেইনটেক্সটে নেই — শুধু salt$PBKDF2-হ্যাশ। (ডিফল্ট কী আলাদাভাবে জানানো হয়েছে)
    private val defaultAdminHash = "737376706e2d61646d696e2d73616c742d7631$1fbdc782bfbd3a90aaaac81e2f12e8f84ba51cb316339aa9282b50b76e9341b3"
    private val validFingerprints = setOf("", "chrome", "firefox", "safari", "ios", "android", "edge", "random", "randomized")
    private val defaultVlessUri = "vless://9bea506a-6f3f-4e4c-8e5d-9473d70fba51@149.28.156.223:47778?security=reality&encryption=none&pbk=8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg&headerType=none&fp=chrome&type=tcp&sid=c1e22f0e&sni=ai.android#SS%20VPN%20Server"

    // StateFlows
    private val _appControl = MutableStateFlow(AppControl())
    val appControl: StateFlow<AppControl> = _appControl.asStateFlow()

    private val _isDark = MutableStateFlow(true)
    val isDark: StateFlow<Boolean> = _isDark.asStateFlow()
    private val _reduceMotion = MutableStateFlow(false)
    val reduceMotion: StateFlow<Boolean> = _reduceMotion.asStateFlow()
    // লোগো পরিবর্তনের সংস্করণ (0 = কাস্টম লোগো নেই)
    private val _logoVersion = MutableStateFlow(0)
    val logoVersion: StateFlow<Int> = _logoVersion.asStateFlow()

    fun setDark(v: Boolean) { _isDark.value = v; prefs.edit().putBoolean("ui_dark", v).apply() }
    fun setReduceMotion(v: Boolean) { _reduceMotion.value = v; prefs.edit().putBoolean("ui_reduce_motion", v).apply() }

    /** অ্যাডমিন নির্বাচিত ছবি PNG হিসেবে (সর্বোচ্চ ৫১২px) সংরক্ষণ করে। সফল হলে true। */
    fun saveLogo(bitmap: android.graphics.Bitmap?): Boolean {
        if (bitmap == null) return false
        return try {
            val max = 512
            val scale = minOf(1f, max.toFloat() / maxOf(bitmap.width, bitmap.height))
            val out = if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(
                bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true
            ) else bitmap
            java.io.File(context.filesDir, "brand_logo.png").outputStream().use {
                out.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
            }
            _logoVersion.value = _logoVersion.value + 1
            logAdminAction("Custom logo updated")
            true
        } catch (e: Exception) { false }
    }

    fun clearLogo() {
        java.io.File(context.filesDir, "brand_logo.png").delete()
        _logoVersion.value = 0
        logAdminAction("Custom logo removed")
    }

    fun loadLogo(): android.graphics.Bitmap? = try {
        val f = java.io.File(context.filesDir, "brand_logo.png")
        if (f.exists()) android.graphics.BitmapFactory.decodeFile(f.absolutePath) else null
    } catch (e: Exception) { null }

    private val _adminServers = MutableStateFlow<List<AdminServer>>(emptyList())
    val adminServers: StateFlow<List<AdminServer>> = _adminServers.asStateFlow()

    private val _adminAudit = MutableStateFlow<List<String>>(emptyList())
    val adminAudit: StateFlow<List<String>> = _adminAudit.asStateFlow()

    private val _activeVlessLink = MutableStateFlow(defaultVlessUri)
    val activeVlessLink: StateFlow<String> = _activeVlessLink.asStateFlow()

    private val _currentProfile = MutableStateFlow(VlessProfile.DEFAULT)
    val currentProfile: StateFlow<VlessProfile> = _currentProfile.asStateFlow()

    private val _syncStatus = MutableStateFlow("Cloud sync: starting…")
    /** ক্লাউড (Firestore) সিঙ্কের সর্বশেষ অবস্থা — অ্যাডমিন প্যানেলে দেখানো হয়। */
    val syncStatus: StateFlow<String> = _syncStatus.asStateFlow()

    private fun syncOk(what: String) { _syncStatus.value = "Cloud sync OK ($what) • " + java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date()) }
    private fun syncFail(what: String, t: Throwable?) {
        val m = (t?.message ?: "unknown").take(160)
        val hint = if (m.contains("PERMISSION_DENIED", true)) " — Admin cloud login required (Admin → Ads → Cloud sync)" else ""
        _syncStatus.value = "Cloud sync FAILED ($what): $m$hint"
    }

    private fun currentCloudAdmin(): String? = try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.email } catch (_: Throwable) { null }
    private val _cloudAdminEmail = MutableStateFlow<String?>(currentCloudAdmin())
    /** Firebase Auth-এ সাইন-ইন করা অ্যাডমিনের ইমেইল (null = সাইন-ইন নেই; তখন ক্লাউডে লেখা যায় না)। */
    val cloudAdminEmail: StateFlow<String?> = _cloudAdminEmail.asStateFlow()

    fun cloudSignIn(email: String, password: String, onResult: (String?) -> Unit) {
        try {
            com.google.firebase.auth.FirebaseAuth.getInstance()
                .signInWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener {
                    _cloudAdminEmail.value = it.user?.email
                    syncOk("admin signed in")
                    onResult(null)
                }
                .addOnFailureListener { onResult(it.message ?: "Sign-in failed") }
        } catch (t: Throwable) { onResult(t.message ?: "Firebase not configured") }
    }

    fun cloudSignOut() {
        try { com.google.firebase.auth.FirebaseAuth.getInstance().signOut() } catch (_: Throwable) { }
        _cloudAdminEmail.value = null
    }

    private val _adMobConfig = MutableStateFlow(AdMobConfig())
    val adMobConfig: StateFlow<AdMobConfig> = _adMobConfig.asStateFlow()

    private val _isPremium = MutableStateFlow(false)
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    private val _premiumExpiresAt = MutableStateFlow(0L)
    val premiumExpiresAt: StateFlow<Long> = _premiumExpiresAt.asStateFlow()

    private val _activeKey = MutableStateFlow("")
    val activeKey: StateFlow<String> = _activeKey.asStateFlow()

    private val _adFreeUntil = MutableStateFlow(0L)
    val adFreeUntil: StateFlow<Long> = _adFreeUntil.asStateFlow()

    private val _keysList = MutableStateFlow<List<PremiumKeyData>>(emptyList())
    val keysList: StateFlow<List<PremiumKeyData>> = _keysList.asStateFlow()

    init {
        loadLocalConfig()
        syncWithFirestore()
    }

    private fun loadLocalConfig() {
        // পুরনো প্লেইনটেক্সট অ্যাডমিন কী (যদি আগের ভার্সনে সেভ হয়ে থাকে) মুছে ফেলা
        if (prefs.contains("secret_admin_key")) prefs.edit().remove("secret_admin_key").apply()
        _appControl.value = AppControl(
            adsEnabled = prefs.getBoolean("ctl_ads", true),
            bannerEnabled = prefs.getBoolean("ctl_banner", true),
            interstitialEnabled = prefs.getBoolean("ctl_interstitial", true),
            rewardedEnabled = prefs.getBoolean("ctl_rewarded", true),
            rewardHours = prefs.getInt("ctl_reward_hours", 2).coerceIn(1, 24),
            maintenanceMode = prefs.getBoolean("ctl_maint", false),
            maintenanceMessage = prefs.getString("ctl_maint_msg", null) ?: AppControl().maintenanceMessage,
            announcement = prefs.getString("ctl_announce", "") ?: "",
            fingerprintOverride = (prefs.getString("ctl_fp", "") ?: "").takeIf { it in validFingerprints } ?: "",
            appName = (prefs.getString("ctl_app_name", null) ?: "SS VPN").take(30),
            homeHeadline = (prefs.getString("ctl_headline", null) ?: "Secure. Private. Fast.").take(60),
            launcherPreset = prefs.getInt("ctl_launcher", 0).coerceIn(0, 2),
            facebookUrl = sanitizeUrl(prefs.getString("ctl_fb", "") ?: ""),
            youtubeUrl = sanitizeUrl(prefs.getString("ctl_yt", "") ?: ""),
            instagramUrl = sanitizeUrl(prefs.getString("ctl_ig", "") ?: ""),
            telegramUrl = sanitizeUrl(prefs.getString("ctl_tg", "") ?: ""),
            latestVersion = (prefs.getString("ctl_latest", "") ?: "").take(20),
            updateUrl = sanitizeUrl(prefs.getString("ctl_update_url", "") ?: "")
        )
        _isDark.value = prefs.getBoolean("ui_dark", true)
        _reduceMotion.value = prefs.getBoolean("ui_reduce_motion", false)
        _logoVersion.value = if (java.io.File(context.filesDir, "brand_logo.png").exists()) 1 else 0
        _adminAudit.value = (prefs.getString("admin_audit", "") ?: "").split("\n").filter { it.isNotBlank() }
        // এমবেড করা সার্ভারই ডিফল্ট। শুধু এই ডিভাইসে অ্যাডমিন নিজে লিংক বদলালেই সেভ করা লিংক ব্যবহার হবে;
        // আগের পুরনো/ভুল সেভ করা বা Firebase থেকে আসা লিংক আর নিঃশব্দে প্রোফাইল বদলাতে পারবে না।
        // এমবেড করা সার্ভার-তথ্য নতুন (UUID বদলেছে) — পুরোনো সংরক্ষিত ওভাররাইড/তালিকা একবার মুছে নতুনটা ধরানো হয়।
        if (prefs.getInt("embedded_ver", 0) < 5) {
            prefs.edit()
                .putBoolean("vless_user_override", false)
                .remove("active_vless_uri")
                .remove("admin_servers_json")
                .remove("admob_banner").remove("admob_interstitial").remove("admob_rewarded")
                .putInt("embedded_ver", 5)
                .apply()
        }
        val userOverride = prefs.getBoolean("vless_user_override", false)
        val savedVless = if (userOverride) {
            prefs.getString("active_vless_uri", defaultVlessUri) ?: defaultVlessUri
        } else {
            defaultVlessUri
        }
        _activeVlessLink.value = savedVless
        val parsed = VlessParser.parse(savedVless).getOrDefault(VlessProfile.DEFAULT)
        _currentProfile.value = parsed
        loadAdminServers()

        _adMobConfig.value = AdMobConfig(
            bannerId = prefs.getString("admob_banner", "") ?: "",
            interstitialId = prefs.getString("admob_interstitial", "") ?: "",
            rewardedId = prefs.getString("admob_rewarded", "") ?: ""
        )

        // Check user premium state
        val premium = prefs.getBoolean("is_premium", false)
        val expiry = prefs.getLong("premium_expires_at", 0L)
        val now = System.currentTimeMillis()
        if (premium && expiry > now) {
            _isPremium.value = true
            _premiumExpiresAt.value = expiry
            _activeKey.value = prefs.getString("active_key", "") ?: ""
        } else {
            _isPremium.value = false
            _premiumExpiresAt.value = 0L
        }

        val adFree = prefs.getLong("ad_free_until", 0L)
        _adFreeUntil.value = if (adFree > now) adFree else 0L

        loadKeysRegistry()
    }

    private fun loadKeysRegistry() {
        val json = prefs.getString("keys_registry_json", null)
        val list = mutableListOf<PremiumKeyData>()
        if (!json.isNullOrEmpty()) {
            try {
                val array = JSONArray(json)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        PremiumKeyData(
                            key = obj.getString("key"),
                            days = obj.optInt("days", 30),
                            boundDeviceId = if (obj.has("boundDeviceId") && !obj.isNull("boundDeviceId")) obj.getString("boundDeviceId") else null,
                            activatedAt = obj.optLong("activatedAt", 0L),
                            expiresAt = obj.optLong("expiresAt", 0L),
                            isRevoked = obj.optBoolean("isRevoked", false)
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        _keysList.value = list
    }

    private fun saveKeysRegistry(list: List<PremiumKeyData>) {
        val array = JSONArray()
        list.forEach { k ->
            val obj = JSONObject()
            obj.put("key", k.key)
            obj.put("days", k.days)
            obj.put("boundDeviceId", k.boundDeviceId)
            obj.put("activatedAt", k.activatedAt)
            obj.put("expiresAt", k.expiresAt)
            obj.put("isRevoked", k.isRevoked)
            array.put(obj)
        }
        prefs.edit().putString("keys_registry_json", array.toString()).apply()
        _keysList.value = list
    }

    private fun syncWithFirestore() {
        scope.launch {
            try {
                val db = FirebaseFirestore.getInstance()
                // Sync remote server link
                db.collection("config").document("server")
                    .addSnapshotListener { doc, err ->
                        if (err != null || doc == null) { syncFail("server", err); return@addSnapshotListener }
                        syncOk("server")
                        val remoteVless = doc.getString("vlessLink")
                        // রিমোট লিংক শুধু সংরক্ষণ হয়, স্বয়ংক্রিয়ভাবে প্রয়োগ হয় না — ভুল/পুরনো Reality কী
                        // থাকলে "reality verification failed" হয়ে সব সংযোগ ব্যর্থ হতো।
                        if (!remoteVless.isNullOrEmpty()) {
                            prefs.edit().putString("remote_vless_uri", remoteVless).apply()
                            // অ্যাডমিন স্পষ্টভাবে "সব ইউজারকে পাঠান" দিলে (publishToAll) এবং এই ডিভাইসে
                            // লোকাল ওভাররাইড না থাকলে তবেই রিমোট সার্ভার প্রয়োগ হয়।
                            if (doc.getBoolean("publishToAll") == true &&
                                !prefs.getBoolean("vless_user_override", false)
                            ) {
                                VlessParser.parse(remoteVless).onSuccess { p ->
                                    _activeVlessLink.value = remoteVless.trim()
                                    _currentProfile.value = p
                                }
                            }
                        }
                    }

                // অ্যাডমিন কী কখনোই Firestore থেকে নামানো/তোলা হয় না (নিরাপত্তা)।
                // অ্যাপ কন্ট্রোল (বিজ্ঞাপন সুইচ, মেইনটেন্যান্স ইত্যাদি) পুল:
                db.collection("config").document("app")
                    .addSnapshotListener { doc, err ->
                        if (err != null || doc == null) { syncFail("app", err); return@addSnapshotListener }
                        syncOk("app settings")
                        if (doc.exists()) {
                            val cur = _appControl.value
                            val fp = (doc.getString("fingerprintOverride") ?: cur.fingerprintOverride)
                                .takeIf { it in validFingerprints } ?: cur.fingerprintOverride
                            applyControl(
                                cur.copy(
                                    adsEnabled = doc.getBoolean("adsEnabled") ?: cur.adsEnabled,
                                    bannerEnabled = doc.getBoolean("bannerEnabled") ?: cur.bannerEnabled,
                                    interstitialEnabled = doc.getBoolean("interstitialEnabled") ?: cur.interstitialEnabled,
                                    rewardedEnabled = doc.getBoolean("rewardedEnabled") ?: cur.rewardedEnabled,
                                    rewardHours = (doc.getLong("rewardHours")?.toInt() ?: cur.rewardHours).coerceIn(1, 24),
                                    maintenanceMode = doc.getBoolean("maintenanceMode") ?: cur.maintenanceMode,
                                    maintenanceMessage = (doc.getString("maintenanceMessage") ?: cur.maintenanceMessage).take(200),
                                    announcement = (doc.getString("announcement") ?: cur.announcement).take(200),
                                    fingerprintOverride = fp,
                                    appName = (doc.getString("appName") ?: cur.appName).take(30).ifBlank { cur.appName },
                                    homeHeadline = (doc.getString("homeHeadline") ?: cur.homeHeadline).take(60),
                                    launcherPreset = cur.launcherPreset,
                                    facebookUrl = sanitizeUrl(doc.getString("facebookUrl") ?: cur.facebookUrl),
                                    youtubeUrl = sanitizeUrl(doc.getString("youtubeUrl") ?: cur.youtubeUrl),
                                    instagramUrl = sanitizeUrl(doc.getString("instagramUrl") ?: cur.instagramUrl),
                                    telegramUrl = sanitizeUrl(doc.getString("telegramUrl") ?: cur.telegramUrl),
                                    latestVersion = (doc.getString("latestVersion") ?: cur.latestVersion).take(20),
                                    updateUrl = sanitizeUrl(doc.getString("updateUrl") ?: cur.updateUrl)
                                ),
                                push = false
                            )
                        }
                    }

                // Sync remote ad IDs
                db.collection("config").document("ads")
                    .addSnapshotListener { doc, err ->
                        if (err != null || doc == null) { syncFail("ads", err); return@addSnapshotListener }
                        syncOk("ads")
                        val banner = doc.getString("bannerId")
                        val interstitial = doc.getString("interstitialId")
                        val rewarded = doc.getString("rewardedId")
                        if (banner != null || interstitial != null || rewarded != null) {
                            val updated = AdMobConfig(
                                bannerId = banner ?: _adMobConfig.value.bannerId,
                                interstitialId = interstitial ?: _adMobConfig.value.interstitialId,
                                rewardedId = rewarded ?: _adMobConfig.value.rewardedId
                            )
                            if (updated != _adMobConfig.value) {
                                _adMobConfig.value = updated
                                prefs.edit().putString("admob_banner", updated.bannerId)
                                    .putString("admob_interstitial", updated.interstitialId)
                                    .putString("admob_rewarded", updated.rewardedId).apply()
                                try { com.example.ads.AdManager.onIdsChanged() } catch (_: Throwable) { }
                            }
                        }
                    }
            } catch (e: Throwable) {
                // Firebase কনফিগার করা নেই (google-services.json নেই) হলে এখানে আসে
                syncFail("setup", e)
            }
        }
    }

    /**
     * Requirement 4 & 5: Validates key, checks Secret Admin Key, and enforces 1 Key = 1 Device hardware binding.
     */
    fun activateKey(rawInput: String): KeyActivationResult {
        val input = rawInput.trim()
        if (input.isEmpty()) {
            return KeyActivationResult.Error("Please enter an activation key.")
        }

        // 0. ব্রুট-ফোর্স সুরক্ষা: ৫ বার ভুলের পর ক্রমবর্ধমান সময়ের জন্য লক
        val lockedUntil = prefs.getLong("act_lock_until", 0L)
        val nowMs = System.currentTimeMillis()
        if (lockedUntil > nowMs) {
            val secs = ((lockedUntil - nowMs) / 1000L).coerceAtLeast(1L)
            return KeyActivationResult.Error("Too many failed attempts. Try again in ${secs}s.")
        }

        // 1. Secret Admin Key verification (হ্যাশ তুলনা)
        if (verifyAdminKey(input)) {
            prefs.edit().putInt("act_fail", 0).putLong("act_lock_until", 0L).apply()
            logAdminAction("Admin console unlocked")
            return KeyActivationResult.AdminUnlocked
        }

        // 2. Premium Key Verification & Device Binding Security
        val registry = _keysList.value.toMutableList()
        val keyData = registry.find { it.key.equals(input, ignoreCase = true) }

        if (keyData == null) {
            val fails = prefs.getInt("act_fail", 0) + 1
            val editor = prefs.edit().putInt("act_fail", fails)
            if (fails >= 5) {
                val lockSecs = minOf(900L, 30L * (1L shl minOf(fails - 5, 5)))
                editor.putLong("act_lock_until", System.currentTimeMillis() + lockSecs * 1000L)
            }
            editor.apply()
            return KeyActivationResult.Error("Invalid or expired activation key.")
        }
        prefs.edit().putInt("act_fail", 0).apply()

        if (keyData.isRevoked) {
            return KeyActivationResult.Error("This activation key has been revoked.")
        }

        // Device Binding Check (1 Key = 1 Device Only)
        if (keyData.boundDeviceId != null && keyData.boundDeviceId != currentDeviceId) {
            return KeyActivationResult.Error("Key already activated on another device!")
        }

        // Activate and bind to this device
        val now = System.currentTimeMillis()
        val expiry = if (keyData.expiresAt > now) keyData.expiresAt else now + (keyData.days.toLong() * 24 * 3600 * 1000L)
        val updatedKey = keyData.copy(
            boundDeviceId = currentDeviceId,
            activatedAt = if (keyData.activatedAt > 0) keyData.activatedAt else now,
            expiresAt = expiry
        )

        val index = registry.indexOfFirst { it.key == keyData.key }
        if (index >= 0) registry[index] = updatedKey
        saveKeysRegistry(registry)

        // Save local premium state
        _isPremium.value = true
        _premiumExpiresAt.value = expiry
        _activeKey.value = input

        prefs.edit()
            .putBoolean("is_premium", true)
            .putLong("premium_expires_at", expiry)
            .putString("active_key", input)
            .apply()

        // Sync binding to Firestore
        scope.launch {
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("keys").document(input).set(
                    mapOf(
                        "key" to input,
                        "boundDeviceId" to currentDeviceId,
                        "activatedAt" to now,
                        "expiresAt" to expiry,
                        "isRevoked" to false
                    )
                )
            } catch (e: Exception) {
                // Fallback saved locally
            }
        }

        val daysLeft = getRemainingPremiumDays()
        return KeyActivationResult.PremiumActivated(daysLeft)
    }

    /**
     * Requirement 6: Stacking +2 hours ad-free access each time watched.
     */
    fun stackTwoHoursAdFree() {
        val now = System.currentTimeMillis()
        val current = _adFreeUntil.value
        val base = if (current > now) current else now
        val newExpiry = base + (_appControl.value.rewardHours.toLong() * 60 * 60 * 1000L)
        _adFreeUntil.value = newExpiry
        prefs.edit().putLong("ad_free_until", newExpiry).apply()
    }

    fun isAdFreeActive(): Boolean {
        if (_isPremium.value && _premiumExpiresAt.value > System.currentTimeMillis()) {
            return true
        }
        return _adFreeUntil.value > System.currentTimeMillis()
    }

    fun getRemainingAdFreeSeconds(): Long {
        val diff = _adFreeUntil.value - System.currentTimeMillis()
        return (diff / 1000L).coerceAtLeast(0L)
    }

    fun getRemainingPremiumDays(): Int {
        val diff = _premiumExpiresAt.value - System.currentTimeMillis()
        if (diff <= 0) return 0
        return ((diff / (1000L * 60 * 60 * 24)) + 1).toInt()
    }

    // Admin Operations
    private fun pbkdf2Hex(input: String, saltHex: String): String {
        val salt = saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        val spec = javax.crypto.spec.PBEKeySpec(input.toCharArray(), salt, 60000, 256)
        val bytes = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun verifyAdminKey(input: String): Boolean {
        val stored = prefs.getString("admin_key_hash", null) ?: defaultAdminHash
        val parts = stored.split("$")
        if (parts.size != 2) return false
        return try {
            val calc = pbkdf2Hex(input, parts[0])
            java.security.MessageDigest.isEqual(calc.toByteArray(), parts[1].toByteArray())
        } catch (e: Exception) {
            false
        }
    }

    /** নতুন অ্যাডমিন কী (কমপক্ষে ১২ অক্ষর) হ্যাশ করে সংরক্ষণ করে। সফল হলে true। */
    fun updateSecretAdminKey(newKey: String): Boolean {
        val trimmed = newKey.trim()
        if (trimmed.length < 12) return false
        val saltBytes = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
        val saltHex = saltBytes.joinToString("") { "%02x".format(it) }
        val hash = pbkdf2Hex(trimmed, saltHex)
        prefs.edit().putString("admin_key_hash", "$saltHex$$hash").apply()
        logAdminAction("Admin key changed")
        return true
    }

    // ---------- অ্যাডমিন অডিট লগ ----------
    fun logAdminAction(text: String) {
        val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date())
        val list = (listOf("$stamp  $text") + _adminAudit.value).take(50)
        _adminAudit.value = list
        prefs.edit().putString("admin_audit", list.joinToString("\n")).apply()
    }

    fun clearAdminAudit() {
        _adminAudit.value = emptyList()
        prefs.edit().remove("admin_audit").apply()
    }

    // ---------- অ্যাপ কন্ট্রোল (বিজ্ঞাপন, মেইনটেন্যান্স, ঘোষণা, ফিঙ্গারপ্রিন্ট) ----------
    private fun applyControl(c: AppControl, push: Boolean) {
        _appControl.value = c
        prefs.edit()
            .putBoolean("ctl_ads", c.adsEnabled)
            .putBoolean("ctl_banner", c.bannerEnabled)
            .putBoolean("ctl_interstitial", c.interstitialEnabled)
            .putBoolean("ctl_rewarded", c.rewardedEnabled)
            .putInt("ctl_reward_hours", c.rewardHours)
            .putBoolean("ctl_maint", c.maintenanceMode)
            .putString("ctl_maint_msg", c.maintenanceMessage)
            .putString("ctl_announce", c.announcement)
            .putString("ctl_fp", c.fingerprintOverride)
            .putString("ctl_app_name", c.appName)
            .putString("ctl_headline", c.homeHeadline)
            .putInt("ctl_launcher", c.launcherPreset)
            .putString("ctl_fb", c.facebookUrl)
            .putString("ctl_yt", c.youtubeUrl)
            .putString("ctl_ig", c.instagramUrl)
            .putString("ctl_tg", c.telegramUrl)
            .putString("ctl_latest", c.latestVersion)
            .putString("ctl_update_url", c.updateUrl)
            .apply()
        if (push) {
            scope.launch {
                try {
                    FirebaseFirestore.getInstance().collection("config").document("app").set(
                        mapOf(
                            "adsEnabled" to c.adsEnabled,
                            "bannerEnabled" to c.bannerEnabled,
                            "interstitialEnabled" to c.interstitialEnabled,
                            "rewardedEnabled" to c.rewardedEnabled,
                            "rewardHours" to c.rewardHours,
                            "maintenanceMode" to c.maintenanceMode,
                            "maintenanceMessage" to c.maintenanceMessage,
                            "announcement" to c.announcement,
                            "fingerprintOverride" to c.fingerprintOverride,
                            "appName" to c.appName,
                            "homeHeadline" to c.homeHeadline,
                            "facebookUrl" to c.facebookUrl,
                            "youtubeUrl" to c.youtubeUrl,
                            "instagramUrl" to c.instagramUrl,
                            "telegramUrl" to c.telegramUrl,
                            "latestVersion" to c.latestVersion,
                            "updateUrl" to c.updateUrl
                        )
                    ).addOnSuccessListener { syncOk("pushed settings") }
                        .addOnFailureListener { syncFail("push settings", it) }
                } catch (e: Throwable) { syncFail("push settings", e) }
            }
        }
    }

    fun updateAppControl(label: String, transform: (AppControl) -> AppControl) {
        val next = transform(_appControl.value).let {
            it.copy(
                rewardHours = it.rewardHours.coerceIn(1, 24),
                maintenanceMessage = it.maintenanceMessage.take(200),
                announcement = it.announcement.take(200),
                fingerprintOverride = it.fingerprintOverride.takeIf { fp -> fp in validFingerprints } ?: "",
                appName = it.appName.trim().take(30).ifBlank { "SS VPN" },
                homeHeadline = it.homeHeadline.trim().take(60),
                launcherPreset = it.launcherPreset.coerceIn(0, 2),
                facebookUrl = sanitizeUrl(it.facebookUrl),
                youtubeUrl = sanitizeUrl(it.youtubeUrl),
                instagramUrl = sanitizeUrl(it.instagramUrl),
                telegramUrl = sanitizeUrl(it.telegramUrl),
                latestVersion = it.latestVersion.trim().take(20),
                updateUrl = sanitizeUrl(it.updateUrl)
            )
        }
        applyControl(next, push = true)
        logAdminAction(label)
    }

    /** লঞ্চার আইডেন্টিটি প্রিসেট (০=ডিফল্ট, ১=Shield, ২=Night) চালু করে; নতুনটি আগে enable করা হয়। */
    fun applyLauncherPreset(preset: Int) {
        try {
            val pm = context.packageManager
            val names = listOf("LauncherDefault", "LauncherShield", "LauncherNight")
            val target = preset.coerceIn(0, names.size - 1)
            pm.setComponentEnabledSetting(
                android.content.ComponentName(context.packageName, "com.example.${names[target]}"),
                android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                android.content.pm.PackageManager.DONT_KILL_APP
            )
            names.forEachIndexed { i, n ->
                if (i != target) {
                    pm.setComponentEnabledSetting(
                        android.content.ComponentName(context.packageName, "com.example.$n"),
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                }
            }
        } catch (e: Exception) { }
    }

    fun bannerAllowed(): Boolean = _appControl.value.let { it.adsEnabled && it.bannerEnabled } && _adMobConfig.value.bannerId.isNotBlank()
    fun interstitialAllowed(): Boolean = _appControl.value.let { it.adsEnabled && it.interstitialEnabled } && _adMobConfig.value.interstitialId.isNotBlank()
    fun rewardedAllowed(): Boolean = _appControl.value.let { it.adsEnabled && it.rewardedEnabled } && _adMobConfig.value.rewardedId.isNotBlank()
    fun shouldShowInterstitial(): Boolean = interstitialAllowed() && !isAdFreeActive()

    // ---------- লাইসেন্স কী ব্যবস্থাপনা ----------
    fun deleteKey(key: String) {
        saveKeysRegistry(_keysList.value.filterNot { it.key.equals(key, ignoreCase = true) })
        logAdminAction("Deleted key $key")
        scope.launch {
            try {
                FirebaseFirestore.getInstance().collection("keys").document(key).delete()
            } catch (e: Exception) { }
        }
    }

    fun unbindKeyDevice(key: String) {
        saveKeysRegistry(_keysList.value.map {
            if (it.key.equals(key, ignoreCase = true)) it.copy(boundDeviceId = null) else it
        })
        logAdminAction("Unbound device from key $key")
        scope.launch {
            try {
                FirebaseFirestore.getInstance().collection("keys").document(key).update("boundDeviceId", null)
            } catch (e: Exception) { }
        }
    }

    fun deleteRevokedKeys(): Int {
        val before = _keysList.value
        val after = before.filterNot { it.isRevoked }
        saveKeysRegistry(after)
        val n = before.size - after.size
        if (n > 0) logAdminAction("Deleted $n revoked keys")
        return n
    }

    // ---------- ইঞ্জিন সেটিংস (বিল্ড ছাড়াই পরিবর্তনযোগ্য) ----------
    fun engineDnsMode(): String = prefs.getString("eng_dns", "fakeip") ?: "fakeip"
    fun engineMtu(): Int = prefs.getInt("eng_mtu", 1400).coerceIn(1280, 1500)
    fun engineAutoFallback(): Boolean = prefs.getBoolean("eng_fallback", true)
    fun setEngineDnsMode(mode: String) {
        prefs.edit().putString("eng_dns", if (mode == "standard") "standard" else "fakeip").apply()
        logAdminAction("DNS mode -> $mode")
    }
    fun setEngineMtu(mtu: Int) {
        prefs.edit().putInt("eng_mtu", mtu.coerceIn(1280, 1500)).apply()
        logAdminAction("MTU -> $mtu")
    }
    fun setEngineAutoFallback(on: Boolean) {
        prefs.edit().putBoolean("eng_fallback", on).apply()
        logAdminAction("Auto fallback -> $on")
    }

    // ---------- অ্যাডমিন সার্ভার তালিকা (বিল্ড ছাড়াই সার্ভার যোগ/বন্ধ/মুছা/বাছাই) ----------

    private fun loadAdminServers() {
        val list = mutableListOf<AdminServer>()
        try {
            val arr = JSONArray(prefs.getString("admin_servers_json", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val uri = o.optString("uri", "")
                if (VlessParser.parse(uri).isSuccess) {
                    list.add(AdminServer(o.optString("id", UUID.randomUUID().toString()), o.optString("name", "Server").take(40), uri, o.optBoolean("enabled", true)))
                }
            }
        } catch (_: Exception) { }
        if (list.isEmpty()) {
            list.add(AdminServer("builtin", "SS VPN (built-in)", defaultVlessUri, true))
        }
        _adminServers.value = list
    }

    private fun saveAdminServers(list: List<AdminServer>) {
        _adminServers.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("uri", it.uri).put("enabled", it.enabled))
        }
        prefs.edit().putString("admin_servers_json", arr.toString()).apply()
    }

    /** লিংক থেকে নতুন সার্ভার যোগ করে। ভুল হলে এরর বার্তা ফেরত দেয়, সফল হলে null। */
    fun addAdminServer(name: String, link: String): String? {
        val parsed = VlessParser.parse(link.trim())
        if (parsed.isFailure) return parsed.exceptionOrNull()?.message ?: "Invalid VLESS link"
        val p = parsed.getOrThrow()
        val label = name.trim().ifBlank { p.remarks.ifBlank { p.address } }.take(40)
        saveAdminServers(_adminServers.value + AdminServer(UUID.randomUUID().toString(), label, link.trim(), true))
        logAdminAction("Added server '$label'")
        return null
    }

    fun deleteAdminServer(id: String): String? {
        val cur = _adminServers.value
        val target = cur.find { it.id == id } ?: return null
        if (cur.size <= 1) return "At least one server must remain"
        val rest = cur.filter { it.id != id }
        saveAdminServers(rest)
        if (_activeVlessLink.value == target.uri) {
            rest.firstOrNull { it.enabled }?.let { applyActiveLink(it.uri, publish = false) }
        }
        logAdminAction("Deleted server '${target.name}'")
        return null
    }

    fun setAdminServerEnabled(id: String, enabled: Boolean): String? {
        val cur = _adminServers.value
        val target = cur.find { it.id == id } ?: return null
        if (!enabled && cur.count { it.enabled } <= 1 && target.enabled) return "At least one server must stay ON"
        val updated = cur.map { if (it.id == id) it.copy(enabled = enabled) else it }
        saveAdminServers(updated)
        if (!enabled && _activeVlessLink.value == target.uri) {
            updated.firstOrNull { it.enabled }?.let { applyActiveLink(it.uri, publish = false) }
        }
        logAdminAction("Server '${target.name}' ${if (enabled) "ON" else "OFF"}")
        return null
    }

    fun useAdminServer(id: String): String? {
        val s = _adminServers.value.find { it.id == id } ?: return "Server not found"
        if (!s.enabled) return "Turn the server ON first"
        val r = applyActiveLink(s.uri, publish = false)
        if (r.isFailure) return r.exceptionOrNull()?.message
        logAdminAction("Active server -> '${s.name}'")
        return null
    }

    fun resetServersToBuiltIn() {
        saveAdminServers(listOf(AdminServer("builtin", "SS VPN (built-in)", defaultVlessUri, true)))
        prefs.edit().putBoolean("vless_user_override", false).apply()
        _activeVlessLink.value = defaultVlessUri
        _currentProfile.value = VlessParser.parse(defaultVlessUri).getOrDefault(VlessProfile.DEFAULT)
        logAdminAction("Servers reset to built-in")
    }

    /** সক্রিয় সার্ভার এই ডিভাইসে প্রয়োগ করে; publish=true হলে Firestore-এ সব ইউজারের জন্য রাখে। */
    fun applyActiveLink(newUri: String, publish: Boolean): Result<VlessProfile> {
        val parsed = VlessParser.parse(newUri.trim())
        if (parsed.isFailure) return Result.failure(parsed.exceptionOrNull() ?: IllegalArgumentException("Invalid VLESS link"))
        val profile = parsed.getOrThrow()
        _activeVlessLink.value = newUri.trim()
        _currentProfile.value = profile
        prefs.edit().putString("active_vless_uri", newUri.trim()).putBoolean("vless_user_override", true).apply()
        if (publish) {
            scope.launch {
                try {
                    FirebaseFirestore.getInstance().collection("config").document("server")
                        .set(mapOf("vlessLink" to newUri.trim(), "publishToAll" to true))
                        .addOnSuccessListener { syncOk("pushed server") }
                        .addOnFailureListener { syncFail("push server", it) }
                } catch (e: Throwable) { syncFail("push server", e) }
            }
            logAdminAction("Published server to all users")
        }
        return Result.success(profile)
    }

    fun updateActiveVlessLink(newUri: String): Result<VlessProfile> = applyActiveLink(newUri, publish = false)

    fun updateAdMobIds(banner: String, interstitial: String, rewarded: String) {
        val config = AdMobConfig(
            bannerId = banner.trim(),
            interstitialId = interstitial.trim(),
            rewardedId = rewarded.trim()
        )
        _adMobConfig.value = config
        try { com.example.ads.AdManager.onIdsChanged() } catch (_: Throwable) { }
        prefs.edit()
            .putString("admob_banner", config.bannerId)
            .putString("admob_interstitial", config.interstitialId)
            .putString("admob_rewarded", config.rewardedId)
            .apply()
        scope.launch {
            try {
                FirebaseFirestore.getInstance().collection("config").document("ads")
                    .set(
                        mapOf(
                            "bannerId" to config.bannerId,
                            "interstitialId" to config.interstitialId,
                            "rewardedId" to config.rewardedId
                        )
                    ).addOnSuccessListener { syncOk("pushed ads") }
                        .addOnFailureListener { syncFail("push ads", it) }
            } catch (e: Throwable) { syncFail("push ads", e) }
        }
    }

    fun generatePremiumKey(days: Int = 30): String {
        val randomSuffix = UUID.randomUUID().toString().substring(0, 8).uppercase()
        val key = "SS-${days}D-$randomSuffix"
        val newKey = PremiumKeyData(key = key, days = days)
        val list = _keysList.value.toMutableList()
        list.add(0, newKey)
        saveKeysRegistry(list)
        scope.launch {
            try {
                FirebaseFirestore.getInstance().collection("keys").document(key).set(
                    mapOf(
                        "key" to key,
                        "days" to days,
                        "boundDeviceId" to null,
                        "activatedAt" to 0L,
                        "expiresAt" to 0L,
                        "isRevoked" to false
                    )
                )
            } catch (e: Exception) { }
        }
        return key
    }

    fun revokeKey(key: String) {
        val list = _keysList.value.map {
            if (it.key.equals(key, ignoreCase = true)) it.copy(isRevoked = true) else it
        }
        saveKeysRegistry(list)
        if (_activeKey.value.equals(key, ignoreCase = true)) {
            _isPremium.value = false
            _premiumExpiresAt.value = 0L
            _activeKey.value = ""
            prefs.edit().putBoolean("is_premium", false).putLong("premium_expires_at", 0L).remove("active_key").apply()
        }
        scope.launch {
            try {
                FirebaseFirestore.getInstance().collection("keys").document(key).update("isRevoked", true)
            } catch (e: Exception) { }
        }
    }
}
