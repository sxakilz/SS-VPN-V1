package com.example.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.RealityVpnApp
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * আসল Google AdMob বিজ্ঞাপন। অ্যাড ইউনিট ID গুলো অ্যাডমিন প্যানেল (Ads ট্যাব) থেকে রানটাইমে বদলানো যায় —
 * রিবিল্ড লাগে না। ID খালি থাকলে ওই ধরনের অ্যাড দেখানোই হয় না।
 * (শুধু AdMob "App ID" একবার gradle.properties-এর ADMOB_APP_ID-তে বসাতে হয়।)
 */
object AdManager {
    private const val TAG = "AdManager"

    private var initialized = false
    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null
    private var loadingInterstitial = false
    private var loadingRewarded = false

    private val _lastStatus = MutableStateFlow("Ads idle")
    /** অ্যাডমিন/ডিবাগের জন্য সর্বশেষ অ্যাড লোডের অবস্থা। */
    val lastStatus: StateFlow<String> = _lastStatus.asStateFlow()

    private fun cfg() = RealityVpnApp.instance.appConfigManager

    fun ensureInit(context: Context) {
        if (initialized) return
        initialized = true
        try {
            MobileAds.initialize(context.applicationContext) { _lastStatus.value = "AdMob initialized" }
        } catch (t: Throwable) {
            Log.w(TAG, "AdMob init failed", t)
            _lastStatus.value = "AdMob init failed: ${t.message}"
        }
    }

    /** অ্যাড ID বদলালে পুরনো লোড করা অ্যাড ফেলে নতুন করে লোড করে। */
    fun onIdsChanged() {
        interstitial = null
        rewarded = null
        loadingInterstitial = false
        loadingRewarded = false
        val app = try { RealityVpnApp.instance } catch (_: Throwable) { return }
        preload(app)
    }

    fun preload(context: Context) {
        ensureInit(context)
        val m = cfg()
        val ids = m.adMobConfig.value
        if (m.interstitialAllowed() && interstitial == null && !loadingInterstitial) {
            loadingInterstitial = true
            try {
                InterstitialAd.load(context.applicationContext, ids.interstitialId, AdRequest.Builder().build(),
                    object : InterstitialAdLoadCallback() {
                        override fun onAdLoaded(ad: InterstitialAd) {
                            interstitial = ad; loadingInterstitial = false
                            _lastStatus.value = "Interstitial loaded"
                        }
                        override fun onAdFailedToLoad(e: LoadAdError) {
                            interstitial = null; loadingInterstitial = false
                            _lastStatus.value = "Interstitial failed: ${e.code} ${e.message}"
                        }
                    })
            } catch (t: Throwable) { loadingInterstitial = false; _lastStatus.value = "Interstitial error: ${t.message}" }
        }
        if (m.rewardedAllowed() && rewarded == null && !loadingRewarded) {
            loadingRewarded = true
            try {
                RewardedAd.load(context.applicationContext, ids.rewardedId, AdRequest.Builder().build(),
                    object : RewardedAdLoadCallback() {
                        override fun onAdLoaded(ad: RewardedAd) {
                            rewarded = ad; loadingRewarded = false
                            _lastStatus.value = "Rewarded loaded"
                        }
                        override fun onAdFailedToLoad(e: LoadAdError) {
                            rewarded = null; loadingRewarded = false
                            _lastStatus.value = "Rewarded failed: ${e.code} ${e.message}"
                        }
                    })
            } catch (t: Throwable) { loadingRewarded = false; _lastStatus.value = "Rewarded error: ${t.message}" }
        }
    }

    /** ইন্টারস্টিশিয়াল তৈরি থাকলে দেখায়, শেষ হলে (বা না থাকলে সঙ্গে সঙ্গে) [onDone] চলে। ইউজারকে আটকে রাখে না। */
    fun showInterstitial(activity: Activity, onDone: () -> Unit) {
        val ad = interstitial
        if (ad == null) {
            preload(activity)
            onDone()
            return
        }
        interstitial = null
        var finished = false
        fun finish() { if (!finished) { finished = true; onDone(); preload(activity) } }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() = finish()
            override fun onAdFailedToShowFullScreenContent(e: AdError) = finish()
        }
        try { ad.show(activity) } catch (t: Throwable) { finish() }
    }

    /** রিওয়ার্ডেড অ্যাড। দেখা শেষ করলে [onReward]; তৈরি না থাকলে [onNotReady]। */
    fun showRewarded(activity: Activity, onReward: () -> Unit, onNotReady: () -> Unit) {
        val ad = rewarded
        if (ad == null) {
            preload(activity)
            onNotReady()
            return
        }
        rewarded = null
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { if (earned) onReward(); preload(activity) }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { onNotReady(); preload(activity) }
        }
        try { ad.show(activity) { earned = true } } catch (t: Throwable) { onNotReady() }
    }
}

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** আসল AdMob ব্যানার। ID খালি হলে কিছুই আঁকে না (কলারকেই bannerAllowed() দিয়ে ঠেকানো হয়)। */
@Composable
fun AdMobBanner(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val id = RealityVpnApp.instance.appConfigManager.adMobConfig.value.bannerId
    if (id.isBlank()) return
    AdManager.ensureInit(context)
    val adView = remember(id) {
        AdView(context).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = id
            try { loadAd(AdRequest.Builder().build()) } catch (_: Throwable) {}
        }
    }
    DisposableEffect(adView) { onDispose { try { adView.destroy() } catch (_: Throwable) {} } }
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        AndroidView(factory = { adView })
    }
}
