# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

# --- sing-box / libbox (gomobile JNI আন্তঃক্রিয়া নামের ওপর নির্ভর করে) ---
-keep class go.** { *; }
-keep class io.nekohasekai.** { *; }
-keepclassmembers class * implements io.nekohasekai.libbox.PlatformInterface { *; }
-dontwarn go.**
-dontwarn io.nekohasekai.**

# --- অ্যাপের নিজস্ব মডেল (JSON/Moshi) ---
-keep class com.example.model.** { *; }
-keep class com.example.vpn.** { *; }
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
