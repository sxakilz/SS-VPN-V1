package com.example.vpn

import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Data model for a VLESS + REALITY server profile.
 */
data class VlessProfile(
    val id: String = java.util.UUID.randomUUID().toString(),
    val remarks: String = "SS VPN Server",
    val address: String = "149.28.156.223",
    val port: Int = 47778,
    val uuid: String = "9bea506a-6f3f-4e4c-8e5d-9473d70fba51",
    val flow: String = "",
    val encryption: String = "none",
    val networkType: String = "tcp",
    val headerType: String = "none",
    val security: String = "reality",
    val sni: String = "ai.android",
    val fingerprint: String = "chrome",
    val packetEncoding: String = "xudp",
    val publicKey: String = "8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg",
    val shortId: String = "c1e22f0e",
    val spiderX: String = "/"
) {
    fun toUri(): String {
        val queryParams = mutableListOf<String>()
        queryParams.add("security=$security")
        if (encryption.isNotEmpty() && encryption != "none") queryParams.add("encryption=${encode(encryption)}")
        if (publicKey.isNotEmpty()) queryParams.add("pbk=${encode(publicKey)}")
        if (headerType.isNotEmpty() && headerType != "none") queryParams.add("headerType=${encode(headerType)}")
        if (fingerprint.isNotEmpty()) queryParams.add("fp=${encode(fingerprint)}")
        if (networkType.isNotEmpty()) queryParams.add("type=${encode(networkType)}")
        if (flow.isNotEmpty()) queryParams.add("flow=${encode(flow)}")
        if (shortId.isNotEmpty()) queryParams.add("sid=${encode(shortId)}")
        if (sni.isNotEmpty()) queryParams.add("sni=${encode(sni)}")
        if (spiderX.isNotEmpty() && spiderX != "/") queryParams.add("spx=${encode(spiderX)}")

        val query = queryParams.joinToString("&")
        val remarkEncoded = encode(remarks)
        return "vless://$uuid@$address:$port?$query#$remarkEncoded"
    }

    fun toXrayJson(localSocksPort: Int = 10808): String {
        return """
        {
          "log": { "loglevel": "warning" },
          "inbounds": [
            {
              "tag": "socks-in",
              "port": $localSocksPort,
              "listen": "127.0.0.1",
              "protocol": "socks",
              "settings": { "auth": "noauth", "udp": true }
            }
          ],
          "outbounds": [
            {
              "tag": "proxy",
              "protocol": "vless",
              "settings": {
                "vnext": [
                  {
                    "address": "$address",
                    "port": $port,
                    "users": [
                      {
                        "id": "$uuid",
                        "encryption": "$encryption",
                        "flow": "$flow"
                      }
                    ]
                  }
                ]
              },
              "streamSettings": {
                "network": "$networkType",
                "security": "$security",
                "realitySettings": {
                  "show": false,
                  "fingerprint": "$fingerprint",
                  "serverName": "$sni",
                  "publicKey": "$publicKey",
                  "shortId": "$shortId",
                  "spiderX": "$spiderX"
                }
              }
            },
            { "tag": "direct", "protocol": "freedom" }
          ]
        }
        """.trimIndent()
    }

    companion object {
        val DEFAULT = VlessProfile(
            id = "default-ss-vpn",
            remarks = "SS VPN Server",
            address = "149.28.156.223",
            port = 47778,
            uuid = "9bea506a-6f3f-4e4c-8e5d-9473d70fba51",
            flow = "",
            encryption = "none",
            networkType = "tcp",
            headerType = "none",
            security = "reality",
            sni = "ai.android",
            fingerprint = "chrome",
            packetEncoding = "xudp",
            publicKey = "8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg",
            shortId = "c1e22f0e",
            spiderX = "/"
        )

        private fun encode(s: String): String =
            try { URLEncoder.encode(s, StandardCharsets.UTF_8.toString()) } catch (e: Exception) { s }
    }
}

/**
 * Robust parser for VLESS URI specifications.
 */
object VlessParser {

    fun parse(uriString: String): Result<VlessProfile> {
        val trimmed = uriString.trim()
        if (!trimmed.startsWith("vless://", ignoreCase = true)) {
            return Result.failure(IllegalArgumentException("Invalid link format. Must start with vless://"))
        }

        return try {
            val withoutScheme = trimmed.substring("vless://".length)
            val parts = withoutScheme.split("#", limit = 2)
            val coreAndQuery = parts[0]
            val remarks = if (parts.size > 1 && parts[1].isNotEmpty()) {
                decode(parts[1])
            } else {
                "SS VPN Server"
            }

            val atIndex = coreAndQuery.indexOf('@')
            if (atIndex == -1) {
                return Result.failure(IllegalArgumentException("Missing UUID or server address in VLESS link"))
            }

            val uuid = coreAndQuery.substring(0, atIndex).trim()
            val rest = coreAndQuery.substring(atIndex + 1)
            val questionIndex = rest.indexOf('?')
            val hostPort = if (questionIndex != -1) rest.substring(0, questionIndex) else rest
            val queryString = if (questionIndex != -1) rest.substring(questionIndex + 1) else ""

            val hostPortParts = hostPort.split(":")
            val host = hostPortParts[0].trim()
            val port = if (hostPortParts.size > 1) {
                hostPortParts[1].toIntOrNull() ?: 47778
            } else {
                47778
            }

            val params = mutableMapOf<String, String>()
            if (queryString.isNotEmpty()) {
                queryString.split("&").forEach { pair ->
                    val kv = pair.split("=", limit = 2)
                    if (kv.isNotEmpty()) {
                        val key = kv[0].lowercase().trim()
                        val value = if (kv.size > 1) decode(kv[1].trim()) else ""
                        params[key] = value
                    }
                }
            }

            val security = params["security"] ?: "reality"
            val sni = params["sni"] ?: params["servername"] ?: if (host == "149.28.156.223") "ai.android" else host
            val fingerprint = params["fp"] ?: "chrome"
            val publicKey = params["pbk"] ?: ""
            val shortId = params["sid"] ?: ""
            val flow = params["flow"] ?: ""
            val networkType = params["type"] ?: "tcp"
            val headerType = params["headertype"] ?: "none"
            val encryption = params["encryption"] ?: "none"
            val spiderX = params["spx"] ?: "/"

            if (uuid.isEmpty() || host.isEmpty()) {
                return Result.failure(IllegalArgumentException("Invalid VLESS configuration: UUID and host are required"))
            }

            Result.success(
                VlessProfile(
                    remarks = remarks,
                    address = host,
                    port = port,
                    uuid = uuid,
                    flow = flow,
                    encryption = encryption,
                    networkType = networkType,
                    headerType = headerType,
                    security = security,
                    sni = sni,
                    fingerprint = fingerprint,
                    publicKey = publicKey,
                    shortId = shortId,
                    spiderX = spiderX
                )
            )
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("Failed to parse VLESS URI: ${e.message}", e))
        }
    }

    private fun decode(value: String): String =
        try {
            URLDecoder.decode(value, StandardCharsets.UTF_8.toString())
        } catch (e: Exception) {
            value
        }
}
