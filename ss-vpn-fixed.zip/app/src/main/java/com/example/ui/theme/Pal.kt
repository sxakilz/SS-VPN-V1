package com.example.ui.theme

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

/** নতুন Home/Settings UI-এর রঙের প্যালেট (ডার্ক ডিফল্ট, লাইট ঐচ্ছিক)। */
data class Pal(
    val bg: Color,
    val card: Color,
    val cardAlt: Color,
    val text: Color,
    val sub: Color,
    val accent: Color,
    val onAccent: Color,
    val border: Color,
    val ok: Color,
    val bad: Color,
    val warn: Color,
    val isDark: Boolean
)

val DarkPal = Pal(
    bg = Color(0xFF07070B),
    card = Color(0xFF1B1B25),
    cardAlt = Color(0xFF12121A),
    text = Color(0xFFF2F0FA),
    sub = Color(0xFFA7A5B8),
    accent = Color(0xFFCFC2FF),
    onAccent = Color(0xFF1E1448),
    border = Color(0xFF2B2A38),
    ok = Color(0xFF4ADE80),
    bad = Color(0xFFF87171),
    warn = Color(0xFFFBBF24),
    isDark = true
)

val LightPal = Pal(
    bg = Color(0xFFF5F6FA),
    card = Color(0xFFFFFFFF),
    cardAlt = Color(0xFFEDEFF6),
    text = Color(0xFF14141F),
    sub = Color(0xFF6B6B80),
    accent = Color(0xFF5B3FD6),
    onAccent = Color(0xFFFFFFFF),
    border = Color(0xFFE3E5EE),
    ok = Color(0xFF16A34A),
    bad = Color(0xFFDC2626),
    warn = Color(0xFFD97706),
    isDark = false
)

val LocalPal = compositionLocalOf { DarkPal }
