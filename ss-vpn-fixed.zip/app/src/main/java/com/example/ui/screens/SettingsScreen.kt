package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.data.AppConfigManager
import com.example.ui.theme.LocalPal
import com.example.vpn.VpnStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    status: VpnStatus,
    appConfigManager: AppConfigManager,
    onOpenActivation: () -> Unit,
    onOpenLogs: () -> Unit,
    onToast: (String) -> Unit
) {
    val pal = LocalPal.current
    val control by appConfigManager.appControl.collectAsState()
    val isDark by appConfigManager.isDark.collectAsState()
    val reduceMotion by appConfigManager.reduceMotion.collectAsState()
    val isPremium by appConfigManager.isPremium.collectAsState()
    val premiumUntil by appConfigManager.premiumExpiresAt.collectAsState()
    val uri = LocalUriHandler.current
    val context = LocalContext.current

    val installed = BuildConfig.VERSION_NAME
    val hasUpdate = control.latestVersion.isNotBlank() && isNewerVersion(control.latestVersion, installed)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Column(modifier = Modifier.padding(top = 26.dp)) {
            Text("Settings", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = pal.text)
            Text("Appearance, connection and app information", fontSize = 14.sp, color = pal.sub)
        }

        // ---------- Appearance ----------
        Spacer(modifier = Modifier.height(18.dp))
        PalCard {
            ToggleRow("Dark theme", "The signature charcoal look.", isDark) { appConfigManager.setDark(it) }
            Spacer(modifier = Modifier.height(10.dp))
            ToggleRow("Reduce motion", "Minimize non-essential animations.", reduceMotion) { appConfigManager.setReduceMotion(it) }
        }

        // ---------- Connection ----------
        SectionHeader("Connection", "Live session information")
        PalCard {
            InfoRow(
                "Status",
                when (status) {
                    VpnStatus.CONNECTED -> "Connected"
                    VpnStatus.CONNECTING -> "Connecting…"
                    VpnStatus.DISCONNECTING -> "Disconnecting…"
                    else -> "Disconnected"
                },
                if (status == VpnStatus.CONNECTED) pal.ok else null
            )
            InfoRow("Server", "Secure server (auto)")
            InfoRow("Protocol", "VLESS + Reality")
        }

        // ---------- Premium ----------
        SectionHeader("Premium", "Remove ads with an activation key")
        PalCard {
            InfoRow(
                "Plan",
                if (isPremium) "Premium" else "Free",
                if (isPremium) pal.ok else null
            )
            if (isPremium && premiumUntil > 0L) {
                InfoRow("Valid until", SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date(premiumUntil)))
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlineButton(if (isPremium) "Change activation key" else "Enter activation key") { onOpenActivation() }
        }

        // ---------- Updates ----------
        SectionHeader("Updates", "Stay on the latest version")
        PalCard {
            InfoRow("Installed version", installed)
            InfoRow(
                "Latest version",
                when {
                    control.latestVersion.isBlank() -> "Up to date"
                    hasUpdate -> control.latestVersion
                    else -> "Up to date"
                },
                if (hasUpdate) pal.warn else null
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlineButton(if (hasUpdate) "Update now" else "Check for updates") {
                if (hasUpdate && control.updateUrl.isNotBlank()) {
                    com.example.core.UpdateInstaller.start(context, control.updateUrl, onToast)
                } else if (hasUpdate) {
                    onToast("Update ${control.latestVersion} is available. Please contact support.")
                } else {
                    onToast("You're on the latest version.")
                }
            }
        }

        // ---------- Privacy ----------
        SectionHeader("Privacy", "What this app does and does not do")
        PalCard {
            Text(
                "No tracking SDKs. Your browsing is not logged by the app.",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = pal.text,
                lineHeight = 22.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "If Android stops the app or the tunnel drops, your traffic uses your normal connection until the VPN is active again.",
                fontSize = 14.sp,
                color = pal.sub,
                lineHeight = 20.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlineButton("Read full privacy policy") {
                if (control.privacyUrl.isNotBlank()) {
                    try { uri.openUri(control.privacyUrl) } catch (_: Exception) { onToast("Cannot open link") }
                } else {
                    onToast("Privacy policy link will be available soon.")
                }
            }
        }

        // ---------- About ----------
        SectionHeader("About", "${control.appName} • simple, fast and private")
        PalCard {
            InfoRow("App", control.appName)
            InfoRow("App version", installed)
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "${control.appName} is built to serve people with fast, secure and private internet access. " +
                    "Please use it responsibly and only for good, lawful purposes.",
                fontSize = 14.sp,
                color = pal.sub,
                lineHeight = 20.sp
            )
            val hasLinks = control.facebookUrl.isNotBlank() || control.youtubeUrl.isNotBlank() ||
                control.instagramUrl.isNotBlank() || control.telegramUrl.isNotBlank()
            if (hasLinks) {
                Spacer(modifier = Modifier.height(14.dp))
                Text("Follow the community", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = pal.text)
                Spacer(modifier = Modifier.height(10.dp))
                CommunityRow(control.facebookUrl, control.youtubeUrl, control.instagramUrl, control.telegramUrl)
            }
        }

        // ---------- Disclaimer ----------
        SectionHeader("Disclaimer", "Responsible use")
        PalCard {
            Text(
                "You are fully responsible for how you use this VPN. If it is used for illegal activity, abuse or spam, " +
                    "the responsibility is entirely the user's. ${control.appName} and its operators are not liable for any " +
                    "misuse, and accounts involved in abuse may be blocked.",
                fontSize = 14.sp,
                color = pal.sub,
                lineHeight = 21.sp
            )
        }

        // ---------- ডায়াগনস্টিক (শুধু ডিবাগ বিল্ড) ----------
        if (BuildConfig.DEBUG && appConfigManager.adminSessionValid()) {
            SectionHeader("Developer", "Visible in debug builds only")
            PalCard {
                OutlineButton("View diagnostic logs") { onOpenLogs() }
            }
        }

        Spacer(modifier = Modifier.height(112.dp))
        Spacer(modifier = Modifier.navigationBarsPadding())
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Medium, color = pal.text)
            Text(subtitle, fontSize = 13.sp, color = pal.sub)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = pal.onAccent,
                checkedTrackColor = pal.accent,
                uncheckedThumbColor = pal.sub,
                uncheckedTrackColor = pal.cardAlt,
                uncheckedBorderColor = pal.sub
            )
        )
    }
}

@Composable
private fun OutlineButton(text: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .border(BorderStroke(1.dp, pal.sub), RoundedCornerShape(26.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = pal.accent, textAlign = TextAlign.Center)
    }
}
