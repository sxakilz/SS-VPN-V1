package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.collectAsState
import androidx.compose.foundation.clickable
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.AppConfigManager
import com.example.data.KeyActivationResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ActivationKeyDialog(
    appConfigManager: AppConfigManager,
    onDismiss: () -> Unit,
    onAdminUnlocked: () -> Unit,
    onPremiumActivated: (Int) -> Unit
) {
    var keyInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var showBuy by remember { mutableStateOf(false) }
    var recovery by remember { mutableStateOf(false) }
    var rcEmail by remember { mutableStateOf("") }
    var rcPass by remember { mutableStateOf("") }
    var rcNew by remember { mutableStateOf("") }
    var rcMsg by remember { mutableStateOf<String?>(null) }
    var titleTaps by remember { mutableStateOf(0) }
    val billingCfg by appConfigManager.billing.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    if (showBuy) BuyPremiumDialog(appConfigManager) { showBuy = false }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("activation_key_dialog")
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White)
                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(24.dp)),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEFF6FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VpnKey,
                                contentDescription = null,
                                tint = Color(0xFF0F62FE),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Enter Activation Key",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            // গোপন: টাইটেলে ৭ বার ট্যাপ করলে অ্যাডমিন-কী রিসেট ফর্ম খোলে
                            modifier = Modifier.clickable(
                                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                                indication = null
                            ) { titleTaps++; if (titleTaps >= 7) { recovery = true; titleTaps = 0 } }
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Enter your 1-Month Premium Key for unlimited high-speed bandwidth, zero ads, and dedicated secure nodes.",
                    fontSize = 13.sp,
                    color = Color(0xFF475569),
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Input field: clean, without any demo buttons or admin hints
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = {
                        keyInput = it
                        errorMessage = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("activation_key_input"),
                    placeholder = {
                        Text("Enter your key", fontSize = 13.sp, color = Color(0xFF94A3B8))
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = clipboard.primaryClip
                                if (clip != null && clip.itemCount > 0) {
                                    val text = clip.getItemAt(0).text?.toString() ?: ""
                                    keyInput = text.trim()
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = "Paste",
                                tint = Color(0xFF0F62FE)
                            )
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFFF8F9FA),
                        unfocusedContainerColor = Color(0xFFF8F9FA),
                        focusedBorderColor = Color(0xFF0F62FE),
                        unfocusedBorderColor = Color(0xFFE2E8F0)
                    ),
                    shape = RoundedCornerShape(14.dp)
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMessage ?: "",
                        fontSize = 12.sp,
                        color = Color(0xFFEF4444),
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        isProcessing = true
                        errorMessage = null
                        scope.launch {
                            delay(500)
                            isProcessing = false
                            when (val result = appConfigManager.activateKeyOnline(keyInput)) {
                                is KeyActivationResult.AdminUnlocked -> {
                                    onDismiss()
                                    onAdminUnlocked()
                                }
                                is KeyActivationResult.PremiumActivated -> {
                                    onDismiss()
                                    onPremiumActivated(result.daysLeft)
                                }
                                is KeyActivationResult.Error -> {
                                    errorMessage = result.message
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("activate_key_button"),
                    enabled = keyInput.isNotBlank() && !isProcessing,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F62FE)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Verifying...", fontSize = 14.sp)
                    } else {
                        Text(
                            text = "Activate",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                if (billingCfg.buyVisible) {
                    Spacer(modifier = Modifier.height(10.dp))
                    androidx.compose.material3.TextButton(
                        onClick = { showBuy = true },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Don't have a key? Buy key", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF0F62FE)) }
                }

                if (recovery) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Admin key recovery", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    Text("Sign in with the Firebase admin account and set a new admin key (min 12 characters).", fontSize = 11.sp, color = Color(0xFF64748B))
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(rcEmail, { rcEmail = it }, label = { Text("Admin email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        rcPass, { rcPass = it }, label = { Text("Firebase password") }, singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        rcNew, { rcNew = it }, label = { Text("New admin key") }, singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            rcMsg = "Working…"
                            appConfigManager.resetAdminKeyViaCloud(rcEmail, rcPass, rcNew) { err ->
                                rcMsg = err ?: "Admin key changed. Use the new key now."
                                if (err == null) { rcPass = ""; rcNew = "" }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(44.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Reset admin key") }
                    rcMsg?.let { Text(it, fontSize = 12.sp, color = Color(0xFF334155), modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        }
    }
}
