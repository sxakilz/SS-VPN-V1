package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PureWhiteColorScheme = lightColorScheme(
    primary = BrandPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDF5FF),
    onPrimaryContainer = BrandPrimaryDark,
    secondary = BrandSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE8F4FD),
    onSecondaryContainer = Color(0xFF003A66),
    tertiary = BrandAccent,
    onTertiary = Color.White,
    background = White,
    onBackground = TextPrimary,
    surface = White,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = BorderLight,
    outlineVariant = BorderSubtle,
    error = StatusDisconnected,
    onError = Color.White,
    errorContainer = StatusDisconnectedBg,
    onErrorContainer = StatusDisconnected
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Pure white solid background strictly enforced
    dynamicColor: Boolean = false, // Keep clean white brand palette
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PureWhiteColorScheme,
        typography = Typography,
        content = content
    )
}
