package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.MyVpnService
import com.example.data.AppConfigManager
import com.example.ui.theme.LocalPal
import com.example.vpn.TrafficStats
import com.example.vpn.VpnStatus
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    status: VpnStatus,
    stats: TrafficStats,
    pingMs: Int,
    appConfigManager: AppConfigManager,
    errorMessage: String?,
    onDismissError: () -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onWatchRewarded: () -> Unit
) {
    val pal = LocalPal.current
    val control by appConfigManager.appControl.collectAsState()
    val reduceMotion by appConfigManager.reduceMotion.collectAsState()
    val logoVersion by appConfigManager.logoVersion.collectAsState()
    val isPremium by appConfigManager.isPremium.collectAsState()
    val adFreeUntil by appConfigManager.adFreeUntil.collectAsState()
    val exitIp by MyVpnService.verifiedExitIp.collectAsState()

    // প্রতি সেকেন্ডে রিফ্রেশ — বিজ্ঞাপনমুক্ত সময়ের কাউন্টডাউনের জন্য
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(1000)
        }
    }
    val adFree = remember(nowMs, isPremium, adFreeUntil) { appConfigManager.isAdFreeActive() }
    val adFreeSeconds = remember(nowMs, adFreeUntil) { appConfigManager.getRemainingAdFreeSeconds() }
    val logo = remember(logoVersion) { appConfigManager.loadLogo() }

    val connected = status == VpnStatus.CONNECTED
    val busy = status == VpnStatus.CONNECTING || status == VpnStatus.DISCONNECTING
    val maintenance = control.maintenanceMode

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            // ---------- হেডার: লোগো + নাম + স্লোগান ----------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BrandLogo(bitmap = logo, size = 46.dp)
                Spacer(modifier = Modifier.width(14.dp))
                Text(
                    control.appName,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = pal.text.copy(alpha = 0.92f),
                    maxLines = 1
                )
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(30.dp)
                        .background(pal.border)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = if (connected) "You're\nprotected" else control.homeHeadline.replaceFirst(" ", "\n"),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal,
                    color = if (connected) pal.ok else pal.sub,
                    lineHeight = 16.sp,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ---------- কানেক্ট অর্ব ----------
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                PowerOrb(
                    status = status,
                    enabled = !maintenance,
                    reduceMotion = reduceMotion,
                    appName = control.appName,
                    durationText = stats.formatDuration(),
                    maintenance = maintenance,
                    onClick = { if (connected) onDisconnect() else onConnect() }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = when {
                    connected -> "Your traffic is encrypted through the secure tunnel."
                    busy -> "Please wait…"
                    else -> "Your connection is private once the tunnel is active."
                },
                fontSize = 17.sp,
                color = pal.text,
                textAlign = TextAlign.Center,
                lineHeight = 24.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            )

            // ---------- বার্তা কার্ড ----------
            if (!errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                NoticeCard(
                    icon = Icons.Default.Warning,
                    tint = pal.bad,
                    text = errorMessage,
                    onClose = onDismissError,
                    tag = "error_banner"
                )
            }
            if (maintenance) {
                Spacer(modifier = Modifier.height(14.dp))
                NoticeCard(
                    icon = Icons.Default.Lock,
                    tint = pal.warn,
                    text = control.maintenanceMessage,
                    onClose = null,
                    tag = "maintenance_banner"
                )
            }
            if (control.announcement.isNotBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                NoticeCard(
                    icon = Icons.Default.Campaign,
                    tint = pal.accent,
                    text = control.announcement,
                    onClose = null,
                    tag = "announcement_banner"
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ---------- সার্ভার (ড্রপডাউন) ----------
            val ctx = androidx.compose.ui.platform.LocalContext.current
            ServerPickerCard(
                manager = appConfigManager, connected = connected, busy = busy,
                onLocked = { android.widget.Toast.makeText(ctx, "Disconnect first to change server", android.widget.Toast.LENGTH_SHORT).show() }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // ---------- টানেল পরিসংখ্যান ----------
            TunnelStatsPanel(stats = stats, exitIp = exitIp, pingMs = pingMs, connected = connected)

            // ---------- ব্যানার অ্যাড: পেজের ভেতরেই (নেভিগেশনের নিচে চাপা পড়ে না) ----------
            if (appConfigManager.bannerAllowed() && !adFree) {
                Spacer(modifier = Modifier.height(14.dp))
                com.example.ads.AdMobBanner(modifier = Modifier.testTag("bottom_ad_banner"))
            }

            // ---------- রিওয়ার্ড কার্ড ----------
            if (appConfigManager.rewardedAllowed() || adFree) {
                Spacer(modifier = Modifier.height(14.dp))
                PalCard(
                    onClick = if (appConfigManager.rewardedAllowed()) onWatchRewarded else null,
                    modifier = Modifier.testTag("reward_card")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(pal.cardAlt),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CardGiftcard, null, tint = pal.accent, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isPremium) "Premium active" else "Watch ad • +${control.rewardHours}h ad-free",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = pal.text
                            )
                            Text(
                                text = when {
                                    isPremium -> "No ads while your premium key is valid."
                                    adFreeSeconds > 0 -> "Ad-free left: ${formatRemaining(adFreeSeconds)} • tap to add more"
                                    else -> "Remove connect/disconnect ads and banners."
                                },
                                fontSize = 13.sp,
                                color = pal.sub
                            )
                        }
                    }
                }
            }

            // ---------- কমিউনিটি ----------
            val hasLinks = control.facebookUrl.isNotBlank() || control.youtubeUrl.isNotBlank() ||
                control.instagramUrl.isNotBlank() || control.telegramUrl.isNotBlank()
            if (hasLinks) {
                Spacer(modifier = Modifier.height(14.dp))
                PalCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(pal.cardAlt),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(control.appName.take(1).uppercase(), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = pal.accent)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text("${control.appName} community", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = pal.text)
                            Text("Updates, help and announcements", fontSize = 13.sp, color = pal.sub)
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    CommunityRow(control.facebookUrl, control.youtubeUrl, control.instagramUrl, control.telegramUrl)
                }
            }

            // ভাসমান নেভিগেশনের জন্য জায়গা + সিস্টেম নেভিগেশন ইনসেট
            Spacer(modifier = Modifier.height(112.dp))
            Spacer(modifier = Modifier.navigationBarsPadding())
        }
    }
}

private fun formatRemaining(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    return if (h > 0) "${h}h ${m}m" else "${m}m ${seconds % 60}s"
}

@Composable
private fun NoticeCard(
    icon: ImageVector,
    tint: Color,
    text: String,
    onClose: (() -> Unit)?,
    tag: String
) {
    val pal = LocalPal.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag)
            .clip(RoundedCornerShape(20.dp))
            .background(tint.copy(alpha = if (pal.isDark) 0.14f else 0.10f))
            .border(BorderStroke(1.dp, tint.copy(alpha = 0.45f)), RoundedCornerShape(20.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Text(text, fontSize = 14.sp, color = pal.text, lineHeight = 20.sp, modifier = Modifier.weight(1f))
        if (onClose != null) {
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                Icons.Default.Close,
                contentDescription = "Dismiss",
                tint = pal.sub,
                modifier = Modifier
                    .size(20.dp)
                    .clickable { onClose() }
            )
        }
    }
}

@Composable
private fun StatLine(icon: ImageVector, label: String, value: String, total: String?) {
    val pal = LocalPal.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = pal.accent, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Text(label, fontSize = 15.sp, color = pal.sub, modifier = Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(value, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = pal.text)
            if (total != null) Text("Total $total", fontSize = 11.sp, color = pal.sub)
        }
    }
}

/** সিমুলেটেড স্পনসর্ড ব্যানার (আসল AdMob SDK এখনও যুক্ত নেই)। */
@Composable
private fun SponsoredBanner() {
    val pal = LocalPal.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bottom_ad_banner")
            .clip(RoundedCornerShape(22.dp))
            .background(pal.cardAlt)
            .border(BorderStroke(1.dp, pal.border), RoundedCornerShape(22.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(pal.warn.copy(alpha = 0.22f))
                .padding(horizontal = 7.dp, vertical = 3.dp)
        ) {
            Text("AD", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = pal.warn)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("Sponsored", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = pal.text)
            Text("Watch an ad below to hide banners for a while.", fontSize = 12.sp, color = pal.sub)
        }
    }
}

@Composable
private fun PowerOrb(
    status: VpnStatus,
    enabled: Boolean,
    reduceMotion: Boolean,
    appName: String,
    durationText: String,
    maintenance: Boolean,
    onClick: () -> Unit
) {
    val pal = LocalPal.current
    val connected = status == VpnStatus.CONNECTED
    val busy = status == VpnStatus.CONNECTING || status == VpnStatus.DISCONNECTING
    val ringColor = when {
        connected -> pal.ok
        busy -> pal.accent
        else -> pal.border
    }

    val transition = rememberInfiniteTransition(label = "orb")
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep"
    )

    Box(
        modifier = Modifier
            .size(250.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled && !busy) { onClick() }
            .testTag("connect_button"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx()
            val inset = stroke / 2f
            val arcSize = Size(size.width - stroke, size.height - stroke)
            // বাইরের ট্র্যাক
            drawCircle(
                color = pal.cardAlt,
                radius = size.minDimension / 2f - inset,
                style = Stroke(width = stroke)
            )
            if (busy && !reduceMotion) {
                drawArc(
                    color = ringColor,
                    startAngle = sweep,
                    sweepAngle = 110f,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            } else if (connected || busy) {
                drawCircle(
                    color = ringColor,
                    radius = size.minDimension / 2f - inset,
                    style = Stroke(width = stroke)
                )
            }
        }
        Box(
            modifier = Modifier
                .size(196.dp)
                .clip(CircleShape)
                .background(pal.card),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = appName.uppercase(),
                    fontSize = 13.sp,
                    letterSpacing = 4.sp,
                    color = pal.sub
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = when (status) {
                        VpnStatus.CONNECTED -> "Connected"
                        VpnStatus.CONNECTING -> "Connecting"
                        VpnStatus.DISCONNECTING -> "Stopping"
                        else -> "Connect"
                    },
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (connected) pal.ok else pal.text
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = when {
                        maintenance -> "Under maintenance"
                        connected -> durationText
                        busy -> "Please wait"
                        else -> "Tap to start"
                    },
                    fontSize = 15.sp,
                    color = pal.sub
                )
            }
        }
    }
}
