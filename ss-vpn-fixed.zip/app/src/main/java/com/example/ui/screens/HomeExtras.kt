package com.example.ui.screens

import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppConfigManager
import com.example.ui.theme.LocalPal
import com.example.vpn.TrafficStats

/** হোমের সার্ভার কার্ড: ট্যাপ করলে সার্ভার তালিকা (Auto + অ্যাডমিনের চালু করা সব সার্ভার) খোলে। */
@Composable
fun ServerPickerCard(manager: AppConfigManager, connected: Boolean, busy: Boolean, onLocked: () -> Unit) {
    val pal = LocalPal.current
    val servers by manager.adminServers.collectAsState()
    val pick by manager.selectedServerId.collectAsState()
    val activeLink by manager.activeVlessLink.collectAsState()
    val enabled = servers.filter { it.enabled }
    var open by remember { mutableStateOf(false) }
    val activeName = enabled.firstOrNull { it.uri == activeLink }?.name ?: enabled.firstOrNull()?.name ?: "Secure server"
    val subtitle = if (pick == null) (if (enabled.size > 1) "Auto • $activeName" else activeName) else activeName
    val canPick = enabled.size > 1

    PalCard(onClick = if (canPick) { { if (connected || busy) onLocked() else open = !open } } else null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(46.dp).clip(CircleShape).background(pal.cardAlt),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Public, null, tint = pal.accent, modifier = Modifier.size(24.dp)) }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Secure server", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = pal.text, maxLines = 1)
                Text(subtitle, fontSize = 13.sp, color = pal.sub, maxLines = 1)
            }
            Text(
                text = if (connected) "ACTIVE" else "READY",
                fontSize = 12.sp, fontWeight = FontWeight.Bold,
                color = if (connected) pal.ok else pal.sub
            )
            if (canPick) {
                Spacer(modifier = Modifier.width(6.dp))
                Icon(if (open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = pal.sub)
            }
        }
        if (open && canPick) {
            Spacer(modifier = Modifier.height(10.dp))
            ServerRow("Auto (recommended)", pick == null) { manager.userPickServer(null); open = false }
            enabled.forEach { s ->
                ServerRow(s.name, pick == s.id) { manager.userPickServer(s.id); open = false }
            }
        }
    }
}

@Composable
private fun ServerRow(name: String, selected: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) pal.cardAlt else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, fontSize = 15.sp, color = pal.text, modifier = Modifier.weight(1f), maxLines = 1)
        if (selected) Icon(Icons.Default.Check, null, tint = pal.accent, modifier = Modifier.size(18.dp))
    }
}

/** নতুন টানেল পরিসংখ্যান: বড় IP, লাইভ স্পিড গ্রাফ, ডাউনলোড/আপলোড টাইল, লেটেন্সি ও সেশন। */
@Composable
fun TunnelStatsPanel(stats: TrafficStats, exitIp: String?, pingMs: Int, connected: Boolean) {
    val pal = LocalPal.current
    val samples = remember { mutableStateListOf<Float>() }
    val latest = androidx.compose.runtime.rememberUpdatedState(stats)
    LaunchedEffect(connected) {
        samples.clear()
        while (connected) {
            val st = latest.value
            samples.add(st.downloadSpeedKbps + st.uploadSpeedKbps)
            while (samples.size > 60) samples.removeAt(0)
            kotlinx.coroutines.delay(400)
        }
    }
    PalCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(if (connected) pal.ok else pal.sub))
            Spacer(Modifier.width(10.dp))
            Text("Tunnel statistics", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = pal.text, modifier = Modifier.weight(1f))
            if (connected) Text("Live", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = pal.ok)
        }
        Spacer(Modifier.height(12.dp))
        if (!connected) {
            Text("IP, speed graph and latency appear while the VPN is connected.", fontSize = 15.sp, color = pal.sub, lineHeight = 22.sp)
            return@PalCard
        }
        // IP | Speed | Ping
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(modifier = Modifier.weight(1.5f)) {
                Text("IP", fontSize = 12.sp, color = pal.sub)
                Text(exitIp ?: "Checking…", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = pal.text, fontFamily = FontFamily.Monospace, maxLines = 1)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Speed", fontSize = 12.sp, color = pal.sub)
                Text(stats.formatDownloadSpeed(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = pal.text, maxLines = 1)
            }
            Column(modifier = Modifier.weight(0.8f)) {
                Text("Ping", fontSize = 12.sp, color = pal.sub)
                Text(if (pingMs > 0) "$pingMs ms" else "-- ms", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = pal.text, maxLines = 1)
            }
        }
        Spacer(Modifier.height(10.dp))
        SpeedGraph(samples, pal.ok)
        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("↓ ${stats.formatTotalDownload()}", fontSize = 11.sp, color = pal.sub)
            Text("↑ ${stats.formatTotalUpload()}", fontSize = 11.sp, color = pal.sub)
            Text(stats.formatDuration(), fontSize = 11.sp, color = pal.sub)
        }
    }
}

/** হার্টবিট/ট্রেডিং স্টাইল: মসৃণ সবুজ লাইন + নিচে গ্রেডিয়েন্ট, ডানপ্রান্তে স্পন্দিত বিন্দু। */
@Composable
private fun SpeedGraph(data: List<Float>, color: Color) {
    val pulse = androidx.compose.animation.core.rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(900), androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "glow"
    )
    Canvas(modifier = Modifier.fillMaxWidth().height(70.dp)) {
        val w = size.width; val h = size.height
        val n = 60
        val maxV = maxOf(6f, data.maxOrNull() ?: 6f) * 1.25f
        val pad = h * 0.12f
        fun yOf(v: Float) = h - pad - (v / maxV).coerceIn(0f, 1f) * (h - pad * 2f)
        if (data.isEmpty()) return@Canvas
        val step = w / (n - 1)
        val startX = w - step * (data.size - 1)
        val path = Path()
        data.forEachIndexed { i, v ->
            val x = startX + step * i
            val y = yOf(v)
            if (i == 0) path.moveTo(x, y) else {
                val px = startX + step * (i - 1)
                val py = yOf(data[i - 1])
                path.cubicTo((px + x) / 2f, py, (px + x) / 2f, y, x, y)
            }
        }
        val area = Path().apply { addPath(path); lineTo(w, h); lineTo(startX, h); close() }
        drawPath(area, Brush.verticalGradient(listOf(color.copy(alpha = 0.32f), Color.Transparent)))
        drawPath(path, color, style = Stroke(width = 3.5f, cap = StrokeCap.Round))
        val ex = w; val ey = yOf(data.last())
        drawCircle(color.copy(alpha = 0.25f * glow), radius = 11f * (0.6f + glow), center = Offset(ex - 4f, ey))
        drawCircle(color, radius = 4.5f, center = Offset(ex - 4f, ey))
    }
}

@Composable
private fun SpeedTile(icon: ImageVector, label: String, speed: String, total: String, tint: Color, modifier: Modifier) {
    val pal = LocalPal.current
    Column(modifier = modifier.clip(RoundedCornerShape(16.dp)).background(pal.cardAlt).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, fontSize = 12.sp, color = pal.sub)
        }
        Spacer(Modifier.height(4.dp))
        Text(speed, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = pal.text)
        Text("Total $total", fontSize = 11.sp, color = pal.sub)
    }
}

@Composable
private fun MiniChip(icon: ImageVector, label: String, value: String, modifier: Modifier) {
    val pal = LocalPal.current
    Row(
        modifier = modifier.clip(RoundedCornerShape(14.dp)).background(pal.cardAlt).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = pal.accent, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, fontSize = 11.sp, color = pal.sub)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = pal.text)
        }
    }
}
