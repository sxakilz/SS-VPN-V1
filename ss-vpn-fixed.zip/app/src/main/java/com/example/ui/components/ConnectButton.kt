package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ripple
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.StatusConnected
import com.example.ui.theme.StatusConnecting
import com.example.ui.theme.StatusDisconnected
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vpn.VpnStatus

@Composable
fun ConnectButton(
    status: VpnStatus,
    pingMs: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.14f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spinAngle"
    )

    val isConnected = status == VpnStatus.CONNECTED
    val isConnecting = status == VpnStatus.CONNECTING || status == VpnStatus.DISCONNECTING

    val primaryColor = when (status) {
        VpnStatus.CONNECTED -> Color(0xFF10B981)
        VpnStatus.CONNECTING, VpnStatus.DISCONNECTING -> Color(0xFFF59E0B)
        VpnStatus.DISCONNECTED, VpnStatus.ERROR -> Color(0xFF6B7280)
    }

    val glowColor = when (status) {
        VpnStatus.CONNECTED -> Color(0xFF10B981).copy(alpha = 0.25f)
        VpnStatus.CONNECTING, VpnStatus.DISCONNECTING -> Color(0xFFF59E0B).copy(alpha = 0.2f)
        VpnStatus.DISCONNECTED, VpnStatus.ERROR -> Color(0xFF6B7280).copy(alpha = 0.1f)
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(190.dp),
            contentAlignment = Alignment.Center
        ) {
            // Outer Pulsing Glow Ring
            if (isConnecting || isConnected) {
                Box(
                    modifier = Modifier
                        .size(185.dp)
                        .scale(if (isConnected) 1.05f else pulseScale)
                        .clip(CircleShape)
                        .background(glowColor)
                )
            }

            // Decorative Outer Border
            Box(
                modifier = Modifier
                    .size(165.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(2.dp, BorderLight, CircleShape)
            )

            // Inner Action Button
            Box(
                modifier = Modifier
                    .size(136.dp)
                    .shadow(elevation = 8.dp, shape = CircleShape, spotColor = primaryColor.copy(alpha = 0.4f))
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = when (status) {
                                VpnStatus.CONNECTED -> listOf(Color(0xFF10B981), Color(0xFF059669))
                                VpnStatus.CONNECTING, VpnStatus.DISCONNECTING -> listOf(Color(0xFFF59E0B), Color(0xFFD97706))
                                VpnStatus.DISCONNECTED, VpnStatus.ERROR -> listOf(Color(0xFF6B7280), Color(0xFF4B5563))
                            }
                        )
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(bounded = true, color = Color.White),
                        onClick = onClick
                    )
                    .testTag("vpn_toggle_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = when (status) {
                            VpnStatus.CONNECTED -> Icons.Default.CheckCircle
                            VpnStatus.CONNECTING, VpnStatus.DISCONNECTING -> Icons.Default.Sync
                            VpnStatus.DISCONNECTED, VpnStatus.ERROR -> Icons.Default.PowerSettingsNew
                        },
                        contentDescription = "VPN Toggle",
                        tint = Color.White,
                        modifier = Modifier
                            .size(46.dp)
                            .then(if (isConnecting) Modifier.rotate(spinAngle) else Modifier)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = when (status) {
                            VpnStatus.CONNECTED -> "CONNECTED"
                            VpnStatus.CONNECTING -> "CONNECTING"
                            VpnStatus.DISCONNECTING -> "CLOSING"
                            VpnStatus.DISCONNECTED -> "CONNECT"
                            VpnStatus.ERROR -> "RETRY"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Latency and Status Label
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(
                    when (status) {
                        VpnStatus.CONNECTED -> Color(0xFFECFDF5)
                        VpnStatus.CONNECTING, VpnStatus.DISCONNECTING -> Color(0xFFFFFBEB)
                        else -> Color(0xFFF1F5F9)
                    }
                )
                .border(
                    1.dp,
                    when (status) {
                        VpnStatus.CONNECTED -> Color(0xFFA7F3D0)
                        VpnStatus.CONNECTING, VpnStatus.DISCONNECTING -> Color(0xFFFDE68A)
                        else -> BorderLight
                    },
                    CircleShape
                )
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = when (status) {
                    VpnStatus.CONNECTED -> if (pingMs > 0) "● Protected • $pingMs ms" else "● Protected • Secure"
                    VpnStatus.CONNECTING -> "● Negotiating Reality..."
                    VpnStatus.DISCONNECTING -> "● Disconnecting tunnel"
                    VpnStatus.DISCONNECTED -> "Tap to connect VLESS Reality"
                    VpnStatus.ERROR -> "Connection failed, retry"
                },
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = when (status) {
                    VpnStatus.CONNECTED -> StatusConnected
                    VpnStatus.CONNECTING, VpnStatus.DISCONNECTING -> StatusConnecting
                    VpnStatus.DISCONNECTED -> TextSecondary
                    VpnStatus.ERROR -> StatusDisconnected
                }
            )
        }
    }
}
