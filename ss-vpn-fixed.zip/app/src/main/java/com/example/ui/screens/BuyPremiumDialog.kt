package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.billing.BillingManager
import com.example.data.AppConfigManager

/**
 * "Buy key" ডায়লগ। অ্যাডমিন প্যানেলের সেটিং অনুযায়ী:
 *  • Play Store: প্ল্যান তালিকা + কেনা → অটো র‍্যান্ডম কী ও প্রিমিয়াম চালু
 *  • Manual: প্ল্যান ও দাম দেখিয়ে যোগাযোগ লিংক (Telegram/WhatsApp ইত্যাদি)
 */
@Composable
fun BuyPremiumDialog(manager: AppConfigManager, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val cfg by manager.billing.collectAsState()
    val ready by BillingManager.ready.collectAsState()
    val plans by BillingManager.plans.collectAsState()
    val msg by BillingManager.message.collectAsState()
    val lastKey by BillingManager.lastKey.collectAsState()

    LaunchedEffect(cfg.playEnabled, cfg.plansText) { BillingManager.refresh(ctx) }
    DisposableEffect(Unit) { onDispose { BillingManager.clearMessage() } }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)),
            color = Color.White
        ) {
            Column(modifier = Modifier.padding(22.dp).verticalScroll(rememberScrollState())) {
                Text("Get Premium", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                Spacer(Modifier.height(4.dp))
                Text("No ads • priority access. Choose a plan.", fontSize = 13.sp, color = Color(0xFF64748B))
                Spacer(Modifier.height(14.dp))

                if (cfg.playEnabled) {
                    Text("Google Play", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F62FE))
                    Spacer(Modifier.height(6.dp))
                    if (ready && plans.isNotEmpty()) {
                        plans.forEach { p ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(14.dp)).background(Color(0xFFF1F5F9)).padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(p.label, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF0F172A))
                                    Text("${p.days} days", fontSize = 12.sp, color = Color(0xFF64748B))
                                }
                                Button(
                                    onClick = { ctx.findActivity()?.let { BillingManager.launch(it, p.productId) } },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F62FE)),
                                    shape = RoundedCornerShape(12.dp)
                                ) { Text(p.price.ifBlank { "Buy" }, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    } else {
                        Text(
                            "Play Store purchase is not available in this build yet.",
                            fontSize = 13.sp, color = Color(0xFF64748B)
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                }

                if (cfg.manualEnabled && cfg.contactUrl.isNotBlank()) {
                    Text("Buy a key directly", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F62FE))
                    Spacer(Modifier.height(6.dp))
                    cfg.plans.forEach { p ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(p.label, fontSize = 14.sp, color = Color(0xFF0F172A))
                            Text(p.priceText.ifBlank { "—" }, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF0F172A))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(cfg.contactUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            catch (_: Throwable) { Toast.makeText(ctx, "Cannot open link", Toast.LENGTH_SHORT).show() }
                        },
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F62FE)),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Contact to buy a key", fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(6.dp))
                    Text("After payment you will receive a key. Enter it under 'Enter activation key'.", fontSize = 11.sp, color = Color(0xFF64748B))
                }

                if (msg.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(msg, fontSize = 12.sp, color = Color(0xFF334155))
                }
                lastKey?.let { k ->
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("key", k))
                        Toast.makeText(ctx, "Key copied", Toast.LENGTH_SHORT).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Copy my key: $k") }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Close") }
            }
        }
    }
}

private fun Context.findActivity(): android.app.Activity? {
    var c: Context? = this
    while (c is android.content.ContextWrapper) {
        if (c is android.app.Activity) return c
        c = c.baseContext
    }
    return null
}
