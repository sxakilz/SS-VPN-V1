package com.example.data

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import org.json.JSONObject

/**
 * google-services.json (app/src/main/assets/google-services.json) থেকে Firebase চালু করে।
 * গুগল-সার্ভিসেস গ্রেডল প্লাগইন ছাড়াই কাজ করে। ফাইল না থাকলে null/false ফেরত — অ্যাপ ক্র্যাশ করে না।
 */
object FirebaseBootstrap {
    @Volatile var lastError: String? = null

    fun init(context: Context): Boolean {
        return try {
            if (FirebaseApp.getApps(context).isNotEmpty()) return true
            val text = context.assets.open("google-services.json").bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            val info = root.getJSONObject("project_info")
            val clients = root.getJSONArray("client")
            var pick: JSONObject? = null
            for (i in 0 until clients.length()) {
                val c = clients.getJSONObject(i)
                val pkg = c.getJSONObject("client_info").getJSONObject("android_client_info").getString("package_name")
                if (pkg == context.packageName) { pick = c; break }
            }
            val client = pick ?: clients.getJSONObject(0)
            val opts = FirebaseOptions.Builder()
                .setProjectId(info.getString("project_id"))
                .setApplicationId(client.getJSONObject("client_info").getString("mobilesdk_app_id"))
                .setApiKey(client.getJSONArray("api_key").getJSONObject(0).getString("current_key"))
                .apply { info.optString("storage_bucket").takeIf { it.isNotBlank() }?.let { setStorageBucket(it) } }
                .build()
            FirebaseApp.initializeApp(context, opts)
            lastError = null
            true
        } catch (e: java.io.FileNotFoundException) {
            lastError = "google-services.json missing (put it in app/src/main/assets/)"
            false
        } catch (e: Throwable) {
            lastError = "Firebase config error: ${e.message}"
            false
        }
    }
}
