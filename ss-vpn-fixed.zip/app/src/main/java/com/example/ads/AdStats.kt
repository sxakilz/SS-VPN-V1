package com.example.ads

import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.AdValue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** অ্যাডের গোনা-হিসাব (impression + আনুমানিক আয়) — সব ফোন থেকে Firestore "stats" কালেকশনে জমা হয়। */
object AdStats {
    const val BANNER = "banner"
    const val INTER = "inter"
    const val REWARD = "reward"

    private val pending = HashMap<String, Long>()
    private var currency = "USD"
    private val handler = Handler(Looper.getMainLooper())
    private val flushRunnable = Runnable { flush() }

    @Synchronized
    private fun add(key: String, n: Long) {
        pending[key] = (pending[key] ?: 0L) + n
        handler.removeCallbacks(flushRunnable)
        handler.postDelayed(flushRunnable, 15_000)
    }

    fun impression(type: String) = add("${type}Imp", 1)
    fun rewardCompleted() = add("rewardDone", 1)
    fun paid(type: String, v: AdValue) {
        if (v.currencyCode.isNotBlank()) currency = v.currencyCode
        add("${type}RevMicros", v.valueMicros)
    }

    @Synchronized
    fun flush() {
        if (pending.isEmpty()) return
        val snap = HashMap(pending)
        pending.clear()
        try {
            val auth = FirebaseAuth.getInstance()
            val go = {
                val db = FirebaseFirestore.getInstance()
                val data = HashMap<String, Any>()
                snap.forEach { (k, v) -> data[k] = FieldValue.increment(v) }
                data["currency"] = currency
                data["updatedAt"] = System.currentTimeMillis()
                val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                db.collection("stats").document("total").set(data, SetOptions.merge())
                db.collection("stats").document("d_$day").set(data, SetOptions.merge())
                    .addOnFailureListener { requeue(snap) }
            }
            if (auth.currentUser == null) {
                auth.signInAnonymously().addOnSuccessListener { go() }.addOnFailureListener { requeue(snap) }
            } else go()
        } catch (_: Throwable) { requeue(snap) }
    }

    @Synchronized
    private fun requeue(snap: Map<String, Long>) {
        snap.forEach { (k, v) -> pending[k] = (pending[k] ?: 0L) + v }
    }

    data class Totals(
        val bannerImp: Long = 0, val interImp: Long = 0, val rewardImp: Long = 0, val rewardDone: Long = 0,
        val bannerRev: Double = 0.0, val interRev: Double = 0.0, val rewardRev: Double = 0.0,
        val currency: String = "USD"
    ) {
        val imp get() = bannerImp + interImp + rewardImp
        val rev get() = bannerRev + interRev + rewardRev
    }

    /** অ্যাডমিন হিসেবে সাইন-ইন থাকলে মোট + আজ + শেষ ৭ দিনের যোগফল পড়ে। */
    fun load(onResult: (total: Totals?, today: Totals?, week: Totals?, error: String?) -> Unit) {
        try {
            val col = FirebaseFirestore.getInstance().collection("stats")
            col.get().addOnSuccessListener { qs ->
                val fmt = SimpleDateFormat("yyyyMMdd", Locale.US)
                val todayId = "d_" + fmt.format(Date())
                val weekIds = (0..6).map { "d_" + fmt.format(Date(System.currentTimeMillis() - it * 86_400_000L)) }.toSet()
                fun parse(d: Map<String, Any?>): Totals {
                    fun l(k: String) = (d[k] as? Number)?.toLong() ?: 0L
                    fun r(k: String) = l(k) / 1_000_000.0
                    return Totals(l("bannerImp"), l("interImp"), l("rewardImp"), l("rewardDone"),
                        r("bannerRevMicros"), r("interRevMicros"), r("rewardRevMicros"), (d["currency"] as? String) ?: "USD")
                }
                var total: Totals? = null; var today: Totals? = null
                val weekList = ArrayList<Totals>()
                for (doc in qs.documents) {
                    val t = parse(doc.data ?: emptyMap())
                    when {
                        doc.id == "total" -> total = t
                        doc.id == todayId -> today = t
                    }
                    if (doc.id in weekIds) weekList.add(t)
                }
                val week = Totals(
                    weekList.sumOf { it.bannerImp }, weekList.sumOf { it.interImp }, weekList.sumOf { it.rewardImp },
                    weekList.sumOf { it.rewardDone }, weekList.sumOf { it.bannerRev }, weekList.sumOf { it.interRev },
                    weekList.sumOf { it.rewardRev }, total?.currency ?: "USD"
                )
                onResult(total ?: Totals(), today ?: Totals(), week, null)
            }.addOnFailureListener { onResult(null, null, null, it.message ?: "Failed") }
        } catch (t: Throwable) { onResult(null, null, null, t.message ?: "Firebase not configured") }
    }
}
