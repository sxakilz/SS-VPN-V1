package com.example.ads

import android.app.Activity
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Google UMP: EEA/UK/অন্যান্য অঞ্চলে বিজ্ঞাপনের সম্মতি ফর্ম। ফর্মের লেখা/নিয়ম AdMob কনসোলের
 * Privacy & messaging থেকে ঠিক হয় — অ্যাপে রিবিল্ড লাগে না। সম্মতি মিললে (বা দরকার না হলে) [onReady] চলে।
 */
object ConsentHelper {
    fun gather(activity: Activity, onReady: () -> Unit) {
        try {
            val info = UserMessagingPlatform.getConsentInformation(activity)
            val params = ConsentRequestParameters.Builder().build()
            info.requestConsentInfoUpdate(
                activity, params,
                {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                        onReady()
                    }
                },
                { _ -> onReady() }
            )
            if (info.canRequestAds()) onReady()
        } catch (t: Throwable) {
            onReady()
        }
    }
}
