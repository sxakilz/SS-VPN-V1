package com.example.core

import android.net.TrafficStats
import java.io.File
import java.net.NetworkInterface

/**
 * libbox-এর ট্রাফিক কাউন্টার না এলে বিকল্প উৎস:
 *  ১) TUN ইন্টারফেসের কার্নেল কাউন্টার (/sys/class/net/tunX/statistics)
 *  ২) না পেলে TrafficStats মোট ÷ ২ (টানেলের ভেতর-বাইরে দুবার গোনা হয়, তাই আনুমানিক)
 * (rx = ফোনে নামা ডেটা / ডাউনলোড, tx = ফোন থেকে যাওয়া / আপলোড)
 */
class TunCounters {
    private var iface: String? = null
    private var baseDown = -1L
    private var baseUp = -1L
    private var lastDown = 0L
    private var lastUp = 0L
    var viaSysfs = false
        private set

    data class Sample(val downTotal: Long, val upTotal: Long, val downRate: Long, val upRate: Long)

    private fun findTun(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .firstOrNull { it.name.startsWith("tun") && it.isUp }?.name
    } catch (_: Throwable) { null }

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().toLongOrNull()
    } catch (_: Throwable) { null }

    private fun raw(): Pair<Long, Long>? {
        if (iface == null) iface = findTun()
        iface?.let { n ->
            val rx = readLong("/sys/class/net/$n/statistics/rx_bytes")
            val tx = readLong("/sys/class/net/$n/statistics/tx_bytes")
            if (rx != null && tx != null) { viaSysfs = true; return rx to tx }
        }
        viaSysfs = false
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx == TrafficStats.UNSUPPORTED.toLong() || tx == TrafficStats.UNSUPPORTED.toLong()) return null
        return (rx / 2) to (tx / 2)
    }

    /** প্রতি সেকেন্ডে একবার কল করুন। */
    fun sample(): Sample? {
        val (rx, tx) = raw() ?: return null
        if (baseDown < 0) { baseDown = rx; baseUp = tx; lastDown = rx; lastUp = tx }
        val s = Sample(
            downTotal = (rx - baseDown).coerceAtLeast(0), upTotal = (tx - baseUp).coerceAtLeast(0),
            downRate = (rx - lastDown).coerceAtLeast(0), upRate = (tx - lastUp).coerceAtLeast(0)
        )
        lastDown = rx; lastUp = tx
        return s
    }
}
