package com.example.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.vpn.TrafficStats
import com.example.vpn.VlessProfile
import com.example.vpn.VpnStatus
import com.example.BuildConfig
import com.example.RealityVpnApp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicLong

/**
 * Production Android VpnService backed by the native sing-box (libbox) VLESS Reality core.
 *
 * Enforces:
 * - Physical connectivity pre-check before touching TUN
 * - Strictly protected TUN (`172.19.0.1/30`, `0.0.0.0/0`, `AF_INET` on API 21+, app self-exclusion)
 * - Full sing-box VLESS Reality (`xtls-rprx-vision`, `xudp`) outbound with `"final": "proxy"` & `hijack-dns`
 * - 4-second VPS socket handshake verification & auto-fallback (never shows fake connected state)
 * - Real sing-box CommandClient telemetry for upload/download speeds and byte totals
 */
class MyVpnService : VpnService() {

    private var singBoxEngine: SingBoxEngine? = null
    private var workerJob: Job? = null
    private val serviceJob = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + serviceJob)

    private val liveUpRateBytesPerSec = AtomicLong(0L)
    private val liveDownRateBytesPerSec = AtomicLong(0L)
    private val liveTotalUpBytes = AtomicLong(0L)
    private val liveTotalDownBytes = AtomicLong(0L)

    private var activeProfile: VlessProfile? = null
    private var startTimeMillis: Long = 0L

    override fun onCreate() {
        super.onCreate()
        currentInstance = this
        _activeOutboundTag.value = "proxy"
        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val configJson = intent.getStringExtra(EXTRA_CONFIG_JSON)
                val profile = if (!configJson.isNullOrEmpty()) {
                    try {
                        val obj = JSONObject(configJson)
                        VlessProfile(
                            id = obj.optString("id"),
                            remarks = obj.optString("remarks", ConfigManager.DEFAULT_REMARKS),
                            address = obj.optString("address", ConfigManager.DEFAULT_SERVER_IP),
                            port = obj.optInt("port", ConfigManager.DEFAULT_PORT),
                            uuid = obj.optString("uuid", ConfigManager.DEFAULT_UUID),
                            flow = obj.optString("flow", ConfigManager.DEFAULT_FLOW),
                            security = obj.optString("security", ConfigManager.DEFAULT_SECURITY),
                            sni = obj.optString("sni", ConfigManager.DEFAULT_SNI),
                            fingerprint = obj.optString("fingerprint", ConfigManager.DEFAULT_FINGERPRINT),
                            packetEncoding = obj.optString("packetEncoding", ConfigManager.DEFAULT_PACKET_ENCODING),
                            publicKey = obj.optString("publicKey", ConfigManager.DEFAULT_PUBLIC_KEY),
                            shortId = obj.optString("shortId", ConfigManager.DEFAULT_SHORT_ID)
                        )
                    } catch (_: Exception) {
                        ConfigManager.DEFAULT_PROFILE
                    }
                } else {
                    ConfigManager.DEFAULT_PROFILE
                }

                startTunnel(profile)
            }
            ACTION_DISCONNECT -> {
                stopTunnel()
            }
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    private fun networkLabel(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return "unknown"
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) } ?: return "none"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            else -> "other"
        }
    }

    private fun isPhysicalNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
    }

    private fun startTunnel(profile: VlessProfile) {
        // startForegroundService() requires startForeground() within ~5s on EVERY path,
        // including the early-return below, otherwise the app is killed.
        startForeground(NOTIFICATION_ID, createNotification("Connecting to SS VPN (Smart Secured)..."))

        validateProfile(profile)?.let { problem ->
            _vpnStatus.value = VpnStatus.DISCONNECTED
            _lastErrorMessage.value = "Invalid server profile: $problem"
            appendLog("[app] Invalid server profile: $problem")
            stopTunnel()
            return
        }

        // 1. Mandatory Physical Pre-Check
        if (!isPhysicalNetworkAvailable()) {
            _vpnStatus.value = VpnStatus.DISCONNECTED
            _lastErrorMessage.value = "No Internet Connection"
            stopSelf()
            return
        }

        // Tear down any previous core instance cleanly before starting a new session
        workerJob?.cancel()
        workerJob = null
        singBoxEngine?.stop()
        singBoxEngine = null

        activeProfile = profile
        if (BuildConfig.DEBUG) {
            appendLog("[app] Connecting to ${profile.address}:${profile.port} (sni=${profile.sni}, flow=${profile.flow}, fp=${profile.fingerprint}, sid=${profile.shortId}, uuid=${profile.uuid.take(8)}…${profile.uuid.takeLast(4)}, pbk=${profile.publicKey.take(6)}…${profile.publicKey.takeLast(4)})")
        } else {
            appendLog("[app] Connecting...")
        }
        _vpnStatus.value = VpnStatus.CONNECTING
        _lastErrorMessage.value = null

        workerJob = scope.launch {
            try {
                // আগের সেশনের ইঞ্জিন বন্ধ হওয়া শেষ না হলে অল্প অপেক্ষা (TUN সংঘাত এড়াতে)
                stopThread?.let { try { it.join(6000) } catch (_: InterruptedException) {} }
                // Measure initial direct VPS latency via protected socket
                val initialPing = measurePing(profile.address, profile.port)
                if (initialPing > 0) {
                    _pingMs.value = initialPing
                }

                val acm = RealityVpnApp.instance.appConfigManager
                var fakeDns = acm.engineDnsMode() == "fakeip"
                val engineMtu = acm.engineMtu()
                val candidates = if (acm.engineAutoFallback()) buildCandidates(profile) else listOf(profile)
                var tunnelProbe: SingBoxEngine.TunnelProbeResult? = null
                var usedProfile = profile
                var lastEngine: SingBoxEngine? = null
                val savedMtu = getSharedPreferences("vpn_variant", MODE_PRIVATE).getInt("mtu", 0)
                val firstMtu = if (savedMtu in 1280..1500) savedMtu else engineMtu
                val attempts = ArrayList<Pair<VlessProfile, Int>>()
                candidates.forEachIndexed { i, c -> attempts.add(c to (if (i == 0) firstMtu else engineMtu)) }
                // মোবাইল ডেটায় বড় প্যাকেট ভেঙে যায় — শেষ ভরসা: ছোট MTU
                if (candidates.isNotEmpty() && attempts.none { it.second == 1280 }) attempts.add(candidates.first() to 1280)
                for ((idx, att) in attempts.withIndex()) {
                val cand = att.first
                val mtuNow = att.second
                // 2+3. কনফিগ বানিয়ে sing-box (libbox) চালু; Fake-IP কনফিগ নিতে না পারলে নিজে সাধারণ DNS-এ নামে
                val started = startEngineFor(cand, mtuNow, fakeDns)
                val engine = started.engine
                val probePort = started.probePort
                fakeDns = started.fakeUsed
                lastEngine = engine

                // Confirm TUN was established by sing-box PlatformInterface
                if (engine.currentTunDescriptor == null) {
                    _lastErrorMessage.value = "Connection Failed: Unable to initialize VPN TUN interface"
                    stopTunnel()
                    return@launch
                }

                // 4A. Real 4-second VPS TCP Handshake Validation (Anti-Fake Connection Guard)
                val isHandshakeValid = withTimeoutOrNull(4000L) {
                    validateServerHandshake(profile)
                } ?: false

                appendLog("[app] VPS TCP handshake ok=$isHandshakeValid, tun fd ready=${engine.currentTunDescriptor != null}")
                if (!isHandshakeValid) {
                    _lastErrorMessage.value =
                        "Connection Failed: cannot reach server (${lastHandshakeError ?: "timed out after 4s"})"
                    stopTunnel()
                    return@launch
                }

                // 4B. দ্রুত যাচাই: প্রথমে ছোট একটি HTTPS টেস্ট (সফল হলেই সঙ্গে সঙ্গে Connected)।
                //     ব্যর্থ হলে একবার পূর্ণ টেস্ট (দুই টার্গেট) — ধীর/অস্থির মোবাইল নেটওয়ার্কের জন্য।
                // দুই টার্গেট একসাথে (প্যারালাল): যেটা আগে সফল হয় সঙ্গে সঙ্গে Connected। ধীর 4G-তে একবার আরও সময় দিয়ে পুনরায়।
                var probeResult: SingBoxEngine.TunnelProbeResult = raceProbe(probePort, engine, perTargetMs = 6000, totalMs = 7000L)
                if (!probeResult.success && probeResult.failureStage != SingBoxEngine.TunnelFailureStage.UPSTREAM_REALITY_EOF) {
                    val second = raceProbe(probePort, engine, perTargetMs = 9000, totalMs = 10_000L)
                    probeResult = second
                }

                appendLog("[app] attempt ${idx + 1}/${attempts.size} net=${networkLabel()} dns=${if (fakeDns) "fakeip" else "standard"} mtu=$mtuNow fp=${cand.fingerprint} flow=${cand.flow.ifBlank { "none" }} -> success=${probeResult.success} stage=${probeResult.failureStage} ip=${probeResult.exitIp} detail=${probeResult.errorDetail?.take(160)}")
                if (probeResult.success) {
                    tunnelProbe = probeResult
                    usedProfile = cand
                    saveWorkingVariant(cand)
                    getSharedPreferences("vpn_variant", MODE_PRIVATE).edit().putInt("mtu", mtuNow).apply()
                    break
                }
                tunnelProbe = probeResult
                if (idx < attempts.size - 1) { singBoxEngine = null; lastEngine = null; engine.stop() }

                }
                val engine = lastEngine ?: return@launch
                val finalProbe = tunnelProbe ?: return@launch
                if (!finalProbe.success) {
                    val detail = finalProbe.errorDetail ?: "VLESS Reality HTTPS verification failed"
                    _lastErrorMessage.value =
                        if (finalProbe.failureStage == SingBoxEngine.TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED) {
                            "Preview Sandbox Restriction: $detail"
                        } else {
                            "Connection Failed: $detail"
                        }
                    stopTunnel()
                    return@launch
                }

                if (finalProbe.latencyMs > 0) {
                    _pingMs.value = finalProbe.latencyMs
                }
                _verifiedExitIp.value = finalProbe.exitIp

                // 5. Verified sing-box TUN + VLESS Reality end-to-end internet: enter CONNECTED state
                startTimeMillis = System.currentTimeMillis()
                _vpnStatus.value = VpnStatus.CONNECTED
                _connectedProfile.value = usedProfile
                _activeOutboundTag.value = "proxy"

                if (finalProbe.exitIp.isNullOrBlank()) {
                    // generate_204 সফল হলে IP পাওয়া যায় না — ব্যাকগ্রাউন্ডে ভিন্ন সার্ভিস থেকে IP আনা হয়
                    probeScope.launch {
                        val targets = listOf(
                            SingBoxEngine.ProbeTarget("https", "ifconfig.me", 443, "/ip"),
                            SingBoxEngine.ProbeTarget("https", "api.ipify.org", 443, "/"),
                            SingBoxEngine.ProbeTarget("https", "icanhazip.com", 443, "/")
                        )
                        var n = 0
                        while (isActive && _verifiedExitIp.value.isNullOrBlank() && _vpnStatus.value == VpnStatus.CONNECTED && n < 6) {
                            val t = targets[n % targets.size]
                            val r = try {
                                SingBoxEngine.verifyEndToEndTunnel(
                                    socksPort = probePort, timeoutMs = 8000,
                                    coreLogProvider = { engine.getRecentLogs() },
                                    probeTargets = listOf(t),
                                    socketProtector = { sock -> protect(sock) }
                                )
                            } catch (_: Throwable) { null }
                            if (r?.success == true && !r.exitIp.isNullOrBlank()) _verifiedExitIp.value = r.exitIp
                            n++
                            if (_verifiedExitIp.value.isNullOrBlank()) delay(1500)
                        }
                    }
                }

                val pingLabel = if (_pingMs.value > 0) "${_pingMs.value} ms" else "Protected"
                updateNotification("Protected • SS VPN (Smart Secured) • $pingLabel")

                var tick = 0L
                while (isActive && singBoxEngine != null && engine.currentTunDescriptor != null) {
                    delay(1000L)
                    tick++

                    val duration = (System.currentTimeMillis() - startTimeMillis) / 1000L + sessionBonusSeconds

                    if (tick % 15L == 0L) {
                        val newPing = measurePing(profile.address, profile.port)
                        if (newPing > 0) {
                            _pingMs.value = newPing
                            updateNotification("Protected • SS VPN (Smart Secured) • $newPing ms")
                        }
                    }

                    _stats.value = SingBoxEngine.calculateLiveTrafficStats(
                        uplinkBytesPerSec = liveUpRateBytesPerSec.get(),
                        downlinkBytesPerSec = liveDownRateBytesPerSec.get(),
                        totalUploadBytes = liveTotalUpBytes.get(),
                        totalDownloadBytes = liveTotalDownBytes.get(),
                        durationSeconds = duration
                    )
                }
                if (isActive && engine.currentTunDescriptor == null && _vpnStatus.value == VpnStatus.CONNECTED) {
                    _lastErrorMessage.value = "Connection Failed: VPN TUN interface closed unexpectedly"
                    stopTunnel()
                }
            } catch (e: CancellationException) {
                // ব্যবহারকারী ডিসকানেক্ট চাপলে coroutine বাতিল হয় — এটা ত্রুটি নয়, তাই কোনো বার্তা নয়।
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "sing-box tunnel startup failed: ${e.message}", e)
                appendLog("[app] Startup exception: ${e.javaClass.simpleName}: ${e.message}")
                _lastErrorMessage.value = if (e.message?.contains("config", ignoreCase = true) == true) {
                    "Connection Failed: Core Config Error (${e.message})"
                } else {
                    "Connection Failed: ${e.message ?: e.javaClass.simpleName}"
                }
                stopTunnel()
            }
        }
    }


    private val probeScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    /** একাধিক টার্গেটে প্যারালাল HTTPS টেস্ট; প্রথম সফলটাই জেতে, সবগুলো ব্যর্থ হলে সম্মিলিত ত্রুটি। */
    private suspend fun raceProbe(
        probePort: Int,
        engine: SingBoxEngine,
        perTargetMs: Int,
        totalMs: Long
    ): SingBoxEngine.TunnelProbeResult {
        val targets = SingBoxEngine.DEFAULT_PROBE_TARGETS.take(2)
        val winner = kotlinx.coroutines.CompletableDeferred<SingBoxEngine.TunnelProbeResult>()
        val failures = java.util.Collections.synchronizedList(mutableListOf<SingBoxEngine.TunnelProbeResult>())
        targets.forEach { t ->
            probeScope.launch {
                val r = try {
                    SingBoxEngine.verifyEndToEndTunnel(
                        socksPort = probePort,
                        timeoutMs = perTargetMs,
                        coreLogProvider = { engine.getRecentLogs() },
                        probeTargets = listOf(t),
                        socketProtector = { sock -> protect(sock) }
                    )
                } catch (e: Throwable) {
                    SingBoxEngine.TunnelProbeResult(success = false, errorDetail = "${t.host}: ${e.message}")
                }
                if (r.success) {
                    winner.complete(r)
                } else {
                    failures.add(r)
                    if (failures.size >= targets.size) {
                        val first = failures.first()
                        winner.complete(first.copy(errorDetail = failures.joinToString("; ") { it.errorDetail ?: "failed" }))
                    }
                }
            }
        }
        return withTimeoutOrNull(totalMs) { winner.await() }
            ?: SingBoxEngine.TunnelProbeResult(
                success = false,
                failureStage = SingBoxEngine.TunnelFailureStage.HTTP_READ_TIMEOUT,
                errorDetail = "Timed out waiting for HTTPS response"
            )
    }

    /** সার্ভারের Reality মিলছে না এমন ক্ষেত্রে fingerprint/flow-এর বিকল্প ক্রমে চেষ্টা করে; সফলটা মনে রাখে। */
    private fun buildCandidates(p: VlessProfile): List<VlessProfile> {
        val prefs = getSharedPreferences("vpn_variant", MODE_PRIVATE)
        val keyNow = variantKey(p)
        val savedFp = prefs.getString("fp", null)
        val savedFlow = prefs.getString("flow", null)
        val savedOk = prefs.getString("key", null) == keyNow
        val out = LinkedHashSet<Pair<String, String>>()
        if (savedOk && savedFp != null && savedFlow != null) out.add(savedFp to savedFlow)
        // 3x-ui সার্ভারে client flow = None, তাই ফাঁকা flow আগে; vision শেষ ভরসা হিসেবে।
        out.add(p.fingerprint to p.flow)
        out.add("chrome" to "")
        return out.map { (fp, flow) -> p.copy(fingerprint = fp, flow = flow) }
    }


    private class StartedEngine(val engine: SingBoxEngine, val probePort: Int, val fakeUsed: Boolean)

    private fun startEngineFor(cand: VlessProfile, mtu: Int, fakeDns: Boolean): StartedEngine {
        var fake = fakeDns
        while (true) {
            val probePort = SingBoxEngine.findFreeLocalPort()
            val json = ConfigManager(this).buildSingboxConfigJson(
                profile = cand,
                socksProbePort = probePort,
                fakeDns = fake,
                mtu = mtu
            )
            liveUpRateBytesPerSec.set(0L)
            liveDownRateBytesPerSec.set(0L)
            liveTotalUpBytes.set(0L)
            liveTotalDownBytes.set(0L)

            val engine = SingBoxEngine(this)
            singBoxEngine = engine
            try {
                engine.start(
                    configJson = json,
                    onTrafficStatus = { statusMsg ->
                        liveUpRateBytesPerSec.set(statusMsg.uplink)
                        liveDownRateBytesPerSec.set(statusMsg.downlink)
                        liveTotalUpBytes.set(statusMsg.uplinkTotal)
                        liveTotalDownBytes.set(statusMsg.downlinkTotal)
                    },
                    onLogMessage = { logLine ->
                        Log.d(TAG, "[sing-box] $logLine")
                        if (BuildConfig.DEBUG && !isNoisyCoreLine(logLine)) appendLog("[sing-box] $logLine")
                    },
                    onUnexpectedStop = { reason ->
                        if (singBoxEngine === engine && (_vpnStatus.value == VpnStatus.CONNECTED || _vpnStatus.value == VpnStatus.CONNECTING)) {
                            if (!reason.isNullOrBlank()) {
                                _lastErrorMessage.value = "Tunnel disconnected: $reason"
                            }
                            stopTunnel()
                        }
                    }
                )
                return StartedEngine(engine, probePort, fake)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                singBoxEngine = null
                try { engine.stop() } catch (_: Exception) {}
                if (fake) {
                    appendLog("[app] Fake-IP DNS rejected by core (${e.message?.take(120)}); retrying with standard DNS")
                    fake = false
                    continue
                }
                throw e
            }
        }
    }

    private fun isNoisyCoreLine(l: String): Boolean =
        l.contains("found user id") || l.contains("found package") || l.contains("inbound/tun") ||
            l.contains("outbound connection to") || l.contains("process DNS packet")

    private fun saveWorkingVariant(p: VlessProfile) {
        getSharedPreferences("vpn_variant", MODE_PRIVATE).edit()
            .putString("fp", p.fingerprint).putString("flow", p.flow).putString("key", variantKey(p)).apply()
    }

    private fun variantKey(p: VlessProfile) = "${p.address}:${p.port}|${p.uuid}|${p.publicKey}|${p.shortId}|${p.sni}"

    @Volatile
    private var lastHandshakeError: String? = null

    /** সার্ভার প্রোফাইলের স্পষ্ট ভুল (যেমন পোর্ট ৬৫৫৩৫-এর বেশি) আগেই ধরে সঠিক বার্তা দেয়। */
    private fun validateProfile(p: VlessProfile): String? {
        if (p.address.isBlank()) return "Server address is empty"
        if (p.port !in 1..65535) return "Invalid server port: ${p.port} (must be 1-65535)"
        if (!Regex("^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$").matches(p.uuid)) {
            return "Invalid UUID format"
        }
        if (p.security.equals("reality", ignoreCase = true)) {
            if (p.publicKey.length != 43) return "Invalid Reality public key (must be 43 characters)"
            if (!Regex("^[0-9a-fA-F]{0,16}$").matches(p.shortId)) return "Invalid Reality short ID (hex, max 16)"
            if (p.sni.isBlank()) return "Reality SNI is empty"
        }
        return null
    }

    private fun validateServerHandshake(profile: VlessProfile): Boolean {
        lastHandshakeError = null
        val socket = Socket()
        return try {
            if (!protect(socket)) {
                Log.w(TAG, "protect(handshakeSocket) returned false for ${profile.address}:${profile.port}")
            }
            val start = System.currentTimeMillis()
            socket.connect(InetSocketAddress(profile.address, profile.port), 4000)
            val latency = (System.currentTimeMillis() - start).toInt()
            if (latency > 0) _pingMs.value = latency
            true
        } catch (e: Exception) {
            lastHandshakeError = e.message ?: e.javaClass.simpleName
            false
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    @Volatile private var stopThread: Thread? = null

    private fun stopTunnel() {
        _vpnStatus.value = VpnStatus.DISCONNECTING

        workerJob?.cancel()
        workerJob = null

        // libbox বন্ধ হতে কয়েক সেকেন্ড লাগতে পারে — তাই UI ও নোটিফিকেশন আগে পরিষ্কার, ইঞ্জিন ব্যাকগ্রাউন্ডে বন্ধ।
        val oldEngine = singBoxEngine
        singBoxEngine = null

        _vpnStatus.value = VpnStatus.DISCONNECTED
        _connectedProfile.value = null
        _verifiedExitIp.value = null
        _stats.value = TrafficStats()
        _pingMs.value = 0

        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {}
        try {
            (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(NOTIFICATION_ID)
        } catch (_: Exception) {}

        if (oldEngine != null) {
            val t = Thread {
                try { oldEngine.stop() } catch (e: Exception) { Log.w(TAG, "Error stopping SingBoxEngine: ${e.message}") }
                // এর মধ্যে নতুন সেশন শুরু হয়ে গেলে সার্ভিস বন্ধ করা যাবে না
                if (singBoxEngine == null && workerJob == null) { try { stopSelf() } catch (_: Exception) {} }
            }
            stopThread = t
            t.start()
        } else {
            stopSelf()
        }
    }

    override fun onDestroy() {
        stopTunnel()
        serviceJob.cancel()
        if (currentInstance === this) {
            currentInstance = null
        }
        super.onDestroy()
    }

    private fun measurePing(host: String, port: Int): Int {
        return try {
            val start = System.currentTimeMillis()
            val socket = Socket()
            if (!protect(socket)) {
                Log.w(TAG, "protect(pingSocket) returned false for $host:$port")
            }
            socket.connect(InetSocketAddress(host, port), 2000)
            val latency = (System.currentTimeMillis() - start).toInt()
            socket.close()
            latency
        } catch (_: Exception) {
            -1
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SS VPN Tunnel Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live connection status for SS VPN"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = Intent(this, MyVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val pendingDisconnect = PendingIntent.getService(
            this,
            1,
            disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SS VPN")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_vpn)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", pendingDisconnect)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, createNotification(text))
        } catch (_: Exception) {}
    }

    companion object {
        private const val TAG = "MyVpnService"
        const val ACTION_CONNECT = "com.ss.vpn.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.ss.vpn.ACTION_DISCONNECT"
        const val EXTRA_CONFIG_JSON = "extra_config_json"

        const val CHANNEL_ID = "ss_vpn_status_channel"
        const val NOTIFICATION_ID = 2001

        private val _vpnStatus = MutableStateFlow(VpnStatus.DISCONNECTED)
        val vpnStatus = _vpnStatus.asStateFlow()

        private val _activeOutboundTag = MutableStateFlow("proxy")
        val activeOutboundTag = _activeOutboundTag.asStateFlow()

        private val _lastErrorMessage = MutableStateFlow<String?>(null)
        val lastErrorMessage = _lastErrorMessage.asStateFlow()

        private val _connectedProfile = MutableStateFlow<VlessProfile?>(null)
        val connectedProfile = _connectedProfile.asStateFlow()

        private val _stats = MutableStateFlow(TrafficStats())
        val stats = _stats.asStateFlow()

        private val _pingMs = MutableStateFlow(0)
        val pingMs = _pingMs.asStateFlow()

        private val _verifiedExitIp = MutableStateFlow<String?>(null)
        val verifiedExitIp = _verifiedExitIp.asStateFlow()

        private var sessionBonusSeconds: Long = 0L

        private val _logs = MutableStateFlow<List<String>>(emptyList())
        val logs = _logs.asStateFlow()

        @Synchronized
        fun appendLog(line: String) {
            val next = _logs.value + line
            _logs.value = if (next.size <= 600) next else {
                // পুরোনো sing-box নয়েজ আগে ফেলি; [app] লাইনগুলো (কোন attempt সফল/ব্যর্থ) যতটা সম্ভব রাখি।
                val keepApp = next.filter { it.startsWith("[app]") }.takeLast(150)
                val rest = next.filter { !it.startsWith("[app]") }.takeLast(450)
                (keepApp + rest)
            }
        }

        @Synchronized
        fun clearLogs() {
            _logs.value = emptyList()
        }

        @Volatile
        var currentInstance: MyVpnService? = null
            private set

        fun setOutboundTag(tag: String) {
            _activeOutboundTag.value = tag
        }

        fun addSessionBonus(seconds: Long) {
            sessionBonusSeconds += seconds
        }

        fun clearErrorMessage() {
            _lastErrorMessage.value = null
        }
    }
}
