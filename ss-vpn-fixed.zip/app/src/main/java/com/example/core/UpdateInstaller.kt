package com.example.core

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

/** অ্যাপের ভেতরেই APK নামিয়ে ইনস্টল শুরু করে। লিংক সরাসরি .apk ফাইলের হতে হবে; না হলে ব্রাউজারে খোলে। */
object UpdateInstaller {

    fun start(context: Context, url: String, onMsg: (String) -> Unit) {
        val app = context.applicationContext
        val looksDirect = url.lowercase().let { it.contains(".apk") || it.contains("/releases/download/") || it.contains("download") }
        if (!looksDirect) { openInBrowser(app, url, onMsg); return }
        try {
            if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) {
                onMsg("Allow \"Install unknown apps\" for this app, then tap Update again.")
                app.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${app.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            }
            val dir = app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: app.filesDir
            val file = File(dir, "update.apk")
            if (file.exists()) file.delete()
            val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle("Updating app")
                .setDescription("Downloading the latest version…")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationUri(Uri.fromFile(file))
            val id = dm.enqueue(req)
            onMsg("Downloading update…")
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    if (i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) != id) return
                    try { app.unregisterReceiver(this) } catch (_: Exception) {}
                    val q = dm.query(DownloadManager.Query().setFilterById(id))
                    var ok = false
                    q.use { if (it.moveToFirst()) ok = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL }
                    if (ok && file.exists() && file.length() > 100_000) install(app, file, onMsg)
                    else { onMsg("Download failed. Opening link in browser."); openInBrowser(app, url, onMsg) }
                }
            }
            ContextCompat.registerReceiver(app, receiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED)
        } catch (t: Throwable) {
            onMsg("Could not start update. Opening link in browser.")
            openInBrowser(app, url, onMsg)
        }
    }

    private fun install(app: Context, file: File, onMsg: (String) -> Unit) {
        try {
            val uri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", file)
            app.startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (t: Throwable) { onMsg("Could not open installer.") }
    }

    private fun openInBrowser(app: Context, url: String, onMsg: (String) -> Unit) {
        try {
            app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) { onMsg("Cannot open update link") }
    }
}
