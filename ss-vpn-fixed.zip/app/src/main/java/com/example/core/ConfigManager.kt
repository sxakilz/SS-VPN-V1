package com.example.core

import android.content.Context
import android.content.SharedPreferences
import com.example.vpn.VlessParser
import com.example.vpn.VlessProfile
import org.json.JSONArray
import org.json.JSONObject

/**
 * Embedded VLESS Reality Configuration & Sing-box/Xray JSON Generator.
 * Provides direct IPv4 DNS resolution routing to prevent "DNS_PROBE_STARTED".
 */
class ConfigManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ss_vpn_core_config", Context.MODE_PRIVATE)

    companion object {
        // Embedded Server Constants
        const val DEFAULT_PROTOCOL = "vless"
        const val DEFAULT_SERVER_IP = "149.28.156.223"
        const val DEFAULT_PORT = 47778
        const val DEFAULT_UUID = "9bea506a-6f3f-4e4c-8e5d-9473d70fba51"
        const val DEFAULT_FLOW = ""
        const val DEFAULT_SECURITY = "reality"
        const val DEFAULT_FINGERPRINT = "chrome"
        const val DEFAULT_SNI = "ai.android"
        const val DEFAULT_PACKET_ENCODING = "xudp"
        const val DEFAULT_PUBLIC_KEY = "8M89Z5vsKLRa4mXjLPz-huE_qVcQw7hkPX5oj4takFg"
        const val DEFAULT_SHORT_ID = "c1e22f0e"
        const val DEFAULT_REMARKS = "SS VPN Server"

        val DEFAULT_PROFILE = VlessProfile(
            id = "embedded-default-node",
            remarks = DEFAULT_REMARKS,
            address = DEFAULT_SERVER_IP,
            port = DEFAULT_PORT,
            uuid = DEFAULT_UUID,
            flow = DEFAULT_FLOW,
            encryption = "none",
            networkType = "tcp",
            headerType = "none",
            security = DEFAULT_SECURITY,
            sni = DEFAULT_SNI,
            fingerprint = DEFAULT_FINGERPRINT,
            packetEncoding = DEFAULT_PACKET_ENCODING,
            publicKey = DEFAULT_PUBLIC_KEY,
            shortId = DEFAULT_SHORT_ID,
            spiderX = "/"
        )
    }

    /**
     * Generates a production Sing-box 1.12+ JSON configuration with gVisor TUN stack,
     * encrypted TCP DNS over proxy (`hijack-dns` -> `proxy`), and strict `final: "proxy"`
     * to prevent "DNS_PROBE_STARTED" and UAE/Dubai ISP IP/DNS leaks.
     */
    fun buildSingboxConfigJson(
        profile: VlessProfile = getActiveProfile(),
        socksProbePort: Int? = null,
        fakeDns: Boolean = false,
        mtu: Int = 1400
    ): String {
        val root = JSONObject()

        root.put("log", JSONObject().apply {
            put("level", "info")
            put("timestamp", true)
        })

        // 1. Inbound Tun Interface (IPv4 + IPv6) using gvisor stack for unprivileged Android VpnService
        val inbounds = JSONArray().apply {
            put(JSONObject().apply {
                put("type", "tun")
                put("tag", "tun-in")
                // IPv4-only TUN: no IPv6 address/route, so v6 traffic can never be black-holed
                // by a VPS without IPv6 egress (apps then fall back to IPv4 immediately).
                put("address", JSONArray().apply {
                    put("172.19.0.1/30")
                })
                put("mtu", mtu.coerceIn(1280, 1500))
                put("stack", "gvisor")
                put("auto_route", true)
                put("strict_route", false)
            })
            if (socksProbePort != null && socksProbePort > 0) {
                put(JSONObject().apply {
                    put("type", "socks")
                    put("tag", "socks-probe")
                    put("listen", "127.0.0.1")
                    put("listen_port", socksProbePort)
                })
            }
        }
        root.put("inbounds", inbounds)

        // 2. DNS configuration (sing-box 1.12+ typed servers):
        // Uses DNS-over-TCP (port 53) via VLESS Reality proxy so DNS works reliably even on VPS
        // setups where UDP:53 or xudp is restricted, with zero local ISP DNS leakage.
        val dns = JSONObject().apply {
            put("strategy", "ipv4_only")
            put("independent_cache", true)
            val servers = JSONArray().apply {
                put(JSONObject().apply {
                    put("tag", "google-dns")
                    put("type", "tcp")
                    put("server", "8.8.8.8")
                    put("server_port", 53)
                    put("detour", "proxy")
                })
                put(JSONObject().apply {
                    put("tag", "cloudflare-dns")
                    put("type", "tcp")
                    put("server", "1.1.1.1")
                    put("server_port", 53)
                    put("detour", "proxy")
                })
                put(JSONObject().apply {
                    put("tag", "local-dns")
                    put("type", "local")
                })
                if (fakeDns) {
                    // Fake-IP: অ্যাপের প্রতিটি DNS প্রশ্নের জন্য আলাদা Reality কানেকশন না খুলে তাৎক্ষণিক নকল IP দেয়;
                    // আসল ডোমেইন VPS নিজে রিজলভ করে। এতে সার্ভারে একসাথে কানেকশনের ঝড় অনেক কমে।
                    put(JSONObject().apply {
                        put("tag", "fakeip")
                        put("type", "fakeip")
                        put("inet4_range", "198.18.0.0/15")
                    })
                }
            }
            put("servers", servers)
            if (fakeDns) {
                put("rules", JSONArray().apply {
                    put(JSONObject().apply {
                        put("query_type", JSONArray().apply { put("HTTPS"); put("SVCB"); put("AAAA") })
                        put("action", "predefined")
                        put("rcode", "NOERROR")
                    })
                    put(JSONObject().apply {
                        put("query_type", JSONArray().apply { put("A") })
                        put("action", "route")
                        put("server", "fakeip")
                    })
                })
            }
            put("final", "google-dns")
        }
        root.put("dns", dns)

        // 3. Outbounds: 1. VLESS Reality (tag: proxy), 2. Direct outbound (tag: direct)
        val outbounds = JSONArray().apply {
            // VLESS Reality Outbound matching exact server constants
            put(JSONObject().apply {
                put("type", "vless")
                put("tag", "proxy")
                put("server", profile.address)
                put("server_port", profile.port)
                put("uuid", profile.uuid)
                put("flow", profile.flow)
                put("packet_encoding", profile.packetEncoding.ifEmpty { "xudp" })
                put("connect_timeout", "10s")

                val tls = JSONObject().apply {
                    put("enabled", true)
                    put("server_name", profile.sni)
                    put("utls", JSONObject().apply {
                        put("enabled", true)
                        put("fingerprint", profile.fingerprint)
                    })
                    put("reality", JSONObject().apply {
                        put("enabled", true)
                        put("public_key", profile.publicKey)
                        put("short_id", profile.shortId)
                    })
                }
                put("tls", tls)
            })

            // Direct outbound (protected via PlatformInterface.autoDetectInterfaceControl)
            put(JSONObject().apply {
                put("type", "direct")
                put("tag", "direct")
            })
        }
        root.put("outbounds", outbounds)

        // 4. Route Section (CRITICAL TO PREVENT DUBAI IP & DNS LEAKS):
        // Explicitly set final: "proxy", sniff action, and hijack-dns so ALL global internet
        // & DNS traffic is forced through VLESS Reality (149.28.156.223).
        val route = JSONObject().apply {
            put("auto_detect_interface", true)
            put("default_domain_resolver", "local-dns")
            put("final", "proxy")
            val routeRules = JSONArray().apply {
                put(JSONObject().apply {
                    put("inbound", JSONArray().apply { put("tun-in") })
                    put("action", "sniff")
                })
                put(JSONObject().apply {
                    put("protocol", "dns")
                    put("action", "hijack-dns")
                })
                // Reject QUIC (UDP/443) so Chrome/YouTube fall back to TCP instantly instead of
                // stalling on UDP that the VLESS server may not relay.
                put(JSONObject().apply {
                    put("inbound", JSONArray().apply { put("tun-in") })
                    put("network", "udp")
                    put("port", 443)
                    put("action", "reject")
                })
                put(JSONObject().apply {
                    put("inbound", JSONArray().apply { put("tun-in") })
                    put("port", 53)
                    put("action", "hijack-dns")
                })
            }
            put("rules", routeRules)
        }
        root.put("route", route)

        return root.toString(2).replace("\\/", "/")
    }

    /**
     * Generates standard Xray-core JSON client configuration.
     */
    fun buildXrayConfigJson(profile: VlessProfile = getActiveProfile(), socksPort: Int = 10808): String {
        return profile.toXrayJson(socksPort)
    }

    fun getActiveProfile(): VlessProfile {
        val saved = prefs.getString("saved_profile_uri", null)
        return if (!saved.isNullOrEmpty()) {
            VlessParser.parse(saved).getOrDefault(DEFAULT_PROFILE)
        } else {
            DEFAULT_PROFILE
        }
    }

    fun saveActiveProfile(profile: VlessProfile) {
        prefs.edit().putString("saved_profile_uri", profile.toUri()).apply()
    }

    /**
     * Runs automated deep audit on the active configuration to detect route leaks or missing proxy fallbacks.
     */
    fun auditCurrentConfig(configJson: String = buildSingboxConfigJson()): VpnLeakDiagnostic.DiagnosticReport {
        return VpnLeakDiagnostic.runAudit(
            configJson = configJson,
            activeProfile = getActiveProfile(),
            coreEngineType = "sing-box-libbox"
        )
    }

    /**
     * Automatically fixes route fallback, forces 'final': 'proxy', and saves the validated profile.
     */
    fun autoFixAndSave(brokenJson: String): VpnLeakDiagnostic.AutoFixResult {
        val result = VpnLeakDiagnostic.applyAutoFix(brokenJson, getActiveProfile())
        if (result.success) {
            prefs.edit().putString("saved_singbox_json", result.patchedJson).apply()
        }
        return result
    }
}
