package com.example.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.IpPrefix
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import android.util.Base64
import android.util.Log
import com.example.vpn.TrafficStats
import io.nekohasekai.libbox.CommandClient
import io.nekohasekai.libbox.CommandClientHandler
import io.nekohasekai.libbox.CommandClientOptions
import io.nekohasekai.libbox.CommandServer
import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.ConnectionEvents
import io.nekohasekai.libbox.ConnectionOwner
import io.nekohasekai.libbox.ExchangeContext
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.LocalDNSTransport
import io.nekohasekai.libbox.LogIterator
import io.nekohasekai.libbox.NetworkInterface
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.Notification
import io.nekohasekai.libbox.OutboundGroupIterator
import io.nekohasekai.libbox.OverrideOptions
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.ServiceStatusMessage
import io.nekohasekai.libbox.SetupOptions
import io.nekohasekai.libbox.StatusMessage
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.SystemProxyStatus
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLException
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Production sing-box (libbox) native core bridge for Android VpnService.
 *
 * Key guarantees:
 * - Physical non-VPN DefaultInterfaceMonitor using NET_CAPABILITY_NOT_VPN so sing-box
 *   never binds outbound sockets back onto tun0 after VpnService.Builder.establish().
 * - Clean IPv6 zone-ID stripping in getInterfaces() so Go netip.ParsePrefix never drops interfaces.
 * - localDNSTransport pinned strictly to the underlying physical Network (never tun0).
 * - End-to-end SOCKS5 + HTTPS tunnel health probe verifying DNS + VLESS Reality handshake + remote HTTPS egress.
 */
class SingBoxEngine(
    private val vpnService: VpnService
) {

    enum class TunnelFailureStage {
        NONE,
        SOCKS_BIND_UNREACHABLE,
        SOCKS5_HANDSHAKE_FAILED,
        TLS_TUNNEL_HANDSHAKE_FAILED,
        UPSTREAM_REALITY_EOF,
        HTTP_READ_TIMEOUT,
        UNEXPECTED_HTTP_RESPONSE,
        ENVIRONMENT_SANDBOX_BLOCKED
    }

    data class ProbeTarget(
        val scheme: String,
        val host: String,
        val port: Int,
        val path: String
    ) {
        val urlString: String get() = "$scheme://$host$path"
    }

    data class TunnelProbeResult(
        val success: Boolean,
        val latencyMs: Int = -1,
        val exitIp: String? = null,
        val errorDetail: String? = null,
        val failureStage: TunnelFailureStage = TunnelFailureStage.NONE
    )

    @Volatile
    private var commandServer: CommandServer? = null

    @Volatile
    private var commandClient: CommandClient? = null

    @Volatile
    private var tunPfd: ParcelFileDescriptor? = null

    @Volatile
    private var platformBridge: AndroidPlatformInterface? = null

    private val isStopped = AtomicBoolean(false)
    private val recentLogs = ConcurrentLinkedDeque<String>()

    val currentTunDescriptor: ParcelFileDescriptor?
        get() = tunPfd

    fun getRecentLogs(): List<String> = recentLogs.toList()

    private fun recordCoreLog(line: String, onLogMessage: (String) -> Unit) {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) return
        recentLogs.addLast(trimmed)
        while (recentLogs.size > MAX_LOG_LINES) {
            recentLogs.pollFirst()
        }
        onLogMessage(trimmed)
    }

    fun start(
        configJson: String,
        onTrafficStatus: (StatusMessage) -> Unit,
        onLogMessage: (String) -> Unit = {},
        onUnexpectedStop: (String?) -> Unit = {}
    ) {
        isStopped.set(false)
        recentLogs.clear()
        ensureSetup(vpnService.applicationContext)

        // Fail fast if sing-box config has any schema or routing error
        Libbox.checkConfig(configJson)

        val logSink: (String) -> Unit = { line -> recordCoreLog(line, onLogMessage) }

        val bridge = AndroidPlatformInterface(
            vpnService = vpnService,
            onTunOpened = { pfd -> tunPfd = pfd },
            onLog = logSink
        )
        platformBridge = bridge

        val serverHandler = object : CommandServerHandler {
            override fun getSystemProxyStatus(): SystemProxyStatus {
                return SystemProxyStatus().apply {
                    available = false
                    enabled = false
                }
            }

            override fun serviceReload() {
                if (!isStopped.get()) {
                    commandServer?.startOrReloadService(
                        configJson,
                        OverrideOptions().apply { autoRedirect = false }
                    )
                }
            }

            override fun serviceStop() {
                onUnexpectedStop(null)
            }

            override fun setSystemProxyEnabled(enabled: Boolean) {
                // System HTTP proxy is unused in Android TUN mode
            }

            override fun writeDebugMessage(message: String) {
                if (message.isNotBlank()) {
                    logSink(message)
                }
            }
        }

        val server = Libbox.newCommandServer(serverHandler, bridge)
        commandServer = server

        try {
            File(vpnService.filesDir, "command.sock").delete()
        } catch (_: Exception) {}

        try {
            server.start()
        } catch (e: Exception) {
            Log.w(TAG, "Default CommandServer start failed (${e.message}), retrying temporary port")
            server.startWithTemporaryPort()
        }

        val overrideOptions = OverrideOptions().apply {
            autoRedirect = false
        }
        server.startOrReloadService(configJson, overrideOptions)

        // Attach CommandClient to stream real uplink/downlink byte counters from sing-box
        Thread {
            // সার্ভিস পুরো চালু হওয়ার আগে সংযোগ ব্যর্থ হতে পারে — তাই কয়েকবার চেষ্টা (স্পিড/ট্রাফিক দেখানোর জন্য)
            var tries = 0
            while (tries < 10 && !isStopped.get() && commandClient == null) {
                attachStatusClient(onTrafficStatus, logSink, onUnexpectedStop)
                if (commandClient != null) break
                tries++
                try { Thread.sleep(600) } catch (_: InterruptedException) { break }
            }
        }.start()
    }

    private fun attachStatusClient(
        onTrafficStatus: (StatusMessage) -> Unit,
        onLogMessage: (String) -> Unit,
        onUnexpectedStop: (String?) -> Unit
    ) {
        try {
            val clientOptions = CommandClientOptions().apply {
                addCommand(Libbox.CommandStatus)
                addCommand(Libbox.CommandLog)
                statusInterval = 1_000_000_000L // 1 second in nanoseconds
            }

            val clientHandler = object : CommandClientHandler {
                override fun clearLogs() {
                    recentLogs.clear()
                }

                override fun connected() {}
                override fun disconnected(message: String) {
                    if (!isStopped.get() && message.isNotBlank()) {
                        onUnexpectedStop(message)
                    }
                }

                override fun initializeClashMode(modeList: StringIterator, currentMode: String) {}
                override fun setDefaultLogLevel(level: Int) {}
                override fun updateClashMode(newMode: String) {}
                override fun writeConnectionEvents(events: ConnectionEvents) {}
                override fun writeGroups(groups: OutboundGroupIterator) {}

                override fun writeLogs(messageList: LogIterator) {
                    while (messageList.hasNext()) {
                        val entry = messageList.next()
                        onLogMessage(entry.message)
                    }
                }

                override fun writeServiceStatus(status: ServiceStatusMessage) {}

                override fun writeStatus(message: StatusMessage) {
                    if (!isStopped.get()) {
                        onTrafficStatus(message)
                    }
                }
            }

            val client = Libbox.newCommandClient(clientHandler, clientOptions)
            client.connect()
            commandClient = client
        } catch (e: Exception) {
            Log.w(TAG, "CommandClient telemetry attach skipped: ${e.message}")
        }
    }

    fun stop() {
        if (!isStopped.compareAndSet(false, true)) return

        try {
            commandClient?.disconnect()
        } catch (_: Exception) {}
        commandClient = null

        try {
            commandServer?.closeService()
        } catch (e: Exception) {
            Log.w(TAG, "closeService warning: ${e.message}")
        }

        try {
            commandServer?.close()
        } catch (e: Exception) {
            Log.w(TAG, "commandServer.close warning: ${e.message}")
        }
        commandServer = null

        try {
            platformBridge?.cleanup()
        } catch (_: Exception) {}
        platformBridge = null

        try {
            tunPfd?.close()
        } catch (_: Exception) {}
        tunPfd = null
    }

    /**
     * Full PlatformInterface implementation bridging Android VpnService & ConnectivityManager to sing-box.
     */
    private class AndroidPlatformInterface(
        private val vpnService: VpnService,
        private val onTunOpened: (ParcelFileDescriptor) -> Unit,
        private val onLog: (String) -> Unit
    ) : PlatformInterface {

        private val connectivityManager: ConnectivityManager? =
            vpnService.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

        private val physicalNetworks = ConcurrentHashMap<Network, NetworkCapabilities>()

        @Volatile
        private var currentPhysicalNetwork: Network? = null

        @Volatile
        private var networkCallback: ConnectivityManager.NetworkCallback? = null

        @Volatile
        private var currentListener: InterfaceUpdateListener? = null

        @Volatile
        private var lastEmittedInterfaceKey: String? = null

        override fun autoDetectInterfaceControl(fd: Int) {
            // Go (gomobile) কলব্যাকে exception ছুঁড়লে পুরো প্রসেস ক্র্যাশ হতে পারে; তাই শুধু লগ করি।
            // protect() ব্যর্থ হলে সংশ্লিষ্ট কানেকশন নিজে থেকেই ফেল হবে, অ্যাপ ক্র্যাশ করবে না।
            if (!vpnService.protect(fd)) {
                onLog("ERROR protect($fd) returned false (VPN revoked or service not ready)")
            }
        }

        override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

        override fun clearDNSCache() {
            // Handled internally by sing-box core
        }

        override fun openTun(options: TunOptions): Int {
            val builder = vpnService.Builder()
                .setSession("SS VPN")
                .setMtu(if (options.mtu > 0) options.mtu else 1500)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            var hasIpv4Address = false
            val inet4Addresses = options.inet4Address
            while (inet4Addresses != null && inet4Addresses.hasNext()) {
                val prefix = inet4Addresses.next()
                builder.addAddress(prefix.address(), prefix.prefix())
                hasIpv4Address = true
            }
            if (!hasIpv4Address) {
                builder.addAddress("172.19.0.1", 30)
            }

            var hasIpv6Address = false
            val inet6Addresses = options.inet6Address
            while (inet6Addresses != null && inet6Addresses.hasNext()) {
                val prefix = inet6Addresses.next()
                builder.addAddress(prefix.address(), prefix.prefix())
                hasIpv6Address = true
            }

            // allowFamily() ইচ্ছাকৃতভাবে ব্যবহার করা হয়নি: TUN-এ IPv6 route নেই, তাই IPv6 ট্রাফিক
            // সিস্টেম নিজেই ব্লক করে (লিক নেই) এবং অ্যাপগুলো সঙ্গে সঙ্গে IPv4-এ ফলব্যাক করে।

            // Always configure public DNS servers (8.8.8.8 / 1.1.1.1) on the VPN interface;
            // port-53 queries entering tun0 are captured by sing-box hijack-dns -> proxy,
            // and DoT/DoH traffic to 8.8.8.8/1.1.1.1 is routed via final: "proxy".
            builder.addDnsServer("8.8.8.8")
            builder.addDnsServer("1.1.1.1")

            if (options.autoRoute) {
                var hasRoute4 = false
                val inet4Routes = options.inet4RouteAddress
                while (inet4Routes != null && inet4Routes.hasNext()) {
                    val prefix = inet4Routes.next()
                    builder.addRoute(prefix.address(), prefix.prefix())
                    hasRoute4 = true
                }
                if (!hasRoute4) {
                    // Always capture full 0.0.0.0/0 IPv4 traffic inside TUN; outbound sockets
                    // bypass TUN via addDisallowedApplication(packageName) + protect(fd).
                    builder.addRoute("0.0.0.0", 0)
                }

                if (hasIpv6Address) {
                    var hasRoute6 = false
                    val inet6Routes = options.inet6RouteAddress
                    while (inet6Routes != null && inet6Routes.hasNext()) {
                        val prefix = inet6Routes.next()
                        builder.addRoute(prefix.address(), prefix.prefix())
                        hasRoute6 = true
                    }
                    if (!hasRoute6) {
                        builder.addRoute("::", 0)
                    }
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val excludeRoutes = options.inet4RouteExcludeAddress
                    while (excludeRoutes != null && excludeRoutes.hasNext()) {
                        val prefix = excludeRoutes.next()
                        try {
                            builder.excludeRoute(
                                IpPrefix(InetAddress.getByName(prefix.address()), prefix.prefix())
                            )
                        } catch (_: Exception) {}
                    }
                    if (hasIpv6Address) {
                        val excludeRoutes6 = options.inet6RouteExcludeAddress
                        while (excludeRoutes6 != null && excludeRoutes6.hasNext()) {
                            val prefix = excludeRoutes6.next()
                            try {
                                builder.excludeRoute(
                                    IpPrefix(InetAddress.getByName(prefix.address()), prefix.prefix())
                                )
                            } catch (_: Exception) {}
                        }
                    }
                }

                // Exclude this app from TUN so sing-box outbound sockets never loop back
                try {
                    builder.addDisallowedApplication(vpnService.packageName)
                } catch (_: Exception) {}

                val excludePackages = options.excludePackage
                while (excludePackages != null && excludePackages.hasNext()) {
                    val pkg = excludePackages.next()
                    try {
                        builder.addDisallowedApplication(pkg)
                    } catch (_: Exception) {}
                }
            } else {
                builder.addRoute("0.0.0.0", 0)
                if (hasIpv6Address) {
                    builder.addRoute("::", 0)
                }
                try {
                    builder.addDisallowedApplication(vpnService.packageName)
                } catch (_: Exception) {}
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                (currentPhysicalNetwork ?: resolveFallbackPhysicalNetwork())?.let { physicalNet ->
                    try {
                        builder.setUnderlyingNetworks(arrayOf(physicalNet))
                    } catch (_: Exception) {}
                }
            }

            val pfd = builder.establish()
                ?: throw IllegalStateException("VpnService.Builder.establish() returned null")

            onTunOpened(pfd)
            return pfd.fd
        }

        override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
            val cm = connectivityManager ?: return
            closeDefaultInterfaceMonitor(listener)
            currentListener = listener

            // Seed map with currently active physical non-VPN networks BEFORE VPN tun0 is established
            @Suppress("DEPRECATION")
            for (net in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(net) ?: continue
                if (isPhysicalInternetNetwork(cm, net, caps)) {
                    physicalNetworks[net] = caps
                }
            }
            if (physicalNetworks.isEmpty()) {
                cm.activeNetwork?.let { activeNet ->
                    val caps = cm.getNetworkCapabilities(activeNet)
                    if (caps != null && isPhysicalInternetNetwork(cm, activeNet, caps)) {
                        physicalNetworks[activeNet] = caps
                    }
                }
            }
            if (physicalNetworks.isEmpty()) {
                @Suppress("DEPRECATION")
                for (net in cm.allNetworks) {
                    val caps = cm.getNetworkCapabilities(net) ?: continue
                    if (isFallbackPhysicalTransport(cm, net, caps)) {
                        physicalNetworks[net] = caps
                    }
                }
            }
            emitBestPhysicalInterface(cm, listener)

            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                .build()

            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    val caps = cm.getNetworkCapabilities(network)
                    if (caps != null && isPhysicalInternetNetwork(cm, network, caps)) {
                        physicalNetworks[network] = caps
                        emitBestPhysicalInterface(cm, listener)
                    }
                }

                override fun onCapabilitiesChanged(
                    network: Network,
                    networkCapabilities: NetworkCapabilities
                ) {
                    if (isPhysicalInternetNetwork(cm, network, networkCapabilities)) {
                        physicalNetworks[network] = networkCapabilities
                    } else {
                        physicalNetworks.remove(network)
                    }
                    emitBestPhysicalInterface(cm, listener)
                }

                override fun onLinkPropertiesChanged(
                    network: Network,
                    linkProperties: android.net.LinkProperties
                ) {
                    val caps = cm.getNetworkCapabilities(network)
                    if (caps != null && isPhysicalInternetNetwork(cm, network, caps)) {
                        physicalNetworks[network] = caps
                        emitBestPhysicalInterface(cm, listener)
                    }
                }

                override fun onLost(network: Network) {
                    physicalNetworks.remove(network)
                    emitBestPhysicalInterface(cm, listener)
                }
            }

            networkCallback = callback
            try {
                cm.registerNetworkCallback(request, callback)
            } catch (e: Exception) {
                Log.w(TAG, "registerNetworkCallback failed: ${e.message}")
            }
        }

        private fun isPhysicalInternetNetwork(
            cm: ConnectivityManager,
            network: Network,
            caps: NetworkCapabilities
        ): Boolean {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return false
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            ) {
                return false
            }
            val ifName = cm.getLinkProperties(network)?.interfaceName ?: return false
            return !ifName.startsWith("tun") && !ifName.startsWith("ppp")
        }

        private fun isFallbackPhysicalTransport(
            cm: ConnectivityManager,
            network: Network,
            caps: NetworkCapabilities
        ): Boolean {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return false
            val hasPhysicalTransport =
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
            if (!hasPhysicalTransport) return false
            val ifName = cm.getLinkProperties(network)?.interfaceName ?: return false
            return !ifName.startsWith("tun") && !ifName.startsWith("ppp")
        }

        private fun emitBestPhysicalInterface(
            cm: ConnectivityManager,
            listener: InterfaceUpdateListener
        ) {
            try {
                // Rank: Ethernet (3) > Wi-Fi (2) > Cellular (1) > Other (0)
                val bestEntry = physicalNetworks.entries.maxByOrNull { (_, caps) ->
                    when {
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 3
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 2
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 1
                        else -> 0
                    }
                }

                if (bestEntry == null) {
                    @Suppress("DEPRECATION")
                    for (net in cm.allNetworks) {
                        val caps = cm.getNetworkCapabilities(net) ?: continue
                        if (isPhysicalInternetNetwork(cm, net, caps) || isFallbackPhysicalTransport(cm, net, caps)) {
                            physicalNetworks[net] = caps
                        }
                    }
                }

                val resolvedBest = physicalNetworks.entries.maxByOrNull { (_, caps) ->
                    when {
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 3
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 2
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 1
                        else -> 0
                    }
                }

                if (resolvedBest == null) {
                    currentPhysicalNetwork = null
                    if (lastEmittedInterfaceKey != "NONE") {
                        lastEmittedInterfaceKey = "NONE"
                        listener.updateDefaultInterface("", -1, false, false)
                    }
                    return
                }

                val bestNet = resolvedBest.key
                val caps = resolvedBest.value
                val linkProps = cm.getLinkProperties(bestNet) ?: return
                val ifName = linkProps.interfaceName ?: return
                if (ifName.startsWith("tun")) return

                currentPhysicalNetwork = bestNet
                val ifIndex = resolveInterfaceIndex(ifName, linkProps)
                val isExpensive = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
                val key = "$ifName|$ifIndex|$isExpensive"
                if (key != lastEmittedInterfaceKey) {
                    lastEmittedInterfaceKey = key
                    onLog("Physical default interface: $ifName (index=$ifIndex, metered=$isExpensive)")
                    listener.updateDefaultInterface(ifName, ifIndex, isExpensive, false)
                }
            } catch (e: Exception) {
                Log.w(TAG, "emitBestPhysicalInterface failed: ${e.message}")
            }
        }

        private fun resolveInterfaceIndex(
            ifName: String,
            linkProps: android.net.LinkProperties? = null
        ): Int {
            try {
                val netIf = java.net.NetworkInterface.getByName(ifName)
                if (netIf != null && netIf.index > 0) return netIf.index
                linkProps?.linkAddresses?.forEach { la ->
                    val addr = la.address ?: return@forEach
                    val byAddr = runCatching { java.net.NetworkInterface.getByInetAddress(addr) }.getOrNull()
                    if (byAddr != null && byAddr.index > 0) return byAddr.index
                }
                val enumIfs = java.net.NetworkInterface.getNetworkInterfaces()
                while (enumIfs != null && enumIfs.hasMoreElements()) {
                    val candidate = enumIfs.nextElement()
                    if (candidate.name == ifName && candidate.index > 0) return candidate.index
                }
            } catch (_: Exception) {}
            return 0
        }

        override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
            val cb = networkCallback
            networkCallback = null
            currentListener = null
            lastEmittedInterfaceKey = null
            physicalNetworks.clear()
            currentPhysicalNetwork = null
            if (cb != null) {
                try {
                    connectivityManager?.unregisterNetworkCallback(cb)
                } catch (_: Exception) {}
            }
        }

        override fun getInterfaces(): NetworkInterfaceIterator {
            val cm = connectivityManager
            val result = mutableListOf<NetworkInterface>()

            if (cm != null) {
                @Suppress("DEPRECATION")
                val networks = cm.allNetworks
                for (network in networks) {
                    try {
                        val caps = cm.getNetworkCapabilities(network) ?: continue
                        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                        val linkProps = cm.getLinkProperties(network) ?: continue
                        val ifName = linkProps.interfaceName ?: continue
                        if (ifName.startsWith("tun")) continue

                        val sysIf = try {
                            java.net.NetworkInterface.getByName(ifName)
                        } catch (_: Exception) {
                            null
                        }

                        val resolvedIndex = sysIf?.let { runCatching { it.index }.getOrNull() }?.takeIf { it > 0 }
                            ?: resolveInterfaceIndex(ifName, linkProps)

                        val boxIf = NetworkInterface().apply {
                            name = ifName
                            index = resolvedIndex
                            mtu = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                linkProps.mtu.takeIf { it > 0 }
                                    ?: sysIf?.let { runCatching { it.mtu }.getOrNull() }?.takeIf { it > 0 }
                                    ?: 1500
                            } else {
                                sysIf?.let { runCatching { it.mtu }.getOrNull() }?.takeIf { it > 0 } ?: 1500
                            }
                            // Active ConnectivityManager interfaces are UP & RUNNING; guard individual
                            // sysIf ioctls so Android SELinux restrictions never drop the interface.
                            var netFlags = 1 or (1 shl 5)
                            if (sysIf != null) {
                                if (runCatching { sysIf.isLoopback }.getOrDefault(false)) netFlags = netFlags or (1 shl 2)
                                if (runCatching { sysIf.isPointToPoint }.getOrDefault(false)) netFlags = netFlags or (1 shl 3)
                                if (runCatching { sysIf.supportsMulticast() }.getOrDefault(true)) netFlags = netFlags or (1 shl 4)
                            }
                            flags = netFlags
                            type = when {
                                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Libbox.InterfaceTypeWIFI
                                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Libbox.InterfaceTypeCellular
                                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Libbox.InterfaceTypeEthernet
                                else -> Libbox.InterfaceTypeOther
                            }
                            metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)

                            // Strip IPv6 %scope zone suffix so Go netip.ParsePrefix parses cleanly
                            val addrs = linkProps.linkAddresses.mapNotNull { la ->
                                val hostAddr = la.address?.hostAddress?.substringBefore('%')
                                    ?: return@mapNotNull null
                                "$hostAddr/${la.prefixLength}"
                            }
                            addresses = StringIteratorImpl(addrs)

                            val dnsList = linkProps.dnsServers.mapNotNull {
                                it.hostAddress?.substringBefore('%')
                            }
                            dnsServer = StringIteratorImpl(dnsList)
                        }
                        result.add(boxIf)
                    } catch (_: Exception) {}
                }
            }

            return object : NetworkInterfaceIterator {
                private var idx = 0
                override fun hasNext(): Boolean = idx < result.size
                override fun next(): NetworkInterface = result[idx++]
            }
        }

        override fun includeAllNetworks(): Boolean = false

        override fun underNetworkExtension(): Boolean = false

        override fun useProcFS(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

        override fun findConnectionOwner(
            ipProtocol: Int,
            sourceAddress: String,
            sourcePort: Int,
            destinationAddress: String,
            destinationPort: Int
        ): ConnectionOwner {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && connectivityManager != null) {
                try {
                    val uid = connectivityManager.getConnectionOwnerUid(
                        ipProtocol,
                        InetSocketAddress(sourceAddress, sourcePort),
                        InetSocketAddress(destinationAddress, destinationPort)
                    )
                    if (uid >= 0) {
                        val pkg = vpnService.packageManager.getPackagesForUid(uid)?.firstOrNull().orEmpty()
                        return ConnectionOwner().apply {
                            userId = uid
                            androidPackageName = pkg
                        }
                    }
                } catch (_: Exception) {}
            }
            return ConnectionOwner()
        }

        private val dnsExecutor = java.util.concurrent.Executors.newCachedThreadPool()

        override fun localDNSTransport(): LocalDNSTransport? {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
            return object : LocalDNSTransport {
                override fun raw(): Boolean = true

                override fun exchange(ctx: ExchangeContext, message: ByteArray) {
                    val physicalNet = currentPhysicalNetwork ?: resolveFallbackPhysicalNetwork()
                    if (physicalNet == null) {
                        ctx.errnoCode(OsConstants.ENETUNREACH)
                        return
                    }
                    val signal = CancellationSignal()
                    ctx.onCancel { signal.cancel() }
                    android.net.DnsResolver.getInstance().rawQuery(
                        physicalNet,
                        message,
                        android.net.DnsResolver.FLAG_EMPTY,
                        dnsExecutor,
                        signal,
                        object : android.net.DnsResolver.Callback<ByteArray> {
                            override fun onAnswer(answer: ByteArray, rcode: Int) {
                                if (answer.isNotEmpty()) {
                                    ctx.rawSuccess(answer)
                                } else {
                                    ctx.errorCode(if (rcode > 0) rcode else 2)
                                }
                            }

                            override fun onError(error: android.net.DnsResolver.DnsException) {
                                ctx.errnoCode(OsConstants.EIO)
                            }
                        }
                    )
                }

                override fun lookup(ctx: ExchangeContext, network: String, domain: String) {
                    val physicalNet = currentPhysicalNetwork ?: resolveFallbackPhysicalNetwork()
                    try {
                        val allAddrs = if (physicalNet != null) {
                            physicalNet.getAllByName(domain).toList()
                        } else {
                            InetAddress.getAllByName(domain).toList()
                        }
                        val filtered = when (network.lowercase()) {
                            "ip4" -> allAddrs.filterIsInstance<java.net.Inet4Address>()
                            "ip6" -> allAddrs.filterIsInstance<java.net.Inet6Address>()
                            else -> allAddrs
                        }.ifEmpty { allAddrs }
                        val addresses = filtered.mapNotNull { it.hostAddress }
                        if (addresses.isNotEmpty()) {
                            ctx.success(addresses.joinToString("\n"))
                        } else {
                            ctx.errnoCode(OsConstants.ENOENT)
                        }
                    } catch (_: Exception) {
                        ctx.errnoCode(OsConstants.ENOENT)
                    }
                }
            }
        }

        private fun resolveFallbackPhysicalNetwork(): Network? {
            val cm = connectivityManager ?: return null
            @Suppress("DEPRECATION")
            return cm.allNetworks.firstOrNull { net ->
                val caps = cm.getNetworkCapabilities(net) ?: return@firstOrNull false
                !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            }
        }

        override fun readWIFIState(): WIFIState? = null

        override fun sendNotification(notification: Notification) {
            if (notification.body.isNotBlank()) {
                onLog("${notification.title}: ${notification.body}")
            }
        }

        override fun systemCertificates(): StringIterator {
            val certs = mutableListOf<String>()
            try {
                val keyStore = KeyStore.getInstance("AndroidCAStore")
                keyStore.load(null, null)
                val aliases = keyStore.aliases()
                while (aliases.hasMoreElements()) {
                    val alias = aliases.nextElement()
                    val cert = keyStore.getCertificate(alias) ?: continue
                    val pem = "-----BEGIN CERTIFICATE-----\n" +
                        Base64.encodeToString(cert.encoded, Base64.DEFAULT) +
                        "-----END CERTIFICATE-----"
                    certs.add(pem)
                }
            } catch (_: Exception) {}
            return StringIteratorImpl(certs)
        }

        fun cleanup() {
            val cb = networkCallback
            networkCallback = null
            currentListener = null
            lastEmittedInterfaceKey = null
            physicalNetworks.clear()
            currentPhysicalNetwork = null
            if (cb != null) {
                try {
                    connectivityManager?.unregisterNetworkCallback(cb)
                } catch (_: Exception) {}
            }
        }
    }

    private class StringIteratorImpl(
        private val items: List<String>
    ) : StringIterator {
        private var index = 0
        override fun hasNext(): Boolean = index < items.size
        override fun len(): Int = items.size
        override fun next(): String = items[index++]
    }

    companion object {
        private const val TAG = "SingBoxEngine"
        private const val MAX_LOG_LINES = 80
        private const val ALLOW_DIRECT_FALLBACK_PROBE = false
        private val isSetupInitialized = AtomicBoolean(false)

        val DEFAULT_PROBE_TARGETS = listOf(
            ProbeTarget("https", "connectivitycheck.gstatic.com", 443, "/generate_204"),
            ProbeTarget("https", "ifconfig.me", 443, "/ip")
        )

        private val IPV4_REGEX = Regex("""^(\d{1,3}\.){3}\d{1,3}$""")
        private val IPV6_REGEX = Regex("""^[0-9a-fA-F:]+$""")

        fun ensureSetup(context: Context) {
            if (isSetupInitialized.get()) return
            synchronized(this) {
                if (isSetupInitialized.get()) return
                val baseDir = context.filesDir
                val workDir = context.getExternalFilesDir(null) ?: baseDir
                val tempDir = context.cacheDir
                File(baseDir.absolutePath).mkdirs()
                File(workDir.absolutePath).mkdirs()
                File(tempDir.absolutePath).mkdirs()

                val options = SetupOptions().apply {
                    basePath = baseDir.absolutePath
                    workingPath = workDir.absolutePath
                    tempPath = tempDir.absolutePath
                    fixAndroidStack = true
                    debug = false
                    logMaxLines = 500L
                }
                Libbox.setup(options)
                Libbox.setMemoryLimit(true)
                isSetupInitialized.set(true)
            }
        }

        fun findFreeLocalPort(): Int {
            return ServerSocket(0, 1, InetAddress.getByName("127.0.0.1")).use { it.localPort }
        }

        /**
         * Detects if the app is running inside an Android emulator / cloud streaming preview sandbox
         * (such as AI Studio preview) where raw outbound VLESS Reality streams may be dropped by host NAT.
         */
        fun isEmulatorOrSandboxEnvironment(): Boolean {
            return detectEmulatorEnvironment(
                fingerprint = Build.FINGERPRINT,
                model = Build.MODEL,
                manufacturer = Build.MANUFACTURER,
                brand = Build.BRAND,
                device = Build.DEVICE,
                hardware = Build.HARDWARE,
                product = Build.PRODUCT,
                qemuProperty = readSystemProperty("ro.kernel.qemu")
                    .ifEmpty { readSystemProperty("ro.boot.qemu") },
                characteristicsProperty = readSystemProperty("ro.build.characteristics")
            )
        }

        private fun readSystemProperty(key: String): String {
            return try {
                val cls = Class.forName("android.os.SystemProperties")
                val method = cls.getMethod("get", String::class.java, String::class.java)
                (method.invoke(null, key, "") as? String).orEmpty()
            } catch (_: Exception) {
                ""
            }
        }

        fun detectEmulatorEnvironment(
            fingerprint: String,
            model: String,
            manufacturer: String,
            brand: String,
            device: String,
            hardware: String,
            product: String,
            qemuProperty: String = "",
            characteristicsProperty: String = ""
        ): Boolean {
            if (qemuProperty == "1") return true
            if (characteristicsProperty.contains("emulator", ignoreCase = true)) return true
            val combined = "$fingerprint $model $manufacturer $brand $device $hardware $product".lowercase()
            return combined.contains("ranchu") ||
                combined.contains("goldfish") ||
                combined.contains("emulator") ||
                combined.contains("sdk_gphone") ||
                combined.contains("simulator") ||
                combined.contains("cuttlefish") ||
                combined.contains("cutf") ||
                combined.contains("vsoc") ||
                combined.contains("genymotion") ||
                combined.contains("vbox") ||
                combined.contains("emu64") ||
                combined.contains("qemu") ||
                combined.contains("virtio") ||
                combined.contains("aosp_cf") ||
                combined.contains("android_x86") ||
                brand.startsWith("generic", ignoreCase = true) ||
                device.startsWith("generic", ignoreCase = true) ||
                product.startsWith("sdk", ignoreCase = true)
        }

        /**
         * Encodes an RFC 1928 SOCKS5 CONNECT request using ATYP=0x03 (domain name) so sing-box
         * resolves DNS remotely via proxy outbound.
         */
        fun buildSocks5ConnectRequest(host: String, port: Int): ByteArray {
            val hostBytes = host.toByteArray(StandardCharsets.UTF_8)
            val req = ByteArray(7 + hostBytes.size)
            req[0] = 0x05 // VER
            req[1] = 0x01 // CMD = CONNECT
            req[2] = 0x00 // RSV
            req[3] = 0x03 // ATYP = DOMAINNAME
            req[4] = hostBytes.size.toByte()
            System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
            req[5 + hostBytes.size] = ((port ushr 8) and 0xFF).toByte()
            req[6 + hostBytes.size] = (port and 0xFF).toByte()
            return req
        }

        fun parseTraceExitIp(traceBody: String): String? {
            return traceBody.lineSequence()
                .firstOrNull { it.startsWith("ip=") }
                ?.removePrefix("ip=")
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
        }

        fun parseExitIpFromResponse(httpResponse: String): String? {
            parseTraceExitIp(httpResponse)?.let { return it }

            val separator = when {
                httpResponse.contains("\r\n\r\n") -> "\r\n\r\n"
                httpResponse.contains("\n\n") -> "\n\n"
                else -> return null
            }
            val headers = httpResponse.substringBefore(separator)
            val rawBody = httpResponse.substringAfter(separator).trim()
            if (rawBody.isEmpty()) return null

            val candidate = if (headers.contains("transfer-encoding: chunked", ignoreCase = true)) {
                rawBody.lineSequence()
                    .map { it.trim() }
                    .firstOrNull { isValidIpLiteral(it) }
                    ?: return null
            } else {
                rawBody.lineSequence().firstOrNull()?.trim().orEmpty()
            }

            return candidate.takeIf { isValidIpLiteral(it) }
        }

        private fun isValidIpLiteral(value: String): Boolean {
            if (value.isEmpty() || value.length > 45) return false
            if (IPV4_REGEX.matches(value)) {
                return value.split('.').all { part ->
                    val num = part.toIntOrNull()
                    num != null && num in 0..255
                }
            }
            return value.contains(':') && IPV6_REGEX.matches(value)
        }

        fun extractRelevantCoreError(coreLogs: List<String>): String? {
            val highPriority = coreLogs.asReversed().firstOrNull { line ->
                val lower = line.lowercase()
                lower.contains("error") ||
                    lower.contains("fatal") ||
                    lower.contains("dial tcp") ||
                    lower.contains("tls:") ||
                    lower.contains("reality") ||
                    lower.contains("missing default interface") ||
                    lower.contains("no route") ||
                    lower.contains("protect") ||
                    lower.contains("operation not permitted") ||
                    lower.contains("permission") ||
                    lower.contains("connection refused") ||
                    lower.contains("connection reset") ||
                    lower.contains("reset by peer") ||
                    lower.contains("i/o timeout")
            }
            if (highPriority != null) return highPriority

            return coreLogs.asReversed().firstOrNull { line ->
                val lower = line.lowercase()
                lower.contains("warn") ||
                    lower.contains("handshake") ||
                    lower.contains("broken pipe") ||
                    lower.contains("closed") ||
                    lower.contains("unreachable") ||
                    lower.contains("no such") ||
                    lower.contains("eof") ||
                    lower.contains("timeout")
            }
        }

        fun diagnoseProbeFailure(
            stage: TunnelFailureStage,
            targetHost: String,
            coreLogs: List<String> = emptyList(),
            isEmulator: Boolean = isEmulatorOrSandboxEnvironment(),
            rawDetail: String? = null
        ): Pair<TunnelFailureStage, String> {
            val coreHint = extractRelevantCoreError(coreLogs)?.let { " [core: ${it.take(140)}]" }.orEmpty()
            val detailSuffix = rawDetail?.takeIf { it.isNotBlank() }?.let { " ($it)" }.orEmpty()

            return when (stage) {
                TunnelFailureStage.SOCKS_BIND_UNREACHABLE -> {
                    stage to "Local Sing-box SOCKS5 listener unreachable (${rawDetail ?: "port bind failed"})$coreHint"
                }
                TunnelFailureStage.SOCKS5_HANDSHAKE_FAILED -> {
                    if (isEmulator && coreHint.isEmpty()) {
                        TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED to
                            "Sandbox/Emulator preview blocked VLESS Reality outbound during SOCKS5 CONNECT ($targetHost)$detailSuffix; real Android devices connect normally"
                    } else if (coreHint.isNotEmpty()) {
                        stage to "${coreHint.trim()} — ${rawDetail ?: "Sing-box SOCKS5 proxy handshake failed for $targetHost"}"
                    } else {
                        stage to "${rawDetail ?: "Sing-box SOCKS5 proxy handshake failed for $targetHost"}"
                    }
                }
                TunnelFailureStage.TLS_TUNNEL_HANDSHAKE_FAILED -> {
                    if (isEmulator && coreHint.isEmpty()) {
                        TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED to
                            "Sandbox/Emulator preview blocked HTTPS TLS handshake through VLESS Reality to $targetHost$detailSuffix"
                    } else {
                        stage to "TLS handshake over VLESS Reality failed for $targetHost$detailSuffix$coreHint"
                    }
                }
                TunnelFailureStage.UPSTREAM_REALITY_EOF -> {
                    if (isEmulator && coreHint.isEmpty()) {
                        TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED to
                            "Sandbox/Emulator preview environment blocked upstream VLESS Reality stream ($targetHost)$detailSuffix; real Android devices connect normally"
                    } else if (isEmulator) {
                        TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED to
                            "Sandbox/Emulator preview blocked tunnel egress to $targetHost$detailSuffix$coreHint"
                    } else {
                        stage to "Upstream VLESS Reality tunnel closed before response from $targetHost$detailSuffix$coreHint"
                    }
                }
                TunnelFailureStage.HTTP_READ_TIMEOUT -> {
                    if (isEmulator) {
                        TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED to
                            "Sandbox/Emulator preview timed out waiting for HTTPS response from $targetHost$detailSuffix$coreHint"
                    } else {
                        stage to "Timed out waiting for HTTPS response from $targetHost$detailSuffix$coreHint"
                    }
                }
                TunnelFailureStage.UNEXPECTED_HTTP_RESPONSE -> {
                    stage to "Unexpected response via tunnel from $targetHost: ${rawDetail ?: "invalid HTTP"}$coreHint"
                }
                TunnelFailureStage.ENVIRONMENT_SANDBOX_BLOCKED -> {
                    stage to (rawDetail ?: "Sandbox/Emulator environment blocked VLESS Reality tunnel$coreHint")
                }
                TunnelFailureStage.NONE -> {
                    TunnelFailureStage.UPSTREAM_REALITY_EOF to "Tunnel check failed for $targetHost$detailSuffix$coreHint"
                }
            }
        }

        /**
         * Performs an end-to-end HTTPS connectivity verification through the live sing-box
         * SOCKS5 loopback -> VLESS Reality proxy outbound (`149.28.156.223:47778`),
         * probing `https://connectivitycheck.gstatic.com/generate_204` and `https://ifconfig.me/ip`.
         *
         * All probe sockets are explicitly protected via [socketProtector] (`VpnService.protect`)
         * before connecting to prevent TUN routing loops on any Android device or OEM ROM.
         */
        fun verifyEndToEndTunnel(
            socksPort: Int,
            timeoutMs: Int = 7000,
            recentCoreLogs: List<String> = emptyList(),
            coreLogProvider: () -> List<String> = { recentCoreLogs },
            isEmulatorEnvironment: Boolean = isEmulatorOrSandboxEnvironment(),
            probeTargets: List<ProbeTarget> = DEFAULT_PROBE_TARGETS,
            socketProtector: ((Socket) -> Boolean)? = null,
            tlsSocketWrapper: ((Socket, String, Int, Int) -> Socket)? = null
        ): TunnelProbeResult {
            if (probeTargets.isEmpty()) {
                return TunnelProbeResult(
                    success = false,
                    failureStage = TunnelFailureStage.SOCKS5_HANDSHAKE_FAILED,
                    errorDetail = "No tunnel probe targets configured"
                )
            }

            var lastStage = TunnelFailureStage.UPSTREAM_REALITY_EOF
            var lastHost = probeTargets.first().host
            val failureSummaries = mutableListOf<String>()

            for ((index, target) in probeTargets.withIndex()) {
                lastHost = target.host
                val maxAttempts = if (index == 0) 3 else 1
                for (attempt in 1..maxAttempts) {
                    var rawSocket: Socket? = null
                    var transportSocket: Socket? = null
                    var retryTransientEof = false
                    try {
                        val start = System.currentTimeMillis()
                        rawSocket = connectLocalProbeSocket(socksPort, timeoutMs, socketProtector)

                        val rawOut = rawSocket.getOutputStream()
                        val rawIn = rawSocket.getInputStream()

                        // 1. SOCKS5 Greeting (VER=5, NMETHODS=1, NO_AUTH=0)
                        rawOut.write(byteArrayOf(0x05, 0x01, 0x00))
                        rawOut.flush()

                        val greetingReply = try {
                            readExactly(rawIn, 2)
                        } catch (e: SocketTimeoutException) {
                            throw e
                        } catch (e: Exception) {
                            lastStage = TunnelFailureStage.SOCKS5_HANDSHAKE_FAILED
                            failureSummaries.add("${target.host}: SOCKS5 greeting failed (${e.message})")
                            break
                        }

                        if (greetingReply[0] != 0x05.toByte() || greetingReply[1] != 0x00.toByte()) {
                            lastStage = TunnelFailureStage.SOCKS5_HANDSHAKE_FAILED
                            failureSummaries.add(
                                "${target.host}: SOCKS5 auth rejected (method=${greetingReply[1].toInt() and 0xFF})"
                            )
                            break
                        }

                        // 2. SOCKS5 CONNECT (ATYP=0x03 domain name) through VLESS Reality proxy
                        rawOut.write(buildSocks5ConnectRequest(target.host, target.port))
                        rawOut.flush()

                        val connectHead = try {
                            readExactly(rawIn, 4)
                        } catch (e: SocketTimeoutException) {
                            throw e
                        } catch (e: Exception) {
                            lastStage = TunnelFailureStage.SOCKS5_HANDSHAKE_FAILED
                            failureSummaries.add("${target.host}: SOCKS5 CONNECT failed (${e.message})")
                            break
                        }

                        if (connectHead[1] != 0x00.toByte()) {
                            lastStage = TunnelFailureStage.SOCKS5_HANDSHAKE_FAILED
                            val repCode = connectHead[1].toInt() and 0xFF
                            if (attempt < maxAttempts && repCode == 1) {
                                try {
                                    Thread.sleep(250)
                                } catch (_: InterruptedException) {
                                    break
                                }
                                continue
                            } else {
                                failureSummaries.add(
                                    "${target.host}: SOCKS5 CONNECT rejected (rep=$repCode)"
                                )
                                break
                            }
                        }

                        // Consume bound address bytes
                        when (connectHead[3].toInt() and 0xFF) {
                            0x01 -> readExactly(rawIn, 6) // IPv4 + port
                            0x03 -> {
                                val len = rawIn.read()
                                if (len > 0) readExactly(rawIn, len + 2)
                            }
                            0x04 -> readExactly(rawIn, 18) // IPv6 + port
                        }

                        // 3. Layer verified HTTPS TLS (or injected socket wrapper in unit tests)
                        transportSocket = if (tlsSocketWrapper != null) {
                            tlsSocketWrapper(rawSocket, target.host, target.port, timeoutMs)
                        } else if (target.scheme.equals("https", ignoreCase = true)) {
                            wrapAndVerifyTlsSocket(rawSocket, target.host, target.port, timeoutMs)
                        } else {
                            rawSocket
                        }
                        transportSocket.soTimeout = timeoutMs

                        val tunnelOut = transportSocket.getOutputStream()
                        val tunnelIn = transportSocket.getInputStream()

                        // 4. Send HTTP/1.1 GET request through the encrypted VLESS Reality + TLS stream
                        val userAgent = if (target.path == "/ip") "curl/8.5.0" else "SS-VPN/1.0"
                        val httpReq =
                            "GET ${target.path} HTTP/1.1\r\n" +
                                "Host: ${target.host}\r\n" +
                                "Connection: close\r\n" +
                                "User-Agent: $userAgent\r\n" +
                                "Accept: */*\r\n\r\n"
                        tunnelOut.write(httpReq.toByteArray(StandardCharsets.US_ASCII))
                        tunnelOut.flush()

                        // Read complete HTTP response (up to 8KB). For body-bearing /ip probes, wait for body/IP.
                        val respBytes = ByteArrayOutputStream()
                        val buf = ByteArray(1024)
                        val expectsBody = target.path == "/ip"
                        while (respBytes.size() < 8192) {
                            val readCount = tunnelIn.read(buf)
                            if (readCount <= 0) break
                            respBytes.write(buf, 0, readCount)
                            val partial = respBytes.toString(StandardCharsets.UTF_8.name())
                            if (!expectsBody && partial.contains("\r\n\r\n")) {
                                break
                            }
                            if (expectsBody && parseExitIpFromResponse(partial) != null) {
                                break
                            }
                        }

                        val respText = respBytes.toString(StandardCharsets.UTF_8.name())
                        val latency = (System.currentTimeMillis() - start).toInt()

                        if (respText.startsWith("HTTP/1.")) {
                            val statusCode = respText.lineSequence().firstOrNull()
                                ?.split(" ")?.getOrNull(1)?.toIntOrNull()
                            if (statusCode != null && statusCode in 200..399) {
                                val exitIp = parseExitIpFromResponse(respText)
                                return TunnelProbeResult(
                                    success = true,
                                    latencyMs = maxOf(1, latency),
                                    exitIp = exitIp
                                )
                            } else {
                                lastStage = TunnelFailureStage.UNEXPECTED_HTTP_RESPONSE
                                val statusLine = respText.lineSequence().firstOrNull()?.take(60) ?: "HTTP $statusCode"
                                failureSummaries.add("${target.host}: $statusLine")
                            }
                        } else if (respText.isEmpty()) {
                            lastStage = TunnelFailureStage.UPSTREAM_REALITY_EOF
                            if (attempt < maxAttempts) {
                                retryTransientEof = true
                            } else {
                                failureSummaries.add("${target.host}: 0-byte EOF")
                            }
                        } else {
                            lastStage = TunnelFailureStage.UNEXPECTED_HTTP_RESPONSE
                            val preview = respText.lineSequence().firstOrNull()?.take(60) ?: "non-HTTP response"
                            failureSummaries.add("${target.host}: $preview")
                        }
                    } catch (e: SocketTimeoutException) {
                        lastStage = TunnelFailureStage.HTTP_READ_TIMEOUT
                        failureSummaries.add("${target.host}: timeout after ${timeoutMs}ms")
                    } catch (e: java.net.ConnectException) {
                        lastStage = TunnelFailureStage.SOCKS_BIND_UNREACHABLE
                        failureSummaries.add("${target.host}: SOCKS5 port $socksPort refused")
                    } catch (e: SSLException) {
                        val msg = e.message.orEmpty()
                        val lower = msg.lowercase()
                        if (lower.contains("closed") || lower.contains("eof") || lower.contains("reset")) {
                            lastStage = TunnelFailureStage.UPSTREAM_REALITY_EOF
                            if (attempt < maxAttempts) {
                                retryTransientEof = true
                            } else {
                                failureSummaries.add("${target.host}: TLS stream closed ($msg)")
                            }
                        } else {
                            lastStage = TunnelFailureStage.TLS_TUNNEL_HANDSHAKE_FAILED
                            failureSummaries.add("${target.host}: TLS error (${msg.take(80)})")
                        }
                    } catch (e: Exception) {
                        lastStage = TunnelFailureStage.UPSTREAM_REALITY_EOF
                        failureSummaries.add("${target.host}: ${e.message ?: e.javaClass.simpleName}")
                    } finally {
                        try {
                            transportSocket?.close()
                        } catch (_: Exception) {}
                        try {
                            rawSocket?.close()
                        } catch (_: Exception) {}
                    }

                    if (retryTransientEof) {
                        try {
                            Thread.sleep(250)
                        } catch (_: InterruptedException) {
                            break
                        }
                    } else {
                        break
                    }
                }
            }

            // libbox HTTPClient.trySocks5() ব্যর্থ হলে সরাসরি (ডিরেক্ট) ইন্টারনেটে চলে যায় — তাই এটা ভুয়া "সফল" দেখাত
            // (এক্সিট IP আসত আপনার নিজের ISP-র)। টানেল যাচাইয়ে এই ফলব্যাক আর ব্যবহার হয় না।
            if (ALLOW_DIRECT_FALLBACK_PROBE && tlsSocketWrapper == null &&
                (lastStage == TunnelFailureStage.SOCKS5_HANDSHAKE_FAILED ||
                    lastStage == TunnelFailureStage.UPSTREAM_REALITY_EOF ||
                    lastStage == TunnelFailureStage.TLS_TUNNEL_HANDSHAKE_FAILED ||
                    lastStage == TunnelFailureStage.HTTP_READ_TIMEOUT)
            ) {
                val (libboxResult, libboxError) = probeViaLibboxHttpClient(socksPort, probeTargets)
                if (libboxResult != null) {
                    return libboxResult
                }
                if (!libboxError.isNullOrBlank()) {
                    failureSummaries.add("libbox-http: $libboxError")
                }
            }

            var capturedLogs = coreLogProvider()
            if (tlsSocketWrapper == null && extractRelevantCoreError(capturedLogs) == null) {
                for (waitStep in 0 until 5) {
                    try {
                        Thread.sleep(60)
                    } catch (_: InterruptedException) {
                        break
                    }
                    capturedLogs = coreLogProvider()
                    if (extractRelevantCoreError(capturedLogs) != null) break
                }
            }

            val combinedDetail = failureSummaries.joinToString("; ").ifBlank { "All HTTPS probes failed" }
            val (diagnosedStage, diagnosedMessage) = diagnoseProbeFailure(
                stage = lastStage,
                targetHost = lastHost,
                coreLogs = capturedLogs,
                isEmulator = isEmulatorEnvironment,
                rawDetail = combinedDetail
            )
            return TunnelProbeResult(
                success = false,
                errorDetail = diagnosedMessage,
                failureStage = diagnosedStage
            )
        }

        private fun probeViaLibboxHttpClient(
            socksPort: Int,
            probeTargets: List<ProbeTarget>
        ): Pair<TunnelProbeResult?, String?> {
            var lastError: String? = null
            var client: io.nekohasekai.libbox.HTTPClient? = null
            try {
                client = Libbox.newHTTPClient().apply {
                    modernTLS()
                    trySocks5(socksPort)
                }
                for (target in probeTargets) {
                    try {
                        val start = System.currentTimeMillis()
                        val req = client.newRequest().apply {
                            setURL(target.urlString)
                            setMethod("GET")
                            setUserAgent(if (target.path == "/ip") "curl/8.5.0" else "SS-VPN/1.0")
                        }
                        val resp = req.execute()
                        val body = resp.getContent()?.value?.trim().orEmpty()
                        val latency = maxOf(1, (System.currentTimeMillis() - start).toInt())
                        val exitIp = body.takeIf { isValidIpLiteral(it) }
                        if (target.path == "/generate_204" || exitIp != null || body.isNotEmpty()) {
                            return TunnelProbeResult(
                                success = true,
                                latencyMs = latency,
                                exitIp = exitIp
                            ) to null
                        }
                    } catch (e: Exception) {
                        lastError = "${target.host}: ${e.message?.take(120) ?: e.javaClass.simpleName}"
                    }
                }
            } catch (t: UnsatisfiedLinkError) {
                return null to null
            } catch (t: Throwable) {
                lastError = t.message?.take(120) ?: t.javaClass.simpleName
            } finally {
                try {
                    client?.close()
                } catch (_: Throwable) {}
            }
            return null to lastError
        }

        private fun wrapAndVerifyTlsSocket(
            rawSocket: Socket,
            host: String,
            port: Int,
            timeoutMs: Int
        ): SSLSocket {
            val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
            val sslSocket = sslFactory.createSocket(rawSocket, host, port, true) as SSLSocket
            sslSocket.soTimeout = timeoutMs
            val params = sslSocket.sslParameters
            params.serverNames = listOf(SNIHostName(host))
            params.endpointIdentificationAlgorithm = "HTTPS"
            sslSocket.sslParameters = params
            sslSocket.startHandshake()
            if (!HttpsURLConnection.getDefaultHostnameVerifier().verify(host, sslSocket.session)) {
                sslSocket.close()
                throw SSLPeerUnverifiedException("TLS hostname mismatch for $host")
            }
            return sslSocket
        }

        private fun connectLocalProbeSocket(
            socksPort: Int,
            timeoutMs: Int,
            socketProtector: ((Socket) -> Boolean)? = null
        ): Socket {
            var lastConnectEx: java.net.ConnectException? = null
            for (attempt in 0..3) {
                val socket = Socket()
                try {
                    if (socketProtector != null && !socketProtector.invoke(socket)) {
                        Log.w(TAG, "VpnService.protect(probeSocket) returned false for 127.0.0.1:$socksPort")
                    }
                    socket.soTimeout = timeoutMs
                    socket.tcpNoDelay = true
                    socket.connect(InetSocketAddress("127.0.0.1", socksPort), minOf(timeoutMs, 2500))
                    return socket
                } catch (e: java.net.ConnectException) {
                    try {
                        socket.close()
                    } catch (_: Exception) {}
                    lastConnectEx = e
                    if (attempt < 3) {
                        Thread.sleep(150)
                    }
                } catch (e: Exception) {
                    try {
                        socket.close()
                    } catch (_: Exception) {}
                    throw e
                }
            }
            throw lastConnectEx ?: java.net.ConnectException("Unable to bind 127.0.0.1:$socksPort")
        }

        private fun readExactly(inp: InputStream, count: Int): ByteArray {
            val out = ByteArray(count)
            var offset = 0
            while (offset < count) {
                val n = inp.read(out, offset, count - offset)
                if (n < 0) throw java.io.EOFException("Unexpected EOF from SOCKS5")
                offset += n
            }
            return out
        }

        /**
         * Converts real sing-box byte rates into UI TrafficStats without synthetic idle noise.
         */
        fun calculateLiveTrafficStats(
            uplinkBytesPerSec: Long,
            downlinkBytesPerSec: Long,
            totalUploadBytes: Long,
            totalDownloadBytes: Long,
            durationSeconds: Long
        ): TrafficStats {
            val upKbps = maxOf(0f, uplinkBytesPerSec / 1024f)
            val downKbps = maxOf(0f, downlinkBytesPerSec / 1024f)
            return TrafficStats(
                uploadSpeedKbps = upKbps,
                downloadSpeedKbps = downKbps,
                totalUploadBytes = maxOf(0L, totalUploadBytes),
                totalDownloadBytes = maxOf(0L, totalDownloadBytes),
                durationSeconds = maxOf(0L, durationSeconds)
            )
        }
    }
}
