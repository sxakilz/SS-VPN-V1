package com.example.billing

import android.app.Activity
import android.content.Context
import android.util.Log
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.example.RealityVpnApp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Google Play Billing (এককালীন প্রোডাক্ট)। প্রতিটি প্রোডাক্ট ID অ্যাডমিন প্যানেলের প্ল্যান তালিকার সাথে মেলে
 * (ID → কত দিন)। কেনা সফল হলে অ্যাপ নিজেই র‍্যান্ডম কী বানিয়ে ডিভাইসে প্রিমিয়াম চালু করে।
 * অ্যাপ Play Store থেকে ইনস্টল না হলে/Play Console-এ প্রোডাক্ট না থাকলে [ready] false থাকে — অ্যাপ ক্র্যাশ করে না।
 */
object BillingManager {
    private const val TAG = "BillingManager"

    data class PlanUi(val productId: String, val days: Int, val label: String, val price: String)

    private var client: BillingClient? = null
    private val detailsMap = HashMap<String, ProductDetails>()

    private val _plans = MutableStateFlow<List<PlanUi>>(emptyList())
    val plans: StateFlow<List<PlanUi>> = _plans.asStateFlow()

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message.asStateFlow()

    /** সর্বশেষ সফল ক্রয়ে তৈরি কী (ডায়লগে দেখানোর জন্য)। */
    private val _lastKey = MutableStateFlow<String?>(null)
    val lastKey: StateFlow<String?> = _lastKey.asStateFlow()

    private fun cfg() = RealityVpnApp.instance.appConfigManager

    private val listener = PurchasesUpdatedListener { result, purchases ->
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> purchases?.forEach { handle(it) }
            BillingClient.BillingResponseCode.USER_CANCELED -> _message.value = "Purchase cancelled"
            else -> _message.value = "Purchase failed: ${result.debugMessage.ifBlank { result.responseCode.toString() }}"
        }
    }

    /** কনফিগ বদলালে বা ডায়লগ খুললে কল হয়; Play চালু না থাকলে কিছু করে না। */
    fun refresh(context: Context) {
        if (!cfg().billing.value.playEnabled) { _ready.value = false; return }
        connect(context.applicationContext)
    }

    private fun connect(ctx: Context) {
        try {
            val existing = client
            if (existing != null && existing.isReady) { queryDetails(); queryOwned(); return }
            val c = client ?: BillingClient.newBuilder(ctx)
                .setListener(listener)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .build().also { client = it }
            c.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(r: BillingResult) {
                    if (r.responseCode == BillingClient.BillingResponseCode.OK) {
                        queryDetails(); queryOwned()
                    } else {
                        _ready.value = false
                        _message.value = "Play Billing unavailable (${r.responseCode})"
                    }
                }
                override fun onBillingServiceDisconnected() { _ready.value = false }
            })
        } catch (t: Throwable) {
            Log.w(TAG, "connect failed", t)
            _ready.value = false
        }
    }

    private fun queryDetails() {
        val c = client ?: return
        val plans = cfg().billing.value.plans
        if (plans.isEmpty()) { _plans.value = emptyList(); _ready.value = false; return }
        val products = plans.map {
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it.productId).setProductType(BillingClient.ProductType.INAPP).build()
        }
        try {
            c.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(products).build()) { r, list ->
                if (r.responseCode != BillingClient.BillingResponseCode.OK) {
                    _ready.value = false
                    _message.value = "Could not load products (${r.responseCode})"
                    return@queryProductDetailsAsync
                }
                detailsMap.clear()
                list.forEach { detailsMap[it.productId] = it }
                _plans.value = plans.mapNotNull { p ->
                    val d = detailsMap[p.productId] ?: return@mapNotNull null
                    PlanUi(p.productId, p.days, p.label, d.oneTimePurchaseOfferDetails?.formattedPrice ?: p.priceText)
                }
                _ready.value = _plans.value.isNotEmpty()
                if (!_ready.value) _message.value = "Products not found in Play Console yet"
            }
        } catch (t: Throwable) { _ready.value = false }
    }

    /** আগের অসমাপ্ত (pending/unconsumed) ক্রয় থাকলে এখন প্রক্রিয়া করে। */
    private fun queryOwned() {
        val c = client ?: return
        try {
            c.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()) { r, list ->
                if (r.responseCode == BillingClient.BillingResponseCode.OK) list.forEach { handle(it) }
            }
        } catch (_: Throwable) { }
    }

    fun launch(activity: Activity, productId: String) {
        val c = client
        val d = detailsMap[productId]
        if (c == null || !c.isReady || d == null) { _message.value = "Store not ready. Try again in a moment."; return }
        try {
            val params = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).build()))
                .build()
            val r = c.launchBillingFlow(activity, params)
            if (r.responseCode != BillingClient.BillingResponseCode.OK) _message.value = "Cannot start purchase (${r.responseCode})"
        } catch (t: Throwable) { _message.value = "Cannot start purchase: ${t.message}" }
    }

    private fun handle(p: Purchase) {
        if (p.purchaseState == Purchase.PurchaseState.PENDING) { _message.value = "Payment pending… premium will activate once it completes."; return }
        if (p.purchaseState != Purchase.PurchaseState.PURCHASED) return
        val m = cfg()
        val prefs = RealityVpnApp.instance.getSharedPreferences("ss_billing", Context.MODE_PRIVATE)
        val done = prefs.getStringSet("done_tokens", emptySet()) ?: emptySet()
        if (p.purchaseToken !in done) {
            val productId = p.products.firstOrNull() ?: return
            val days = m.billing.value.plans.firstOrNull { it.productId == productId }?.days ?: return
            val key = m.redeemPlayPurchase(days, p.orderId ?: p.purchaseToken.take(24))
            prefs.edit().putStringSet("done_tokens", done + p.purchaseToken).apply()
            _lastKey.value = key
            _message.value = "Premium activated! Your key: $key"
        }
        // কনজিউম করলে একই প্রোডাক্ট আবার কেনা যায় (এক্সটেন্ড/রিনিউ)
        try {
            client?.consumeAsync(ConsumeParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) { _, _ -> }
        } catch (_: Throwable) { }
    }

    fun clearMessage() { _message.value = "" }
}
